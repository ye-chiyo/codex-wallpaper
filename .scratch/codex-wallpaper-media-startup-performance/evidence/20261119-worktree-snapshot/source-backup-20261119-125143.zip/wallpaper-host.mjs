import { open, readFile, unlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { openMainPageSession } from "./read-only-probe.mjs";
import { runtimeSource } from "./client-runtime.mjs";
import { payloadFor } from "./static-background.mjs";
import { prepareMp4VirtualLayout } from "./mp4-layout.mjs";
import {
  loadWallpaperPreview,
  prepareWallpaperAsset,
} from "./wallpaper-library.mjs";

const defaultPage = "app://-/index.html";
const bindingName = "__codexWallpaperHostRequest";
const engineUrl = new URL(
  "../node_modules/webwallgl/webwallgl.global.min.js",
  import.meta.url
);

async function acquireLock(port) {
  const lockPath = join(tmpdir(), `codex-wallpaper-host-${port}.lock`);
  try {
    const handle = await open(lockPath, "wx");
    await handle.writeFile(String(process.pid));
    return { lockPath, handle };
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
    try {
      const owner = Number(await readFile(lockPath, "utf8"));
      process.kill(owner, 0);
      return null;
    } catch {
      await unlink(lockPath).catch(() => {});
      const handle = await open(lockPath, "wx");
      await handle.writeFile(String(process.pid));
      return { lockPath, handle };
    }
  }
}

async function releaseLock(lock) {
  lock?.handle.close();
  await unlink(lock?.lockPath).catch(() => {});
}

async function sessionEvaluate(session, expression) {
  const result = await session.send("Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: true,
  });
  if (result?.exceptionDetails)
    throw new Error(
      result.exceptionDetails.exception?.description ||
        result.exceptionDetails.text ||
        "Runtime evaluation failed"
    );
  return result?.result?.value;
}

async function loadPreview(session, id) {
  const entry = await loadWallpaperPreview(id);
  if (!entry) throw new Error("Preview not found");
  await sessionEvaluate(
    session,
    `globalThis.__codexWallpaperApi.receivePreview(${JSON.stringify(entry)})`
  );
}

async function loadAsset(session, id) {
  const entry = await prepareWallpaperAsset(id);
  if (!entry) throw new Error("Wallpaper not found");
  if (entry.type !== "web" && !entry.playable) {
    if (entry.previewDataUrl)
      await sessionEvaluate(
        session,
        `globalThis.__codexWallpaperApi.receivePreview(${JSON.stringify({
          id: entry.id,
          previewDataUrl: entry.previewDataUrl,
          fallback: true,
        })})`
      );
    throw new Error("Wallpaper exceeds the 512 MiB transfer limit");
  }
  if (entry.type === "scene") {
    const available = await sessionEvaluate(
      session,
      "typeof globalThis.WebWallGL === 'object'"
    );
    if (available !== true) {
      const engine = await readFile(engineUrl, "utf8");
      await sessionEvaluate(session, engine);
    }
  }
  const { path, mime, size, ...metadata } = entry;
  if (entry.type === "web") {
    await sessionEvaluate(
      session,
      `globalThis.__codexWallpaperApi.receiveAsset(${JSON.stringify(metadata)})`
    );
    return;
  }

  const layout =
    entry.type === "video" && mime === "video/mp4"
      ? await prepareMp4VirtualLayout(path, size).catch(() => null)
      : null;
  let token = null;
  try {
    token = await sessionEvaluate(
      session,
      `globalThis.__codexWallpaperApi.beginAssetFileTransfer(${JSON.stringify({
        ...metadata,
        mime,
        size,
      })}, ${JSON.stringify(layout)})`
    );
    if (token) {
      const document = await session.send("DOM.getDocument");
      const input = await session.send("DOM.querySelector", {
        nodeId: document.root.nodeId,
        selector: `input[data-codex-wallpaper-file="${token}"]`,
      });
      if (!input.nodeId) throw new Error("File input is not available");
      await session.send("DOM.setFileInputFiles", {
        files: [path],
        nodeId: input.nodeId,
      });
      const delivered = await sessionEvaluate(
        session,
        `globalThis.__codexWallpaperApi.finishAssetFileTransfer(${JSON.stringify(
          String(token)
        )})`
      );
      if (delivered !== false) return delivered;
      await sessionEvaluate(
        session,
        `globalThis.__codexWallpaperApi.cancelAssetFileTransfer(${JSON.stringify(
          String(token)
        )})`
      );
    }
    console.log(
      JSON.stringify({ fallback: "file-input-unavailable", id: String(id) })
    );
  } catch {
    await sessionEvaluate(
      session,
      `globalThis.__codexWallpaperApi?.cancelAssetFileTransfer?.(${JSON.stringify(
        String(token)
      )})`
    ).catch(() => {});
    console.log(
      JSON.stringify({ fallback: "file-input-failed", id: String(id) })
    );
  }

  const handle = await open(path, "r");
  try {
    const opened = await sessionEvaluate(
      session,
      `globalThis.__codexWallpaperApi.beginAssetTransfer(${JSON.stringify({
        ...metadata,
        mime,
        size,
      })})`
    );
    if (opened === false) return false;
    const chunkSize = 4 * 1024 * 1024;
    for (let offset = 0; offset < size; offset += chunkSize) {
      const length = Math.min(chunkSize, size - offset);
      const buffer = Buffer.allocUnsafe(length);
      const { bytesRead } = await handle.read(buffer, 0, length, offset);
      if (bytesRead <= 0) throw new Error("Asset transfer ended early");
      const received = await sessionEvaluate(
        session,
        `globalThis.__codexWallpaperApi.appendAssetTransferChunk(${JSON.stringify(
          String(id)
        )}, ${JSON.stringify(
          buffer.subarray(0, bytesRead).toString("base64")
        )})`
      );
      if (received === false) return false;
    }
    return await sessionEvaluate(
      session,
      `globalThis.__codexWallpaperApi.finishAssetTransfer(${JSON.stringify(
        String(id)
      )})`
    );
  } finally {
    await handle.close();
  }
}

const requestHandlers = {
  "load-preview": { run: loadPreview, error: "receivePreviewError" },
  "load-asset": { run: loadAsset, error: "receiveAssetError" },
};

export async function attachWallpaperHost({
  port,
  session,
  page = defaultPage,
  payload = null,
}) {
  const lock = await acquireLock(port);
  if (!lock) return null;
  const inFlight = new Map();
  let stopped = false;

  session.on("Runtime.bindingCalled", async ({ name, payload: raw }) => {
    if (name !== bindingName || stopped) return;
    let request;
    try {
      request = JSON.parse(raw);
    } catch {
      return;
    }
    if (request.type === "stop") {
      stopped = true;
      session.close();
      return;
    }
    const handler = requestHandlers[request.type];
    if (!handler) return;
    const key = `${request.type}:${request.id}`;
    const running = inFlight.get(key);
    if (running) {
      if (request.type === "load-asset") running.replacementRequested = true;
      return;
    }
    const flight = { replacementRequested: false };
    inFlight.set(key, flight);
    const deliver = async () => {
      do {
        flight.replacementRequested = false;
        if ((await handler.run(session, request.id)) !== false) return;
      } while (flight.replacementRequested && !stopped);
    };
    deliver()
      .catch(async (error) => {
        await sessionEvaluate(
          session,
          `globalThis.__codexWallpaperApi?.${handler.error}(${JSON.stringify(
            String(request.id)
          )}, ${JSON.stringify(String(error?.message || error))})`
        ).catch(() => {});
      })
      .finally(() => inFlight.delete(key));
  });

  try {
    await session.send("Runtime.enable");
    await session.send("Runtime.addBinding", { name: bindingName });
    const source = runtimeSource(payload ?? (await payloadFor()));
    await session.send("Page.addScriptToEvaluateOnNewDocument", {
      source: `(() => {
        if (window.top !== window || location.href !== ${JSON.stringify(page)}) return;
        document.addEventListener("DOMContentLoaded", async () => {
          if (location.href !== ${JSON.stringify(page)} || globalThis.__codexWallpaperApi) return;
          await ${source};
          await globalThis.__codexWallpaperApi.configureHost();
        }, { once: true });
      })()`,
    });
  } catch (error) {
    await releaseLock(lock);
    throw error;
  }

  return {
    stop: async () => {
      stopped = true;
      session.close();
      await releaseLock(lock);
    },
  };
}

if (
  process.argv[1] &&
  pathToFileURL(process.argv[1]).href === new URL(import.meta.url).href
) {
  const port = Number(process.argv[2]);
  let session;
  try {
    session = await openMainPageSession(port, defaultPage, true);
    const host = await attachWallpaperHost({ port, session });
    if (!host) process.exit(0);
    session.onClose(() => process.exit());
    console.log(JSON.stringify({ ready: true, pid: process.pid }));
  } catch {
    process.exitCode = 1;
    session?.close();
  }
}
