import assert from "node:assert/strict";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { prepareMp4VirtualLayout } from "./mp4-layout.mjs";

function box(type, payload = Buffer.alloc(0)) {
  const result = Buffer.alloc(8 + payload.length);
  result.writeUInt32BE(result.length, 0);
  result.write(type, 4, "latin1");
  payload.copy(result, 8);
  return result;
}

function stco(offset) {
  const payload = Buffer.concat([
    Buffer.from([0, 0, 0, 0]),
    Buffer.from([0, 0, 0, 1]),
    Buffer.alloc(4),
  ]);
  payload.writeUInt32BE(offset, 8);
  return box("stco", payload);
}

test("tail-moov chunk offsets are adjusted without copying media bytes", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "codex-wallpaper-mp4-"));
  const path = join(root, "tail.mp4");
  const mdat = box("mdat", Buffer.from([1, 2, 3, 4]));
  const moov = box(
    "moov",
    box("trak", box("mdia", box("minf", box("stbl", stco(8)))))
  );
  const file = Buffer.concat([box("ftyp"), mdat, moov]);
  const mdatStart = file.indexOf(mdat);
  const moovStart = file.indexOf(moov);
  await writeFile(path, file);
  t.after(() => rm(root, { recursive: true, force: true }));
  const layout = await prepareMp4VirtualLayout(path, file.length);
  assert.equal(layout.layout, "virtual");
  assert.equal(layout.size, file.length);
  assert.equal(layout.moovSize, moov.length);
  assert.equal(layout.offsetCount, 1);
  assert.equal(layout.segments.length, 3);
  assert.deepEqual(
    layout.segments.map(({ type }) => type),
    ["slice", "inline", "slice"]
  );
  const corrected = Buffer.from(layout.segments[1].data, "base64");
  assert.equal(
    corrected.readUInt32BE(corrected.length - 4),
    mdatStart + moov.length
  );
  assert.equal(
    layout.segments.reduce(
      (total, segment) =>
        total +
        (segment.type === "inline"
          ? Buffer.from(segment.data, "base64").length
          : 0),
      0
    ),
    moov.length
  );
});

test("front-moov file stays on the original single-slice layout", async (t) => {
  const root = await mkdtemp(join(tmpdir(), "codex-wallpaper-mp4-"));
  const path = join(root, "front.mp4");
  const moov = box(
    "moov",
    box("trak", box("mdia", box("minf", box("stbl", stco(0)))))
  );
  const file = Buffer.concat([
    box("ftyp"),
    moov,
    box("mdat", Buffer.from([1, 2, 3, 4])),
  ]);
  await writeFile(path, file);
  t.after(() => rm(root, { recursive: true, force: true }));
  assert.deepEqual(await prepareMp4VirtualLayout(path, file.length), {
    version: 1,
    size: file.length,
    layout: "original",
    moovSize: moov.length,
    offsetCount: 0,
    segments: [{ type: "slice", offset: 0, length: file.length }],
  });
});
