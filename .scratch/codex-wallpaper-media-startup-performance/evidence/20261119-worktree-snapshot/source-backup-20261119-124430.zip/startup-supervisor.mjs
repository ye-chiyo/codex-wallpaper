import {
  listPages,
  openMainPageSession,
  selectEndpoint,
} from "./read-only-probe.mjs";
import { payloadFor } from "./static-background.mjs";
import { runtimeSource } from "./client-runtime.mjs";
import { attachWallpaperHost } from "./wallpaper-host.mjs";

const port = Number(process.argv[2]);
const pageArgumentIndex = process.argv.indexOf("--page");
const page =
  pageArgumentIndex >= 0
    ? process.argv[pageArgumentIndex + 1]
    : "app://-/index.html";
const payloadArgumentIndex = process.argv.indexOf("--payload");
const payload =
  payloadArgumentIndex >= 0
    ? JSON.parse(process.argv[payloadArgumentIndex + 1])
    : null;

if (!Number.isInteger(port) || port < 1024 || port > 65535) {
  console.log(JSON.stringify({ state: "failed", error: "invalid-port" }));
  process.exit(1);
}

const targets = await listPages(port);
const endpoint = selectEndpoint(targets, port, page, true);
if (endpoint === null) {
  console.log(
    JSON.stringify({ state: "failed", error: "main-page-unavailable" })
  );
  process.exit(2);
}

const session = await openMainPageSession(port, page, true);
try {
  const frameTree = await session.send("Page.getFrameTree");
  if (frameTree.frameTree.frame.url !== page)
    throw new Error("Unexpected main page");
  const resolvedPayload = payload ?? (await payloadFor());
  const host = await attachWallpaperHost({
    port,
    session,
    page,
    payload: resolvedPayload,
  });
  if (!host) throw new Error("wallpaper-host-already-running");
  const source = runtimeSource(resolvedPayload);
  const evaluated = await session.send("Runtime.evaluate", {
    expression: source,
    returnByValue: true,
    awaitPromise: true,
  });
  const result = evaluated?.result?.value;
  result.hostPid = process.pid;
  console.log(JSON.stringify(result));
  session.onClose(() => process.exit());
} catch (error) {
  console.log(
    JSON.stringify({
      state: "failed",
      error: String(error?.message || error),
    })
  );
  process.exitCode = 1;
  session.close();
}
