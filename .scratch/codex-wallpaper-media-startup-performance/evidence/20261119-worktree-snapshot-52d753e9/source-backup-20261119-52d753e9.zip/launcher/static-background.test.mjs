import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { createServer } from "node:http";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { once } from "node:events";
import test from "node:test";
import { candidateIdentity } from "./client-runtime.mjs";
import { applyStaticBackground, evaluateInPage } from "./static-background.mjs";
import { callMainPage, openMainPageSession } from "./read-only-probe.mjs";

const edge =
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";
const rootId = "codex-wallpaper-p1";
const controlRootId = "codex-wallpaper-p1-controls";
const tinyMp4 =
  "AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAN0bW9vdgAAAGxtdmhkAAAAAAAAAAAAAAAAAAAD6AAAA+gAAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAp90cmFrAAAAXHRraGQAAAADAAAAAAAAAAAAAAABAAAAAAAAA+gAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAABAAAAAQAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAAPoAAAQAAABAAAAAAIXbWRpYQAAACBtZGhkAAAAAAAAAAAAAAAAAAAoAAAAKABVxAAAAAAALWhkbHIAAAAAAAAAAHZpZGUAAAAAAAAAAAAAAABWaWRlb0hhbmRsZXIAAAABwm1pbmYAAAAUdm1oZAAAAAEAAAAAAAAAAAAAACRkaW5mAAAAHGRyZWYAAAAAAAAAAQAAAAx1cmwgAAAAAQAAAYJzdGJsAAAAvnN0c2QAAAAAAAAAAQAAAK5hdmMxAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAABAAEABIAAAASAAAAAAAAAABFExhdmM2My4xLjEwMiBsaWJ4MjY0AAAAAAAAAAAAAAAAGP//AAAANGF2Y0MBZAAK/+EAF2dkAAqs2V7ARAAAAwAEAAADACg8SJZYAQAGaOvjyyLA/fj4AAAAABBwYXNwAAAAAQAAAAEAAAAUYnRydAAAAAAAABegAAAAAAAAABhzdHRzAAAAAAAAAAEAAAAFAAAIAAAAABRzdHNzAAAAAAAAAAEAAAABAAAAOGN0dHMAAAAAAAAABQAAAAEAABAAAAAAAQAAKAAAAAABAAAQAAAAAAEAAAAAAAAAAQAACAAAAAAcc3RzYwAAAAAAAAABAAAAAQAAAAUAAAABAAAAKHN0c3oAAAAAAAAAAAAAAAUAAALEAAAADAAAAAwAAAAMAAAADAAAABRzdGNvAAAAAAAAAAEAAAOkAAAAYXVkdGEAAABZbWV0YQAAAAAAAAAhaGRscgAAAAAAAAAAbWRpcmFwcGwAAAAAAAAAAAAAAAAsaWxzdAAAACSpdG9vAAAAHGRhdGEAAAABAAAAAExhdmY2My4xLjEwMgAAAAhmcmVlAAAC/G1kYXQAAAKtBgX//6ncRem95tlIt5Ys2CDZI+7veDI2NCAtIGNvcmUgMTY1IHIzMjIzIDA0ODBjYjAgLSBILjI2NC9NUEVHLTQgQVZDIGNvZGVjIC0gQ29weWxlZnQgMjAwMy0yMDI1IC0gaHR0cDovL3d3dy52aWRlb2xhbi5vcmcveDI2NC5odG1sIC0gb3B0aW9uczogY2FiYWM9MSByZWY9MyBkZWJsb2NrPTE6MDowIGFuYWx5c2U9MHgzOjB4MTEzIG1lPWhleCBzdWJtZT03IHBzeT0xIHBzeV9yZD0xLjAwOjAuMDAgbWl4ZWRfcmVmPTEgbWVfcmFuZ2U9MTYgY2hyb21hX21lPTEgdHJlbGxpcz0xIDh4OGRjdD0xIGNxbT0wIGRlYWR6b25lPTIxLDExIGZhc3RfcHNraXA9MSBjaHJvbWFfcXBfb2Zmc2V0PS0yIHRocmVhZHM9MSBsb29rYWhlYWRfdGhyZWFkcz0xIHNsaWNlZF90aHJlYWRzPTAgbnI9MCBkZWNpbWF0ZT0xIGludGVybGFjZWQ9MCBibHVyYXlfY29tcGF0PTAgY29uc3RyYWluZWRfaW50cmE9MCBiZnJhbWVzPTMgYl9weXJhbWlkPTIgYl9hZGFwdD0xIGJfYmlhcz0wIGRpcmVjdD0xIHdlaWdodGI9MSBvcGVuX2dvcD0wIHdlaWdodHA9MiBrZXlpbnQ9MjUwIGtleWludF9taW49NSBzY2VuZWN1dD00MCBpbnRyYV9yZWZyZXNoPTAgcmNfbG9va2FoZWFkPTQwIHJjPWNyZiBtYnRyZWU9MSBjcmY9MjMuMCBxY29tcD0wLjYwIHFwbWluPTAgcXBtYXg9NjkgcXBzdGVwPTQgaXBfcmF0aW89MS40MCBhcT0xOjEuMDAAgAAAAA9liIQAEv/+963fgU3DKz0AAAAIQZokbEP//uAAAAAIQZ5CeIIfq4EAAAAIAZ5hdEP/s4AAAAAIAZ5jakP/s4E=";

function encodeWebSocketText(value) {
  const body = Buffer.from(value);
  if (body.length < 126)
    return Buffer.concat([Buffer.from([0x81, body.length]), body]);
  const header = Buffer.alloc(4);
  header[0] = 0x81;
  header[1] = 126;
  header.writeUInt16BE(body.length, 2);
  return Buffer.concat([header, body]);
}

function takeWebSocketText(buffer) {
  if (buffer.length < 2) return null;
  const opcode = buffer[0] & 15;
  let length = buffer[1] & 127;
  let offset = 2;
  if (length === 126) {
    if (buffer.length < 4) return null;
    length = buffer.readUInt16BE(2);
    offset = 4;
  } else if (length === 127) {
    if (buffer.length < 10) return null;
    length = Number(buffer.readBigUInt64BE(2));
    offset = 10;
  }
  const masked = (buffer[1] & 128) !== 0;
  const maskOffset = offset;
  if (masked) offset += 4;
  const total = offset + length;
  if (buffer.length < total) return null;
  const mask = masked ? buffer.subarray(maskOffset, maskOffset + 4) : null;
  const payload = Buffer.from(buffer.subarray(offset, total));
  if (mask)
    payload.forEach((byte, index) => (payload[index] = byte ^ mask[index % 4]));
  return { opcode, text: payload.toString(), rest: buffer.subarray(total) };
}

async function startExactCdpFixture(t, evaluate = null) {
  const id = "0123456789abcdef0123456789abcdef";
  const requests = [];
  const sockets = new Set();
  let hostSocket = null;
  function requestHost(type, id) {
    return (
      hostSocket?.write(
        encodeWebSocketText(
          JSON.stringify({
            method: "Runtime.bindingCalled",
            params: {
              name: "__codexWallpaperHostRequest",
              payload: JSON.stringify({ type, id }),
            },
          })
        )
      ) ?? false
    );
  }
  const server = createServer((request, response) => {
    assert.equal(request.url, "/json/list");
    response.end(
      JSON.stringify([
        {
          id,
          type: "page",
          url: "app://-/index.html",
          webSocketDebuggerUrl: `ws://127.0.0.1:${server.address().port}/devtools/page/${id}`,
        },
      ])
    );
  });
  server.on("connection", (socket) => {
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
  });
  server.on("upgrade", (request, socket) => {
    const accept = createHash("sha1")
      .update(
        request.headers["sec-websocket-key"] +
          "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
      )
      .digest("base64");
    socket.write(
      `HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`
    );
    let incoming = Buffer.alloc(0);
    socket.on("data", (chunk) => {
      incoming = Buffer.concat([incoming, chunk]);
      let frame = takeWebSocketText(incoming);
      while (frame && frame.opcode === 1) {
        incoming = frame.rest;
        const command = JSON.parse(frame.text);
        requests.push(command);
        let result = {};
        if (command.method === "Runtime.evaluate") {
          const value = evaluate
            ? evaluate(command.params.expression, requestHost)
            : command.params.expression.startsWith(
                  "globalThis.__codexWallpaperApi.beginAssetFileTransfer("
                )
              ? false
              : command.params.expression ===
                  "globalThis.__codexWallpaperApi.configureHost()"
                ? { state: "enabled", hostReady: true }
                : { state: "disabled", backgroundLayers: 0 };
          result = { result: { value } };
        }
        if (
          command.method === "DOM.getDocument" ||
          command.method === "DOM.querySelector"
        ) {
          result =
            command.method === "DOM.getDocument" ? { root: { nodeId: 1 } } : {};
        }
        if (command.method === "Runtime.addBinding") hostSocket = socket;
        socket.write(
          encodeWebSocketText(JSON.stringify({ id: command.id, result }))
        );
        frame = takeWebSocketText(incoming);
      }
    });
  });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  t.after(() => {
    for (const socket of sockets) socket.destroy();
    return new Promise((resolve) => server.close(resolve));
  });
  return {
    port: server.address().port,
    requests,
    requestHost,
    get hostConnected() {
      return Boolean(hostSocket);
    },
    stopHost() {
      requestHost("stop");
    },
  };
}

async function startHtmlFixture(html) {
  const server = createServer((_request, response) => {
    response.setHeader("Content-Type", "text/html; charset=utf-8");
    response.end(html);
  });
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  return {
    server,
    url: `http://127.0.0.1:${server.address().port}/`,
  };
}

async function startFixture() {
  return startHtmlFixture(
    `<!doctype html>
      <html data-theme="dark">
      <title>wallpaper fixture</title>
      <style>
        :root {
          --app-color-background-surface: rgb(24 24 28);
          --app-color-background-surface-under: rgb(12 12 16);
          --app-color-text-foreground: rgb(245 245 250);
          --color-codex-diff-added: rgb(55 180 105);
          --color-codex-diff-deleted: rgb(225 82 96);
          --color-text-secondary: rgb(255 255 255 / .65);
          --color-text-tertiary: rgb(255 255 255 / .5);
          color-scheme: dark;
        }
        :root[data-theme="light"] {
          --app-color-background-surface: rgb(247 247 249);
          --app-color-background-surface-under: rgb(232 232 237);
          --app-color-text-foreground: rgb(20 20 24);
          --color-codex-diff-added: rgb(20 135 70);
          --color-codex-diff-deleted: rgb(180 45 58);
          --color-text-secondary: rgb(0 0 0 / .65);
          --color-text-tertiary: rgb(0 0 0 / .5);
          color-scheme: light;
        }
        body { margin: 0; min-height: 1200px; color: rgb(245 245 250); }
        :root[data-theme="light"] body { color: rgb(20 20 24); }
        [data-app-shell-page-surface] { background: var(--app-color-background-surface); }
        [data-app-shell-main-surface] { min-height: 100vh; background: transparent; }
        [data-browser-sidebar-webview] { opacity: .001; }
        @layer host { [data-app-shell-titlebar] { position: fixed; top: 0; height: 36px; } }
        .muted-chrome { color: var(--color-text-tertiary); }
        [data-testid="webmcp-tool-scroll"], [data-summary-panel-variant] { display: block; padding: 8px; }
        #user-markdown-action { border: 0; background: transparent; }
        pre { padding: 12px; }
        [data-testid="diff-preview-scroll"] { display: block; padding: 24px; }
        #changes-panel [data-line-type] { display: block; min-height: 1lh; }
        #changes-panel [data-line-type="change-deletion"] { background-color: var(--diffs-bg-deletion, transparent); }
        #changes-panel [data-line-type="change-addition"] { background-color: var(--diffs-bg-addition, transparent); }
        [data-composer-surface-variant] { display: block; padding: 24px; background: var(--app-color-background-surface); }
        .thread-scroll-footer-shell::before { content: ""; background-image: linear-gradient(transparent, var(--app-color-background-surface)); }
        .thread-scroll-footer-shell::after { content: ""; background-color: var(--app-color-background-surface); }
        .thread-footer-backdrop { position: absolute; bottom: 0; width: 80%; height: 80px; background: var(--app-color-background-surface-under); pointer-events: none; }
      </style>
      <div data-app-shell-workspace-row>
        <div data-app-shell-page-surface data-app-shell-frame data-app-shell-page-sidebar>
          <div id="app-menu"><div role="menubar"><button class="muted-chrome">View</button></div></div>
          <div data-app-shell-main-surface>
            <main>
            <div data-app-shell-main-content-top-fade>
            <div id="thread-top-fade" aria-hidden="true" style="position: absolute; pointer-events: none; background-image: linear-gradient(var(--app-color-background-surface), transparent);"></div>
            <article id="message" data-markdown-text-style="assistant-message">
              <span>${"Long assistant response ".repeat(40)}</span>
              <p id="ordinary-status" class="bg-surface">Ordinary assistant status</p>
              <pre id="chat-code"><code>const chatCode = true;</code></pre>
            </article>
            <div id="user-message" data-user-message-bubble>
              User message
              <button id="user-markdown-action" class="rounded-md bg-transparent" type="button" aria-expanded="false">User markdown action</button>
            </div>
            <button id="open-changes" type="button">Open Changes</button>
            <div data-app-action-timeline-scroll>
            <div data-local-conversation-item-target-ids="fixture-activity-item">
              <div class="outline-none">
                <div class="min-w-0 text-size-chat relative overflow-visible py-0">
                  <div class="flex min-w-0 flex-col">
                    <div id="ordinary-activity-header" class="group/activity-header relative inline-flex min-w-0 max-w-full self-start items-center gap-1 p-0 text-start">
                      <button id="ordinary-activity-action" class="absolute inset-0 cursor-interaction rounded-md bg-transparent focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-0 focus-visible:outline-none focus-visible:ring-inset" type="button" aria-expanded="false">Toggle activity</button>
                      <span id="ordinary-activity-icon" aria-hidden="true">◆</span>
                      <span class="inline-flex min-w-0 gap-2 items-center shrink truncate text-size-chat pointer-events-none relative">
                        <span class="min-w-0 flex-1 truncate">
                          <span id="ordinary-activity-text" class="block min-w-0 max-w-full flex-1 truncate">${"Long ordinary execution explanation ".repeat(18)}</span>
                        </span>
                      </span>
                      <span aria-hidden="true">›</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <section data-testid="webmcp-tool-scroll" class="bg-surface">
              <button id="tool-action" class="rounded-md bg-transparent" type="button" aria-expanded="false">Toggle tool</button>
              <div id="tool-details">Tool details</div>
            </section>
            <div data-turn-key="fixture-tool-turn">
              <div>
                <div>
                  <div data-local-conversation-item-target-ids="fixture-tool-item">
                    <div>
                      <div>
                        <div>
                          <div id="legacy-tool-row" class="relative min-w-0 gap-1">
                            <button class="rounded-md bg-transparent" type="button" aria-expanded="false">Legacy timeline tool</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <section data-summary-panel-variant class="bg-surface">Summary row</section>
            <div class="thread-scroll-footer-shell">
            <div data-thread-scroll-footer>
              <div class="thread-footer-backdrop bg-surface"></div>
              <div data-pip-obstacle="thread-footer-leading" class="bg-surface thread-footer-leading">Leading footer content</div>
              <div data-thread-composer-backdrop>
                <form class="bg-surface" data-composer-surface-variant="inline">
                  <textarea id="composer">Composer text</textarea>
                </form>
              </div>
            </div>
            </div>
            </div>
            </div>
            </main>
            <header data-app-shell-titlebar>Chat toolbar</header>
          </div>
        </div>
        <aside data-app-shell-trailing-sidebar hidden><div class="h-full min-w-0"><header><div role="tablist" aria-label="Workspace panels"><button id="changes-tab" role="tab" aria-selected="true">Changes</button><button id="files-tab" role="tab" aria-selected="false">Files</button></div><button id="close-changes" type="button">Close</button></header><section id="files-panel" hidden><file-tree-container>src</file-tree-container></section><section id="changes-panel" data-testid="diff-preview-scroll" data-thread-find-target="review"><div class="composer-diff-simple-line"><pre><code id="code"><span id="deletion-line" data-line-type="change-deletion" aria-label="Deleted line"></span><span id="addition-line" data-line-type="change-addition" aria-label="Added line"></span>const visible = true;</code></pre></div></section></div></aside>
      </div>
      <aside data-app-shell-page-sidebar>
        <nav data-app-navigation-rail><button data-sidebar-destination class="muted-chrome">Home</button></nav>
        <div data-slate-sidebar-content><button id="project-action" class="muted-chrome">Project</button></div>
      </aside>
      <div data-app-shell-pane-content-viewport><pre id="editor">editor</pre></div>
      <div data-browser-sidebar-webview hidden><webview></webview></div>
      <section role="dialog" id="settings-dialog"><button id="dialog-action">Dialog</button></section>
      </html>
      <script>
        const sidebar = document.querySelector('[data-app-shell-trailing-sidebar]');
        document.querySelector('#open-changes').addEventListener('click', () => { sidebar.hidden = false; });
        document.querySelector('#close-changes').addEventListener('click', () => { sidebar.hidden = true; });
        const changesTab = document.querySelector('#changes-tab');
        const filesTab = document.querySelector('#files-tab');
        const changesPanel = document.querySelector('#changes-panel');
        const filesPanel = document.querySelector('#files-panel');
        const selectPanel = (changes) => {
          changesTab.setAttribute('aria-selected', String(changes));
          filesTab.setAttribute('aria-selected', String(!changes));
          changesPanel.hidden = !changes;
          filesPanel.hidden = changes;
        };
        changesTab.addEventListener('click', () => selectPanel(true));
        filesTab.addEventListener('click', () => selectPanel(false));
      </script>`
  );
}

async function startChromeFixture() {
  return startHtmlFixture(
    `<!doctype html>
      <html data-theme="dark">
      <title>Codex window chrome fixture</title>
      <style>
        :root {
          --app-color-background-surface: rgb(24 24 28);
          --app-color-background-surface-under: rgb(12 12 16);
          --app-color-text-foreground: rgb(245 245 250);
          --color-text-secondary: rgb(255 255 255 / .65);
          --color-text-tertiary: rgb(255 255 255 / .5);
          color-scheme: dark;
        }
        :root[data-theme="light"] {
          --app-color-background-surface: rgb(247 247 249);
          --app-color-background-surface-under: rgb(232 232 237);
          --app-color-text-foreground: rgb(20 20 24);
          --color-text-secondary: rgb(0 0 0 / .65);
          --color-text-tertiary: rgb(0 0 0 / .5);
          color-scheme: light;
        }
        body { margin: 0; height: 100vh; background: rgb(70 30 90); color: var(--app-color-text-foreground); }
        [data-app-shell-workspace-row] {
          height: 100vh;
        }
        [data-app-shell-frame] {
          position: relative;
          display: grid;
          grid-template-columns: 52px 188px minmax(0, 1fr);
          width: 100%;
          height: 100%;
          min-height: 0;
          padding-top: 36px;
          box-sizing: border-box;
          background: var(--app-color-background-surface);
        }
        #app-menu { position: absolute; inset: 0 0 auto; z-index: 30; height: 36px; }
        [data-app-navigation-rail], [data-slate-sidebar-content] {
          padding: 12px 8px;
        }
        [data-app-navigation-rail] { grid-column: 1; grid-row: 1; }
        [data-slate-sidebar-content] { grid-column: 2; grid-row: 1; }
        [data-app-shell-main-surface] {
          grid-column: 3;
          grid-row: 1;
          min-width: 0;
          background: var(--app-color-background-surface);
        }
        .content { padding: 72px 24px 24px; }
        .muted-chrome { color: var(--color-text-tertiary); }
        @layer host {
          [data-app-shell-titlebar] {
            position: fixed;
            top: 36px;
            right: 0;
            left: 240px;
            z-index: 30;
            display: flex;
            align-items: center;
            gap: 8px;
            height: 52px;
            padding: 0 12px;
            pointer-events: none;
            -webkit-app-region: drag;
          }
          [data-app-shell-titlebar] button {
            position: relative;
            pointer-events: auto;
            -webkit-app-region: no-drag;
          }
        }
        [role="menu"] { position: absolute; top: 36px; left: 12px; padding: 6px; }
        [hidden] { display: none !important; }
      </style>
      <div data-app-shell-workspace-row>
        <div data-app-shell-frame data-app-shell-page-surface data-app-shell-page-sidebar>
          <div id="app-menu">
            <div role="menubar"><button id="view-menu" class="muted-chrome">View</button></div>
            <div id="view-options" role="menu" hidden>View options</div>
          </div>
          <nav data-app-navigation-rail><button id="home-action" class="muted-chrome">Home</button></nav>
          <div data-slate-sidebar-content><button id="project-action" class="muted-chrome">Project</button></div>
          <main data-app-shell-main-surface>
            <div class="content">Chat canvas</div>
          </main>
          <header data-app-shell-titlebar>
            <button id="chat-title">Current chat</button>
          </header>
        </div>
      </div>
      <script>
        document.querySelector("#view-menu").addEventListener("click", () => {
          document.querySelector("#view-options").hidden = false;
        });
        document.querySelector("#chat-title").addEventListener("click", (event) => {
          event.currentTarget.dataset.clicked = "true";
          document.querySelector("#view-options").hidden = true;
        });
      </script>
      </html>`
  );
}

async function waitForPort(profile) {
  const file = join(profile, "DevToolsActivePort");
  for (let attempt = 0; attempt < 100; attempt += 1) {
    try {
      const [port] = (await readFile(file, "utf8")).trim().split(/\r?\n/);
      return Number(port);
    } catch {
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  }
  throw new Error("Edge did not expose CDP");
}

async function waitForPage(port, options) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const href = await evaluateInPage(port, "location.href", options);
    if (href === options.page) return;
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error("Edge did not load the fixture page");
}

async function startBrowserFixture(t, fixture = null) {
  fixture ??= await startFixture();
  const profile = await mkdtemp(join(tmpdir(), "codex-wallpaper-edge-"));
  const browser = spawn(
    edge,
    [
      "--headless=new",
      "--disable-background-networking",
      "--disable-component-update",
      "--no-first-run",
      "--no-proxy-server",
      "--remote-debugging-port=0",
      `--user-data-dir=${profile}`,
      fixture.url,
    ],
    { stdio: "ignore" }
  );
  t.after(async () => {
    await new Promise((resolve) => {
      if (browser.exitCode !== null) resolve();
      else {
        browser.once("exit", resolve);
        browser.kill();
      }
    });
    await new Promise((resolve) => fixture.server.close(resolve));
    await rm(profile, {
      recursive: true,
      force: true,
      maxRetries: 10,
      retryDelay: 100,
    });
  });
  return { fixture, port: await waitForPort(profile) };
}

async function clickAtElementCenter(port, options, selector) {
  const target = await evaluateInPage(
    port,
    `(() => {
      const control = document.querySelector(${JSON.stringify(selector)});
      const rect = control.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      const hit = document.elementFromPoint(x, y);
      return { x, y, receivesClick: hit === control || control.contains(hit) };
    })()`,
    options
  );
  for (const type of ["mousePressed", "mouseReleased"]) {
    await callMainPage(
      port,
      "Input.dispatchMouseEvent",
      { type, x: target.x, y: target.y, button: "left", clickCount: 1 },
      options.page,
      true
    );
  }
  return target.receivesClick;
}

test("window chrome keeps wallpaper sharp and native titlebar interactive", async (t) => {
  const fixture = await startChromeFixture();
  const { port } = await startBrowserFixture(t, fixture);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: { version: 1, library: [] },
  };
  const readTitlebar = `(() => {
    const bar = document.querySelector("[data-app-shell-titlebar]");
    const style = getComputedStyle(bar);
    return [style.position, style.zIndex, style.getPropertyValue("-webkit-app-region"),
      getComputedStyle(bar.firstElementChild).getPropertyValue("-webkit-app-region"),
      bar.getBoundingClientRect().toJSON()];
  })()`;
  await waitForPage(port, options);
  const nativeTitlebar = await evaluateInPage(port, readTitlebar, options);
  await applyStaticBackground(port, options);
  assert.deepEqual(
    await evaluateInPage(
      port,
      "globalThis.__codexWallpaperApi.identity()",
      options
    ),
    candidateIdentity()
  );
  assert.deepEqual(
    await evaluateInPage(port, readTitlebar, options),
    nativeTitlebar
  );

  await clickAtElementCenter(port, options, "#view-menu");
  assert.equal(
    await evaluateInPage(
      port,
      '!document.querySelector("#view-options").hidden',
      options
    ),
    true
  );
  await clickAtElementCenter(port, options, "#chat-title");
  assert.equal(
    await evaluateInPage(
      port,
      'document.querySelector("#chat-title").dataset.clicked === "true"',
      options
    ),
    true
  );

  const chrome = await evaluateInPage(
    port,
    `(() => {
    const frame = document.querySelector("[data-app-shell-frame]");
    const surrounds = frame.querySelectorAll(
      "#app-menu, [data-app-shell-titlebar], [data-app-navigation-rail], [data-slate-sidebar-content]"
    );
    const alphaOf = (color) => color === "rgba(0, 0, 0, 0)"
      ? 0
      : Number(color.match(/\\/\\s*([\\d.]+)\\s*\\)/)?.[1] ?? 1);
    function sample(theme) {
      document.documentElement.dataset.theme = theme;
      const paint = getComputedStyle(frame).backgroundColor;
      const alpha = alphaOf(paint);
      return {
        paint,
        wallpaperThroughFrame: alpha > 0 && alpha < 1,
        noOverpaint: [...surrounds].every(element => {
          const style = getComputedStyle(element);
          return alphaOf(style.backgroundColor) === 0 &&
            style.backdropFilter === "none";
        })
      };
    }
    return ["dark", "light"].map(sample);
  })()`,
    options
  );
  assert.notEqual(
    chrome[0].paint,
    chrome[1].paint,
    "material follows the host theme"
  );
  assert.ok(
    chrome.every(
      ({ wallpaperThroughFrame, noOverpaint }) =>
        wallpaperThroughFrame && noOverpaint
    ),
    "shared tint stays translucent and sharp"
  );
});

test("file transfer is released after cancellation and plays a staged file-backed video", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-file-video",
          title: "Fixture File Video",
          type: "video",
          playable: false,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl: null,
          webHtml: null,
          reason: "on-demand",
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `(() => {
      localStorage.setItem("codex-wallpaper-p1-config", JSON.stringify({
        enabled: true, active: {kind:"workshop",id:"fixture-file-video"},
        favorites: [], playlist: [], settings: {fps: 30, volume: 0}
      }));
    })()`,
    options
  );
  await applyStaticBackground(port, options);
  const result = await evaluateInPage(
    port,
    `(async () => {
      const api = globalThis.__codexWallpaperApi;
      const token = api.beginAssetFileTransfer({
        id: "fixture-file-video",
        title: "Fixture File Video",
        type: "video",
        playable: false,
        previewDataUrl: null,
        webHtml: null,
        reason: "on-demand",
        mime: "video/mp4",
        size: ${Buffer.from(tinyMp4, "base64").length}
      }, null);
      if (!token) throw new Error("File transfer token was rejected");
      const input = document.querySelector(
        \`input[data-codex-wallpaper-file="\${token}"]\`
      );
      api.cancelAssetFileTransfer(token);
      const cancelResult = await api.finishAssetFileTransfer(token).catch(() => false);
      const token2 = api.beginAssetFileTransfer({
        id: "fixture-file-video",
        title: "Fixture File Video",
        type: "video",
        playable: false,
        previewDataUrl: null,
        webHtml: null,
        reason: "on-demand",
        mime: "video/mp4",
        size: ${Buffer.from(tinyMp4, "base64").length}
      }, null);
      const activeInput = document.querySelector(
        \`input[data-codex-wallpaper-file="\${token2}"]\`
      );
      const file = new File(
        [Uint8Array.from(atob(${JSON.stringify(tinyMp4)}), (char) => char.charCodeAt(0))],
        "Fixture File.mp4",
        { type: "video/mp4" }
      );
      const transfer = new DataTransfer();
      transfer.items.add(file);
      activeInput.files = transfer.files;
      activeInput.dispatchEvent(new Event("change", { bubbles: true }));
      await api.finishAssetFileTransfer(token2);
      for (let attempt = 0; attempt < 80; attempt += 1) {
        const video = document.querySelector("#${rootId} .media:not(.staged) video");
        if (video?.readyState >= 2 && video.src.startsWith("blob:")) break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      const video = document.querySelector("#${rootId} .media:not(.staged) video");
      return {
        hadInput: Boolean(input),
        canceledInputGone: !document.contains(input),
        canceledFinish: cancelResult === false,
        blobVideo: video?.src.startsWith("blob:") ?? false,
        playerCount: api.state().playerCount,
        staged: document.querySelectorAll("#${rootId} .media.staged").length
      };
    })()`,
    options
  );
  assert.deepEqual(result, {
    hadInput: true,
    canceledInputGone: true,
    canceledFinish: true,
    blobVideo: true,
    playerCount: 1,
    staged: 0,
  });
});

test("hovering one video card warms metadata once without playing it", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "warm-video",
          title: "Warm Video",
          type: "video",
          playable: true,
          fallback: false,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          assetDataUrl: null,
          webHtml: null,
          reason: null,
        },
      ],
    },
  };
  await waitForPage(port, options);
  await applyStaticBackground(port, options);
  const result = await evaluateInPage(
    port,
    `(async () => {
      document.querySelector(
        "#${controlRootId} [data-codex-wallpaper-settings]"
      ).click();
      const card = document.querySelector("[data-entry-id='warm-video']");
      const originalPlay = HTMLMediaElement.prototype.play;
      let playCalls = 0;
      HTMLMediaElement.prototype.play = () => {
        playCalls += 1;
        return Promise.resolve();
      };
      const requests = [];
      globalThis.__codexWallpaperHostRequest = (raw) => {
        requests.push(JSON.parse(raw));
      };
      card.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
      const request = requests.find((item) => item.type === "warm-asset");
      const api = globalThis.__codexWallpaperApi;
      const token = api.beginAssetFileTransfer(
        {
          id: "warm-video",
          title: "Warm Video",
          type: "video",
          mime: "video/mp4",
          size: ${Buffer.from(tinyMp4, "base64").length},
        },
        null,
        true
      );
      const input = document.querySelector(
        \`input[data-codex-wallpaper-file="\${token}"]\`
      );
      const file = new File(
        [Uint8Array.from(atob(${JSON.stringify(tinyMp4)}), (char) => char.charCodeAt(0))],
        "Warm Video.mp4",
        { type: "video/mp4" }
      );
      const transfer = new DataTransfer();
      transfer.items.add(file);
      input.files = transfer.files;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      await api.finishAssetFileTransfer(token);
      const warm = document.querySelector("video[data-codex-wallpaper-warm]");
      const first = warm?.dataset.codexWallpaperWarm;
      card.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
      const videos = [...document.querySelectorAll("video[data-codex-wallpaper-warm]")];
      await globalThis.__codexWallpaperApi.disable();
      HTMLMediaElement.prototype.play = originalPlay;
      return {
        requested: request?.id === "warm-video",
        warmed: first === "warm-video",
        warmCount: videos.length,
        playCalls,
        playerCount: globalThis.__codexWallpaperApi.state().playerCount,
        afterDisable: document.querySelectorAll(
          "video[data-codex-wallpaper-warm]"
        ).length,
      };
    })()`,
    options
  );
  assert.deepEqual(result, {
    requested: true,
    warmed: true,
    warmCount: 1,
    playCalls: 0,
    playerCount: 0,
    afterDisable: 0,
  });
});

test("real CDP file input delivers a video without a Base64 page transfer", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "cdp-file-video",
          title: "CDP File Video",
          type: "video",
          playable: false,
          fallback: true,
          previewDataUrl: null,
          assetDataUrl: null,
          webHtml: null,
          reason: "on-demand",
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `(() => {
      localStorage.setItem("codex-wallpaper-p1-config", JSON.stringify({
        enabled: true, active: {kind:"workshop",id:"cdp-file-video"},
        favorites: [], playlist: [], settings: {fps: 30, volume: 0}
      }));
    })()`,
    options
  );
  await applyStaticBackground(port, options);
  const path = join(tmpdir(), "codex-wallpaper-cdp-file.mp4");
  await writeFile(path, Buffer.from(tinyMp4, "base64"));
  t.after(() => rm(path, { force: true }));
  const session = await openMainPageSession(port, options.page, true);
  t.after(() => session.close());
  const size = Buffer.from(tinyMp4, "base64").length;
  const token = (
    await session.send("Runtime.evaluate", {
      expression: `globalThis.__codexWallpaperApi.beginAssetFileTransfer(${JSON.stringify(
        {
          id: "cdp-file-video",
          title: "CDP File Video",
          type: "video",
          playable: false,
          fallback: true,
          previewDataUrl: null,
          assetDataUrl: null,
          webHtml: null,
          reason: "on-demand",
          mime: "video/mp4",
          size,
        }
      )}, null)`,
      returnByValue: true,
      awaitPromise: true,
    })
  ).result.value;
  const document = await session.send("DOM.getDocument");
  const input = await session.send("DOM.querySelector", {
    nodeId: document.result?.rootId ?? document.root.nodeId,
    selector: `input[data-codex-wallpaper-file="${token}"]`,
  });
  await session.send("DOM.setFileInputFiles", {
    files: [path],
    nodeId: input.nodeId,
  });
  await session.send("Runtime.evaluate", {
    expression: `globalThis.__codexWallpaperApi.finishAssetFileTransfer(${JSON.stringify(
      String(token)
    )})`,
    returnByValue: true,
    awaitPromise: true,
  });
  const result = await evaluateInPage(
    port,
    `(async () => {
      const api = globalThis.__codexWallpaperApi;
      for (let attempt = 0; attempt < 80; attempt += 1) {
        const video = document.querySelector("#${rootId} .media:not(.staged) video");
        if (video?.readyState >= 2 && video.src.startsWith("blob:")) break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      const video = document.querySelector("#${rootId} .media:not(.staged) video");
      return {
        blobVideo: video?.src.startsWith("blob:") ?? false,
        playerCount: api.state().playerCount,
        staged: document.querySelectorAll("#${rootId} .media.staged").length,
        temporaryInputs: document.querySelectorAll(
          "input[type='file'][hidden]"
        ).length,
      };
    })()`,
    options
  );
  assert.deepEqual(result, {
    blobVideo: true,
    playerCount: 1,
    staged: 0,
    temporaryInputs: 0,
  });
});

test("persisted-disabled CLI starts the real host before a later enable", async (t) => {
  const fixture = await startExactCdpFixture(t);
  const child = spawn(
    process.execPath,
    [
      "--no-use-env-proxy",
      "launcher/static-background.mjs",
      String(fixture.port),
    ],
    { stdio: ["ignore", "pipe", "pipe"] }
  );
  let stdout = "";
  let stderr = "";
  child.stdout.setEncoding("utf8");
  child.stderr.setEncoding("utf8");
  child.stderr.on("data", (chunk) => (stderr += chunk));
  const result = await new Promise((resolve, reject) => {
    const deadline = setTimeout(
      () => reject(new Error(`CLI timed out: ${stderr || stdout}`)),
      10_000
    );
    child.stdout.on("data", (chunk) => {
      stdout += chunk;
      try {
        const value = JSON.parse(stdout.trim().split(/\r?\n/).at(-1));
        clearTimeout(deadline);
        resolve(value);
      } catch {}
    });
    child.once("error", reject);
  });
  assert.equal(result.state, "enabled");
  assert.equal(result.hostReady, true);
  assert.equal(Number.isInteger(result.bridgePid), true);
  assert.ok(
    fixture.requests.some((request) => request.method === "Runtime.enable")
  );
  assert.ok(
    fixture.requests.some((request) => request.method === "Runtime.addBinding")
  );
  assert.ok(
    fixture.requests.some(
      (request) =>
        request.params?.expression ===
        "globalThis.__codexWallpaperApi.configureHost()"
    )
  );
  fixture.stopHost();
  child.kill();
});

test(
  "host delivers a requested replacement after a discarded transfer",
  { timeout: 15000 },
  async (t) => {
    const steamRoot = await mkdtemp(
      join(tmpdir(), "codex-wallpaper-transfer-")
    );
    const videoId = "9999999999999";
    const distribution = join(
      steamRoot,
      "steamapps",
      "common",
      "wallpaper_engine",
      "distribution"
    );
    const project = join(
      steamRoot,
      "steamapps",
      "workshop",
      "content",
      "431960",
      videoId
    );
    t.after(() => rm(steamRoot, { recursive: true, force: true }));
    await mkdir(distribution, { recursive: true });
    await mkdir(project, { recursive: true });
    await writeFile(join(distribution, "version.json"), "{}");
    await writeFile(
      join(project, "project.json"),
      JSON.stringify({
        type: "video",
        title: "Transfer fixture",
        file: "clip.mp4",
      })
    );
    await writeFile(join(project, "clip.mp4"), Buffer.from(tinyMp4, "base64"));
    const calls = [];
    const finished = Promise.withResolvers();
    const fixture = await startExactCdpFixture(t, (expression, requestHost) => {
      if (
        expression.startsWith(
          "globalThis.__codexWallpaperApi.beginAssetTransfer("
        )
      )
        calls.push("begin");
      if (
        expression.startsWith(
          "globalThis.__codexWallpaperApi.appendAssetTransferChunk("
        )
      ) {
        calls.push("chunk");
        if (calls.length === 2) {
          // The page disabled and re-enabled while the old host request was in flight.
          requestHost("load-asset", videoId);
          return false;
        }
      }
      if (
        expression.startsWith(
          "globalThis.__codexWallpaperApi.finishAssetTransfer("
        )
      ) {
        calls.push("finish");
        finished.resolve();
      }
      if (
        expression.startsWith(
          "globalThis.__codexWallpaperApi?.receiveAssetError("
        )
      )
        finished.reject(
          new Error(`Host rejected the test wallpaper: ${expression}`)
        );
      return true;
    });
    const child = spawn(
      process.execPath,
      [
        "--no-use-env-proxy",
        "launcher/wallpaper-host.mjs",
        String(fixture.port),
      ],
      {
        env: { ...process.env, DSH_WE_STEAM_ROOT: steamRoot },
        stdio: ["ignore", "pipe", "pipe"],
      }
    );
    let stderr = "";
    child.stderr.setEncoding("utf8");
    child.stderr.on("data", (chunk) => (stderr += chunk));
    const exited = once(child, "exit");
    t.after(async () => {
      fixture.stopHost();
      if (child.exitCode === null) child.kill();
      await exited;
    });
    await once(child.stdout, "data");
    const requestSent = fixture.requestHost("load-asset", videoId);
    let deadline;
    const outcome = await Promise.race([
      finished.promise.then(() => ({ finished: true })),
      new Promise((resolve) => {
        deadline = setTimeout(() => resolve({ finished: false }), 5000);
      }),
    ]);
    clearTimeout(deadline);
    assert.ok(
      outcome.finished,
      JSON.stringify({
        calls,
        stderr,
        exitCode: child.exitCode,
        hostConnected: fixture.hostConnected,
        requestSent,
        commands: fixture.requests.map((command) => command.method),
      })
    );
    assert.deepEqual(calls, ["begin", "chunk", "begin", "chunk", "finish"]);
  }
);

test("reenabling during a video transfer discards the old stream and accepts its replacement", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        { id: "fixture-video", title: "Transfer fixture", type: "video" },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `(() => {
    localStorage.setItem("codex-wallpaper-p1-config", JSON.stringify({
      enabled: true, active: {kind:"workshop",id:"fixture-video"}
    }));
    globalThis.__fixtureAssetRequests = 0;
    globalThis.__codexWallpaperHostRequest = (raw) => {
      if (JSON.parse(raw).type === "load-asset") globalThis.__fixtureAssetRequests++;
    };
  })()`,
    options
  );
  await applyStaticBackground(port, options);
  const result = await evaluateInPage(
    port,
    `(async () => {
    const api = globalThis.__codexWallpaperApi;
    const data = ${JSON.stringify(tinyMp4)};
    const entry = { id:"fixture-video",title:"Transfer fixture",type:"video",mime:"video/mp4",size:atob(data).length };
    api.beginAssetTransfer(entry);
    await api.disable();
    const disabled = !document.querySelector("#${rootId}");
    await api.enable();
    const chunkRejected = api.appendAssetTransferChunk(entry.id, data) === false;
    const finishRejected = await api.finishAssetTransfer(entry.id) === false;
    api.beginAssetTransfer(entry);
    api.appendAssetTransferChunk(entry.id, data);
    await api.finishAssetTransfer(entry.id);
    for (let i=0;i<40&&!document.querySelector("#${rootId} .media:not(.staged) video");i++)
      await new Promise(resolve => setTimeout(resolve, 25));
    return {
      disabled, chunkRejected, finishRejected, requests: globalThis.__fixtureAssetRequests,
      player: !!document.querySelector("#${rootId} .media:not(.staged) video"),
      staged: document.querySelectorAll("#${rootId} .media.staged").length
    };
  })()`,
    options
  );
  assert.deepEqual(result, {
    disabled: true,
    chunkRejected: true,
    finishRejected: true,
    requests: 2,
    player: true,
    staged: 0,
  });
});

test("failed first video shows its preview instead of a blank background", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-broken-video",
          title: "Fixture Broken Video",
          type: "video",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%23fb923c'/%3E%3C/svg%3E",
          assetDataUrl: "data:video/mp4;base64,AA==",
          reason: "video-preview-fallback",
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `localStorage.setItem(
      "codex-wallpaper-p1-config",
      JSON.stringify({
        enabled: true,
        active: { kind: "workshop", id: "fixture-broken-video" },
        favorites: [],
        playlist: [],
        settings: {
          dim: 18,
          blur: 0,
          opacity: 100,
          fps: 30,
          volume: 0,
          rotationMinutes: 0
        }
      })
    )`,
    options
  );
  assert.equal((await applyStaticBackground(port, options)).state, "enabled");
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        for (let attempt = 0; attempt < 80; attempt += 1) {
          const image = root.querySelector(".media:not(.staged) img");
          if (image?.complete && image.naturalWidth > 0) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const media = root.querySelector(".media:not(.staged)");
        return {
          previewShown: media
            ?.querySelector("img")
            ?.src.includes("fb923c"),
          mediaCount: root.querySelectorAll(".media:not(.staged)").length,
          playerCount: globalThis.__codexWallpaperApi.state().playerCount,
          status: controls.querySelector(".runtime-status")?.textContent
        };
      })()`,
      options
    ),
    {
      previewShown: true,
      mediaCount: 1,
      playerCount: 0,
      status: "视频加载失败，已使用预览",
    }
  );
});

test("disable cancels a staged video before its first frame can commit", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-video",
          title: "Fixture Video",
          type: "video",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl: `data:video/mp4;base64,${tinyMp4}`,
          reason: null,
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `(() => {
      localStorage.setItem(
        "codex-wallpaper-p1-config",
        JSON.stringify({
          enabled: true,
          active: { kind: "workshop", id: "fixture-video" },
          favorites: [],
          playlist: [],
          settings: { dim: 18, blur: 0, opacity: 100, fps: 30, volume: 0, rotationMinutes: 0 }
        })
      );
      globalThis.__t02OriginalFrameCallback =
        HTMLVideoElement.prototype.requestVideoFrameCallback;
      globalThis.__t02OriginalCancelFrameCallback =
        HTMLVideoElement.prototype.cancelVideoFrameCallback;
      globalThis.__t02PendingFrame = null;
      HTMLVideoElement.prototype.requestVideoFrameCallback = (callback) => {
        globalThis.__t02PendingFrame = callback;
        return 1;
      };
      HTMLVideoElement.prototype.cancelVideoFrameCallback = () => {};
    })()`,
    options
  );
  await applyStaticBackground(port, options);
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        for (let attempt = 0; attempt < 40; attempt += 1) {
          if (typeof globalThis.__t02PendingFrame === "function") break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const stagedBefore = root.querySelectorAll(".media.staged").length;
        const pendingFrame = globalThis.__t02PendingFrame;
        await globalThis.__codexWallpaperApi.disable();
        pendingFrame?.(performance.now(), {});
        await new Promise((resolve) => setTimeout(resolve, 50));
        const state = globalThis.__codexWallpaperApi.state();
        const result = {
          stagedBefore,
          state: state.state,
          root: document.querySelectorAll("#${rootId}").length,
          mediaAfter: document.querySelectorAll(
            "#${rootId} [data-codex-wallpaper-layer] .media"
          ).length,
          videoAfter: document.querySelectorAll("#${rootId} video").length,
          playerCount: state.playerCount
        };
        HTMLVideoElement.prototype.requestVideoFrameCallback =
          globalThis.__t02OriginalFrameCallback;
        HTMLVideoElement.prototype.cancelVideoFrameCallback =
          globalThis.__t02OriginalCancelFrameCallback;
        return result;
      })()`,
      options
    ),
    {
      stagedBefore: 1,
      state: "disabled",
      root: 0,
      mediaAfter: 0,
      videoAfter: 0,
      playerCount: 0,
    }
  );
});

test("continuous slider input previews immediately and persists the settled value once", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-image",
          title: "Fixture Image",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          assetDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          reason: null,
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `localStorage.setItem(
      "codex-wallpaper-p1-config",
      JSON.stringify({
        enabled: true,
        active: { kind: "workshop", id: "fixture-image" },
        favorites: [],
        playlist: [],
        settings: {
          dim: 18,
          blur: 0,
          opacity: 100,
          fps: 30,
          volume: 0,
          rotationMinutes: 0
        }
      })
    )`,
    options
  );
  await applyStaticBackground(port, options);

  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        for (let attempt = 0; attempt < 80; attempt += 1) {
          const image = root.querySelector(".media:not(.staged) img");
          if (image?.complete && image.naturalWidth > 0) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        controls.querySelector("[data-codex-wallpaper-settings]").click();
        controls.querySelector("[data-panel-page='appearance']")?.click();
        const opacity = [...controls.querySelectorAll(".range")].find(
          (range) => range.querySelector("span")?.textContent === "不透明度"
        ).querySelector("input");
        const opacityOutput = opacity.closest(".range").querySelector("output");
        const opacityText = opacityOutput.firstChild;
        const originalSetItem = Storage.prototype.setItem;
        let configWrites = 0;
        Storage.prototype.setItem = function (key, value) {
          if (key === "codex-wallpaper-p1-config") configWrites += 1;
          return originalSetItem.call(this, key, value);
        };
        opacity.focus();
        for (let value = 21; value <= 50; value += 1) {
          opacity.value = String(value);
          opacity.dispatchEvent(new Event("input", { bubbles: true }));
        }
        const previewBeforeSettle =
          root.querySelector("[data-codex-wallpaper-layer]").style.opacity;
        const visibleOpacityAfterPreview = opacityOutput.textContent;
        const savedBeforeSettle = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        ).settings.opacity;
        const visiblePages = () => [...controls.querySelectorAll("[data-panel-region]")]
          .filter((page) => page.getClientRects().length > 0)
          .map((page) => page.dataset.panelRegion);
        const appearancePage = visiblePages();
        controls.querySelector("[data-panel-page='playback']")?.click();
        const playbackPage = visiblePages();
        await new Promise((resolve) => setTimeout(resolve, 20));
        const writesAfterBlur = configWrites;
        const savedAfterBlur = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        ).settings.opacity;
        controls.querySelector("[data-panel-page='appearance']")?.click();
        controls.querySelector("[data-codex-wallpaper-panel] header button").click();
        controls.querySelector("[data-codex-wallpaper-settings]").click();
        const reopenedOpacity = [...controls.querySelectorAll(".range")]
          .find(
            (range) => range.querySelector("span")?.textContent === "不透明度"
          )
          .querySelector("input").value;
        const pendingLocal = [...controls.querySelectorAll(".range")]
          .find(
            (range) => range.querySelector("span")?.textContent === "不透明度"
          )
          .querySelector("input");
        pendingLocal.focus();
        pendingLocal.value = "40";
        pendingLocal.dispatchEvent(new Event("input", { bubbles: true }));
        const localBeforeRemote = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        ).settings.opacity;
        const beforeRemoteEvent = localStorage.getItem(
          "codex-wallpaper-p1-config"
        );
        const remoteDuringLocalEdit = JSON.stringify({
          ...JSON.parse(beforeRemoteEvent),
          settings: {
            ...JSON.parse(beforeRemoteEvent).settings,
            opacity: 65,
            volume: 80
          }
        });
        localStorage.setItem(
          "codex-wallpaper-p1-config",
          remoteDuringLocalEdit
        );
        dispatchEvent(
          new StorageEvent("storage", {
            key: "codex-wallpaper-p1-config",
            oldValue: beforeRemoteEvent,
            newValue: remoteDuringLocalEdit,
            storageArea: localStorage
          })
        );
        const afterCombinedSave = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        );
        const displayedVolume = [...controls.querySelectorAll(".range")]
          .find((range) => range.querySelector("span")?.textContent === "音量")
          .querySelector("input").value;
        const displayedOpacityAfterCombinedSave = pendingLocal.value;
        const stateVolumeAfterCombinedSave =
          globalThis.__codexWallpaperApi.state().volume;
        const remoteAfterLocalSettled = JSON.stringify({
          ...JSON.parse(remoteDuringLocalEdit),
          settings: {
            ...JSON.parse(remoteDuringLocalEdit).settings,
            opacity: 80,
            volume: 60
          }
        });
        localStorage.setItem(
          "codex-wallpaper-p1-config",
          remoteAfterLocalSettled
        );
        dispatchEvent(
          new StorageEvent("storage", {
            key: "codex-wallpaper-p1-config",
            oldValue: remoteDuringLocalEdit,
            newValue: remoteAfterLocalSettled,
            storageArea: localStorage
          })
        );
        const remoteApplied = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        ).settings.opacity;
        const remoteVolumeApplied = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        ).settings.volume;
        Storage.prototype.setItem = originalSetItem;
        const visibleOpacityAfterSync = opacityOutput.textContent;
        const displayedAfterRemote = pendingLocal.value;
        const image = root.querySelector(".media:not(.staged) img");
        const name = controls.querySelector("[data-preset-name-input]");
        name.value = "未保存预设";
        const appearanceTab = controls.querySelector("[data-panel-page='appearance']");
        appearanceTab.focus();
        appearanceTab.dispatchEvent(new KeyboardEvent("keydown", { key: "Home", bubbles: true }));
        const keyboardPage = visiblePages();
        const search = controls.querySelector("[data-library-search]");
        search.value = "Fixture";
        search.dispatchEvent(new Event("input", { bubbles: true }));
        appearanceTab.click();
        const editor = opacity.closest(".range");
        editor.querySelector("button").click();
        const number = editor.querySelector("input[type='number']");
        const exactInputFocused = document.activeElement === number;
        number.value = "64.5";
        number.dispatchEvent(new Event("input", { bubbles: true }));
        const exactPreview = root.querySelector("[data-codex-wallpaper-layer]").style.opacity;
        controls.querySelector("[data-codex-wallpaper-panel] header button").click();
        controls.querySelector("[data-codex-wallpaper-settings]").click();
        const exactSaved = JSON.parse(localStorage.getItem("codex-wallpaper-p1-config")).settings.opacity;
        return {
          previewBeforeSettle,
          visibleOpacityAfterPreview,
          visibleOpacityAfterSync,
          keptOpacityText: opacityOutput.firstChild === opacityText,
          savedBeforeSettle,
          writesAfterBlur,
          savedAfterBlur,
          appearancePage,
          playbackPage,
          reopenedOpacity,
          localBeforeRemote,
          localOpacityAfterCombinedSave: afterCombinedSave.settings.opacity,
          remoteVolumeAfterCombinedSave: afterCombinedSave.settings.volume,
          displayedOpacityAfterCombinedSave,
          displayedVolumeAfterCombinedSave: displayedVolume,
          stateVolumeAfterCombinedSave,
          remoteApplied,
          remoteVolumeApplied,
          displayedAfterRemote,
          keyboardPage,
          retainedFilter: search.value,
          retainedDraft: name.value,
          exactInputFocused,
          exactPreview,
          exactSaved,
          exactReopened: opacityOutput.textContent,
          sameImage: root.querySelector(".media:not(.staged) img") === image
        };
      })()`,
      options
    ),
    {
      previewBeforeSettle: "0.5",
      visibleOpacityAfterPreview: "50%",
      visibleOpacityAfterSync: "80%",
      keptOpacityText: true,
      savedBeforeSettle: 100,
      writesAfterBlur: 1,
      savedAfterBlur: 50,
      appearancePage: ["appearance"],
      playbackPage: ["playback"],
      reopenedOpacity: "50",
      localBeforeRemote: 50,
      localOpacityAfterCombinedSave: 40,
      remoteVolumeAfterCombinedSave: 80,
      displayedOpacityAfterCombinedSave: "40",
      displayedVolumeAfterCombinedSave: "80",
      stateVolumeAfterCombinedSave: 80,
      remoteApplied: 80,
      remoteVolumeApplied: 60,
      displayedAfterRemote: "80",
      keyboardPage: ["library"],
      retainedFilter: "Fixture",
      retainedDraft: "未保存预设",
      exactInputFocused: true,
      exactPreview: "0.645",
      exactSaved: 64.5,
      exactReopened: "64.5%",
      sameImage: true,
    }
  );
});

test("cross-window settings update in place without rebuilding cards or media", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-video",
          title: "Fixture Video",
          type: "video",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl: `data:video/mp4;base64,${tinyMp4}`,
          reason: null,
        },
        {
          id: "fixture-image",
          title: "Fixture Image",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          assetDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          reason: null,
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `(() => {
      localStorage.setItem(
        "codex-wallpaper-p1-config",
        JSON.stringify({
          enabled: true,
          active: { kind: "workshop", id: "fixture-video" },
          favorites: [],
          playlist: [],
          settings: {
            dim: 18,
            blur: 0,
            opacity: 100,
            fps: 30,
            volume: 0,
            rotationMinutes: 0
          }
        })
      );
      const original = HTMLVideoElement.prototype.requestVideoFrameCallback;
      globalThis.__t03OriginalFrameCallback = original;
      globalThis.__t03PendingFrame = null;
      HTMLVideoElement.prototype.requestVideoFrameCallback = (callback) => {
        globalThis.__t03PendingFrame = callback;
        return 1;
      };
    })()`,
    options
  );
  await applyStaticBackground(port, options);

  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        for (let attempt = 0; attempt < 80; attempt += 1) {
          const stagedVideo = root.querySelector(".media.staged video");
          if (
            typeof globalThis.__t03PendingFrame === "function" &&
            stagedVideo?.readyState >= 2
          )
            break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        globalThis.__t03PendingFrame?.(performance.now(), {});
        for (let attempt = 0; attempt < 80; attempt += 1) {
          if (root.querySelector(".media:not(.staged) video")) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        controls.querySelector("[data-codex-wallpaper-settings]").click();
        const panel = controls.querySelector("[data-codex-wallpaper-panel]");
        panel.querySelector("[data-panel-page='playback']").click();
        const settings = controls.querySelector(".settings-grid");
        const cards = [...controls.querySelectorAll(".card")];
        const media = root.querySelector(".media");
        const volume = [...controls.querySelectorAll(".range")].find(
          (range) => range.querySelector("span")?.textContent === "音量"
        ).querySelector("input");
        volume.focus();
        panel.scrollTop = 60;
        let cardAdds = 0;
        let mediaMutations = 0;
        const cardObserver = new MutationObserver((records) => {
          cardAdds += records.reduce(
            (count, record) => count + record.addedNodes.length,
            0
          );
        });
        const mediaObserver = new MutationObserver((records) => {
          mediaMutations += records.reduce(
            (count, record) => count + record.addedNodes.length,
            0
          );
        });
        cardObserver.observe(panel.querySelector(".wallpaper-list"), {
          childList: true
        });
        mediaObserver.observe(root.querySelector("[data-codex-wallpaper-layer]"), {
          childList: true,
          subtree: true
        });
        const previous = localStorage.getItem("codex-wallpaper-p1-config");
        const next = JSON.stringify({
          ...JSON.parse(previous),
          favorites: [{ kind: "workshop", id: "fixture-video" }],
          playlist: [
            { kind: "workshop", id: "fixture-video" },
            { kind: "workshop", id: "fixture-image" }
          ],
          settings: {
            dim: 42,
            blur: 6,
            opacity: 73,
            fps: 15,
            volume: 40,
            rotationMinutes: 0
          }
        });
        const peer = document.createElement("iframe");
        peer.hidden = true;
        document.body.append(peer);
        const synced = new Promise((resolve) => window.addEventListener("storage", resolve, { once: true }));
        peer.contentWindow.localStorage.setItem("codex-wallpaper-p1-config", next);
        await synced;
        peer.remove();
        cardObserver.disconnect();
        mediaObserver.disconnect();
        const video = root.querySelector(".media:not(.staged) video");
        const result = {
          cardsSame:
            cards.length === controls.querySelectorAll(".card").length &&
            cards.every((card, index) =>
              card === controls.querySelectorAll(".card")[index]),
          cardAdds,
          mediaSame: media === root.querySelector(".media"),
          mediaMutations,
          staged: root.querySelectorAll(".media.staged").length,
          opacity:
            root.querySelector("[data-codex-wallpaper-layer]").style.opacity,
          filter: media.style.filter,
          videoVolume: video?.volume,
          videoMuted: video?.muted,
          panelOpen: panel.classList.contains("open"),
          panelScrollTop: panel.scrollTop,
          volumeFocused: document.activeElement === volume,
          settingsSame:
            settings === controls.querySelector(".settings-grid"),
          favoritePressed: controls
            .querySelector(
              ".card[data-entry-id='fixture-video'] [data-entry-action='favorite']"
            )
            .getAttribute("aria-pressed"),
          queueLabel: controls
            .querySelector(
              ".card[data-entry-id='fixture-video'] [data-entry-action='queue']"
            ).textContent,
          playlistSummary:
            controls.querySelector(".playlist-summary").textContent,
          stateFps: globalThis.__codexWallpaperApi.state().fpsCap,
          profile: controls.querySelector("[data-playback-profile]").value,
          opacityValue: [...controls.querySelectorAll(".range")]
            .find(
              (range) => range.querySelector("span")?.textContent === "不透明度"
            )
            .querySelector("input").value
        };
        HTMLVideoElement.prototype.requestVideoFrameCallback =
          globalThis.__t03OriginalFrameCallback;
        return result;
      })()`,
      options
    ),
    {
      cardsSame: true,
      cardAdds: 0,
      mediaSame: true,
      mediaMutations: 0,
      staged: 0,
      opacity: "0.73",
      filter: "blur(6px)",
      videoVolume: 0.4,
      videoMuted: false,
      panelOpen: true,
      panelScrollTop: 60,
      volumeFocused: true,
      settingsSame: true,
      favoritePressed: "true",
      queueLabel: "移除轮播",
      playlistSummary: "轮播：Fixture Video · Fixture Image",
      stateFps: 15,
      profile: "custom",
      opacityValue: "73",
    }
  );
});

test("cross-window asset identity change still reloads the wallpaper", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-image",
          title: "Fixture Image",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          assetDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          reason: null,
        },
        {
          id: "fixture-image-next",
          title: "Fixture Image Next",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%23123456'/%3E%3C/svg%3E",
          assetDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%23123456'/%3E%3C/svg%3E",
          reason: null,
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `localStorage.setItem(
      "codex-wallpaper-p1-config",
      JSON.stringify({
        enabled: true,
        active: { kind: "workshop", id: "fixture-image" },
        favorites: [],
        playlist: [],
        settings: {
          dim: 18,
          blur: 0,
          opacity: 100,
          fps: 30,
          volume: 0,
          rotationMinutes: 0
        }
      })
    )`,
    options
  );
  await applyStaticBackground(port, options);

  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        for (let attempt = 0; attempt < 80; attempt += 1) {
          const image = root.querySelector(".media:not(.staged) img");
          if (image?.src.includes("5d32b8") && image.complete) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const oldImage = root.querySelector(".media:not(.staged) img");
        const previous = localStorage.getItem("codex-wallpaper-p1-config");
        const next = JSON.stringify({
          ...JSON.parse(previous),
          active: { kind: "workshop", id: "fixture-image-next" }
        });
        localStorage.setItem("codex-wallpaper-p1-config", next);
        dispatchEvent(
          new StorageEvent("storage", {
            key: "codex-wallpaper-p1-config",
            oldValue: previous,
            newValue: next,
            storageArea: localStorage
          })
        );
        for (let attempt = 0; attempt < 80; attempt += 1) {
          const image = root.querySelector(".media:not(.staged) img");
          if (image?.src.includes("123456") && image.complete) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const nextImage = root.querySelector(".media:not(.staged) img");
        return {
          imageReplaced: oldImage !== nextImage,
          nextImageVisible: nextImage?.src.includes("123456") ?? false,
          staged: root.querySelectorAll(".media.staged").length,
          active: globalThis.__codexWallpaperApi.state().activeId
        };
      })()`,
      options
    ),
    {
      imageReplaced: true,
      nextImageVisible: true,
      staged: 0,
      active: "fixture-image-next",
    }
  );
});

test("opening and closing the mounted panel does not rebuild wallpaper cards", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-image",
          title: "Fixture Image",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          assetDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          reason: null,
        },
        {
          id: "fixture-lazy",
          title: "Fixture Lazy",
          type: "image",
          playable: false,
          fallback: true,
          previewDataUrl: null,
          assetDataUrl: null,
          reason: "asset-not-loaded",
        },
      ],
    },
  };
  await waitForPage(port, options);
  await applyStaticBackground(port, options);
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        for (let attempt = 0; attempt < 80; attempt += 1) {
          const image = root.querySelector(".media:not(.staged) img");
          if (image?.complete && image.naturalWidth > 0) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const controls = document.getElementById("${controlRootId}");
        const button = controls.querySelector("[data-codex-wallpaper-settings]");
        const panel = controls.querySelector("[data-codex-wallpaper-panel]");
        const list = panel.querySelector(".wallpaper-list");
        const beforeOpenCards = list.querySelectorAll(".card").length;
        button.click();
        const opened = panel.classList.contains("open");
        const firstOpenCards = list.querySelectorAll(".card").length;
        const cards = [...list.querySelectorAll(".card")];
        let addedCards = 0;
        const observer = new MutationObserver((records) => {
          addedCards += records.reduce(
            (count, record) =>
              count +
              [...record.addedNodes].filter((node) =>
                node.matches?.(".card")).length,
            0
          );
        });
        observer.observe(list, { childList: true });
        button.click();
        const closed = !panel.classList.contains("open");
        button.click();
        const reopened = panel.classList.contains("open");
        await new Promise((resolve) => setTimeout(resolve, 20));
        observer.disconnect();
        return {
          beforeOpenCards,
          firstOpenCards,
          opened,
          closed,
          reopened,
          sameCards:
            cards.length === list.querySelectorAll(".card").length &&
            cards.every((card, index) =>
              card === list.querySelectorAll(".card")[index]),
          addedCards
        };
      })()`,
      options
    ),
    {
      beforeOpenCards: 0,
      firstOpenCards: 2,
      opened: true,
      closed: true,
      reopened: true,
      sameCards: true,
      addedCards: 0,
    }
  );
});

test("rotation requests an item without a preview and respects background pause", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const image =
    "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='red'/%3E%3C/svg%3E";
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "still",
          title: "Still",
          type: "image",
          playable: true,
          assetDataUrl: image,
        },
        {
          id: "on-demand",
          title: "On demand",
          type: "video",
          reason: "asset-not-loaded",
        },
      ],
    },
  };
  await waitForPage(port, options);
  await applyStaticBackground(port, options);
  const result = await evaluateInPage(
    port,
    `(async () => {
    const select = (selector) => document.querySelector("#${controlRootId} " + selector);
    const action = (id, action) =>
      select('.card[data-entry-id="' + id + '"] [data-entry-action="' + action + '"]');
    const runtime = globalThis.__codexWallpaperApi;
    const requests = [];
    globalThis.__codexWallpaperHostRequest = (raw) => requests.push(JSON.parse(raw));
    let tick = null;
    let visibility = "visible";
    const setInterval = window.setInterval;
    const clearInterval = window.clearInterval;
    window.setInterval = (callback, delay, ...args) => {
      if (delay !== 60000) return setInterval(callback, delay, ...args);
      tick = callback;
      return -1;
    };
    window.clearInterval = (id) => {
      if (id === -1) tick = null;
      else clearInterval(id);
    };
    Object.defineProperty(document, "visibilityState", {
      configurable: true,
      get: () => visibility,
    });
    select("[data-codex-wallpaper-settings]").click();
    action("still", "use").click();
    action("still", "queue").click();
    action("on-demand", "queue").click();
    select("[data-panel-page='playback']").click();
    const minutes = select("[data-setting='rotationMinutes']");
    minutes.value = "1";
    minutes.dispatchEvent(new Event("input", { bubbles:true }));
    select("[data-panel-page='library']").click();
    const saved = JSON.parse(localStorage.getItem("codex-wallpaper-p1-config")).settings.rotationMinutes;
    const summary = select(".playlist-summary").textContent;
    visibility = "hidden";
    document.dispatchEvent(new Event("visibilitychange"));
    const stoppedWhileHidden = tick === null;
    visibility = "visible";
    document.dispatchEvent(new Event("visibilitychange"));
    tick?.();
    const request = requests.find((entry) => entry.type === "load-asset");
    if (!request) return { saved, summary, stoppedWhileHidden, request: null };
    const opened = runtime.beginAssetTransfer({ id: "on-demand" });
    action("still", "use").click();
    return {
      saved,
      summary,
      stoppedWhileHidden,
      request,
      startedTransfer: opened !== false,
      discardedChunk: runtime.appendAssetTransferChunk("on-demand", "AA==") === false,
      discardedEnd: (await runtime.finishAssetTransfer("on-demand")) === false,
      newSelection: runtime.state().activeId,
    };
  })()`,
    options
  );
  assert.deepEqual(result, {
    saved: 1,
    summary: "轮播：Still · On demand",
    stoppedWhileHidden: true,
    request: { type: "load-asset", id: "on-demand" },
    startedTransfer: true,
    discardedChunk: true,
    discardedEnd: true,
    newSelection: "still",
  });
});

test("wallpaper library shell combines filters without reloading the current media", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const preview =
    "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E";
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-image",
          title: "Fixture Image",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl: preview,
          assetDataUrl: preview,
          reason: null,
        },
        {
          id: "fixture-video",
          title: "Fixture Video",
          type: "video",
          playable: true,
          fallback: true,
          previewDataUrl: preview,
          assetDataUrl: null,
          reason: null,
        },
        {
          id: "fixture-scene",
          title: "Fixture Scene",
          type: "scene",
          playable: true,
          fallback: true,
          previewDataUrl: preview,
          assetDataUrl: "data:application/octet-stream;base64,AA==",
          reason: "scene-native",
        },
        {
          id: "fixture-web-fallback",
          title: "Fixture Web Fallback",
          type: "web",
          playable: false,
          fallback: true,
          previewDataUrl: preview,
          assetDataUrl: null,
          webHtml: null,
          reason: "web-preview-fallback",
        },
        {
          id: "fixture-on-demand",
          title: "Fixture On Demand",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl: preview,
          assetDataUrl: null,
          reason: "asset-not-loaded",
        },
        {
          id: "fixture-on-demand-next",
          title: "Fixture On Demand Next",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl: preview,
          assetDataUrl: null,
          reason: "asset-not-loaded",
        },
        {
          id: "fixture-lazy",
          title: "Fixture Lazy",
          type: "image",
          playable: false,
          fallback: true,
          previewDataUrl: null,
          assetDataUrl: null,
          reason: "asset-not-loaded",
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `localStorage.setItem(
      "codex-wallpaper-p1-config",
      JSON.stringify({
        enabled: true,
        active: { kind: "workshop", id: "fixture-image" },
        favorites: [],
        playlist: [],
        settings: {
          dim: 18,
          blur: 0,
          opacity: 100,
          fps: 30,
          volume: 0,
          rotationMinutes: 0
        }
      })
    )`,
    options
  );
  await applyStaticBackground(port, options);

  const result = await evaluateInPage(
    port,
    `(async () => {
      const controls = document.getElementById("${controlRootId}");
      const root = document.getElementById("${rootId}");
      const hostRequests = [];
      globalThis.__codexWallpaperHostRequest = (raw) => {
        hostRequests.push(JSON.parse(raw));
      };
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const panel = controls.querySelector("[data-codex-wallpaper-panel]");
      panel.style.maxHeight = "220px";
      const media = root.querySelector("[data-codex-wallpaper-layer] .media");
      let stableMediaChild = null;
      let mediaMutations = 0;
      const observer = new MutationObserver((records) => {
        mediaMutations += records.length;
      });
      observer.observe(media, { childList: true, subtree: true });

      const regionNames = [...panel.querySelectorAll("[data-panel-region]")].map(
        (region) => region.dataset.panelRegion
      );
      const search = panel.querySelector("[data-library-search]");
      const type = panel.querySelector("[data-library-type]");
      const favorites = panel.querySelector("[data-library-favorites]");

      search.value = "fixture image";
      search.dispatchEvent(new Event("input", { bubbles: true }));
      await new Promise((resolve) => setTimeout(resolve, 80));
      search.value = "lazy";
      search.dispatchEvent(new Event("input", { bubbles: true }));
      panel
        .querySelector(".card[data-entry-id='fixture-lazy']")
        .scrollIntoView({ block: "center" });
      let lazyPreviewRequested = false;
      for (let attempt = 0; attempt < 20; attempt += 1) {
        lazyPreviewRequested = hostRequests.some(
          (request) =>
            request.type === "load-preview" && request.id === "fixture-lazy"
        );
        if (lazyPreviewRequested) break;
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      search.value = "";
      search.dispatchEvent(new Event("input", { bubbles: true }));

      const imageCard = panel.querySelector(
        ".card[data-entry-id='fixture-image']"
      );
      imageCard
        .querySelector("[data-entry-action='favorite']")
        .click();
      imageCard.querySelector("[data-entry-action='queue']").click();

      search.value = "fixture";
      search.dispatchEvent(new Event("input", { bubbles: true }));
      type.value = "image";
      type.dispatchEvent(new Event("change", { bubbles: true }));
      favorites.click();
      const visibleTitles = [...panel.querySelectorAll(".card")]
        .filter((card) => !card.hidden)
        .map((card) => card.querySelector("strong").textContent);
      const resultText = panel.querySelector("[data-library-result]").textContent;

      search.value = "";
      search.dispatchEvent(new Event("input", { bubbles: true }));
      type.value = "all";
      type.dispatchEvent(new Event("change", { bubbles: true }));
      favorites.click();
      const cardStatus = (id) =>
        panel
          .querySelector(\`.card[data-entry-id="\${id}"] [data-card-status]\`)
          ?.textContent;
      const statuses = {
        scene: cardStatus("fixture-scene"),
        webFallback: cardStatus("fixture-web-fallback"),
        onDemand: cardStatus("fixture-on-demand")
      };

      const fileInput = panel.querySelector(".import-row input");
      const transfer = new DataTransfer();
      transfer.items.add(
        new File(
          ["<svg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/>"],
          "Imported Sunset.svg",
          { type: "image/svg+xml" }
        )
      );
      transfer.items.add(
        new File([Uint8Array.from(atob(${JSON.stringify(tinyMp4)}), (char) => char.charCodeAt(0))], "Imported Motion.mp4", {
          type: "video/mp4"
        })
      );
      fileInput.files = transfer.files;
      fileInput.dispatchEvent(new Event("change", { bubbles: true }));
      for (let attempt = 0; attempt < 40; attempt += 1) {
        if (globalThis.__codexWallpaperApi.state().importedCount > 0) break;
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      search.value = "sunset";
      search.dispatchEvent(new Event("input", { bubbles: true }));
      const importedFilterVisible = [...panel.querySelectorAll(".card")]
        .filter((card) => !card.hidden)
        .some(
          (card) => card.querySelector("strong")?.textContent ===
            "Imported Sunset.svg"
        );
      const importedCard = [...panel.querySelectorAll(".card")].find(
        (card) =>
          card.querySelector("strong")?.textContent === "Imported Sunset.svg"
      );
      importedCard.scrollIntoView({ block: "center" });
      let importedPreviewLoaded = false;
      for (let attempt = 0; attempt < 40; attempt += 1) {
        importedPreviewLoaded = Boolean(
          importedCard.querySelector(".thumb img, .thumb video")
        );
        if (importedPreviewLoaded) break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      search.value = "motion";
      search.dispatchEvent(new Event("input", { bubbles: true }));
      const importedVideoCard = [...panel.querySelectorAll(".card")].find(
        (card) =>
          card.querySelector("strong")?.textContent === "Imported Motion.mp4"
      );
      importedVideoCard.scrollIntoView({ block: "center" });
      let importedVideoPreviewLoaded = false;
      for (let attempt = 0; attempt < 40; attempt += 1) {
        importedVideoPreviewLoaded = Boolean(
          importedVideoCard.querySelector(".thumb video")
        );
        if (importedVideoPreviewLoaded) break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      search.value = "";
      search.dispatchEvent(new Event("input", { bubbles: true }));
      panel
        .querySelector(
          ".card[data-entry-id='fixture-on-demand'] [data-entry-action='use']"
        )
        .click();
      await new Promise((resolve) => setTimeout(resolve, 25));
      const loadingStatus = cardStatus("fixture-on-demand");
      globalThis.__codexWallpaperApi.receiveAsset({
        id: "fixture-on-demand",
        title: "Fixture On Demand",
        type: "image",
        playable: true,
        fallback: false,
        previewDataUrl:
          "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
        assetDataUrl:
          "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%23fb923c'/%3E%3C/svg%3E",
        reason: null
      });
      await new Promise((resolve) => setTimeout(resolve, 50));
      const loadedStatus = cardStatus("fixture-on-demand");
      panel
        .querySelector(
          ".card[data-entry-id='fixture-on-demand-next'] [data-entry-action='use']"
        )
        .click();
      await new Promise((resolve) => setTimeout(resolve, 25));
      const newerLoadingStatus = cardStatus("fixture-on-demand-next");
      globalThis.__codexWallpaperApi.receiveAssetError(
        "fixture-on-demand",
        "old request failed"
      );
      await new Promise((resolve) => setTimeout(resolve, 25));
      const newerAfterOldFailure = cardStatus("fixture-on-demand-next");
      globalThis.__codexWallpaperApi.receiveAssetError(
        "fixture-on-demand-next",
        "new request failed"
      );
      await new Promise((resolve) => setTimeout(resolve, 25));
      const failedStatus = cardStatus("fixture-on-demand-next");
      panel
        .querySelector(".card[data-entry-id='fixture-image'] [data-entry-action='use']")
        .click();
      for (let attempt = 0; attempt < 40; attempt += 1) {
        const image = root.querySelector(".media:not(.staged) img");
        if (image?.src.includes("5d32b8") && globalThis.__codexWallpaperApi.state().activeId === "fixture-image")
          break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      stableMediaChild = media.firstElementChild;
      mediaMutations = 0;

      const cards = [...panel.querySelectorAll(".card")];
      panel.style.width = "280px";
      panel.style.maxHeight = "320px";
      search.focus();
      const keyboardReachable =
        document.activeElement === search &&
        search.tabIndex >= 0 &&
        type.tabIndex >= 0 &&
        favorites.tabIndex >= 0;
      panel.scrollTop = panel.scrollHeight;
      const scrollable =
        getComputedStyle(panel).overflowY === "auto" &&
        panel.scrollHeight > panel.clientHeight &&
        panel.scrollTop > 0;

      const close = panel.querySelector("header button");
      close.click();
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const reopenedImageCard = panel.querySelector(
        ".card[data-entry-id='fixture-image']"
      );
      observer.disconnect();
      return {
        regionNames,
        visibleTitles,
        resultText,
        statuses,
        importedFilterVisible,
        importedPreviewLoaded,
        importedVideoPreviewLoaded,
        lazyPreviewRequested,
        loadingStatus,
        loadedStatus,
        newerLoadingStatus,
        newerAfterOldFailure,
        failedStatus,
        keyboardReachable,
        scrollable,
        reopened: panel.classList.contains("open"),
        sameCards: cards.every(
          (card, index) => card === panel.querySelectorAll(".card")[index]
        ),
        sameMediaChild: media.firstElementChild === stableMediaChild,
        mediaMutations,
        favoriteRetained:
          reopenedImageCard
            .querySelector("[data-entry-action='favorite']")
            .getAttribute("aria-pressed") === "true",
        queueRetained:
          reopenedImageCard
            .querySelector("[data-entry-action='queue']")
            .getAttribute("aria-pressed") === "true"
      };
    })()`,
    options
  );

  assert.deepEqual(result, {
    regionNames: ["library", "playback", "appearance"],
    visibleTitles: ["Fixture Image"],
    resultText: "显示 1 / 7 项",
    statuses: {
      scene: "scene · 原生渲染",
      webFallback: "web · 预览降级",
      onDemand: "image · 按需加载",
    },
    importedFilterVisible: true,
    importedPreviewLoaded: true,
    importedVideoPreviewLoaded: true,
    lazyPreviewRequested: true,
    loadingStatus: "image · 加载中",
    loadedStatus: "image · 原生显示",
    newerLoadingStatus: "image · 加载中",
    newerAfterOldFailure: "image · 加载中",
    failedStatus: "image · 加载失败",
    keyboardReachable: true,
    scrollable: true,
    reopened: true,
    sameCards: true,
    sameMediaChild: true,
    mediaMutations: 0,
    favoriteRetained: true,
    queueRetained: true,
  });
});

test("playback profiles and capability controls apply without replacing media", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const image =
    "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E";
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-image",
          title: "Fixture Image",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl: image,
          assetDataUrl: image,
          reason: null,
        },
        {
          id: "fixture-video",
          title: "Fixture Video",
          type: "video",
          playable: true,
          fallback: true,
          previewDataUrl: image,
          assetDataUrl: `data:video/mp4;base64,${tinyMp4}`,
          reason: null,
        },
        {
          id: "fixture-scene",
          title: "Fixture Scene",
          type: "scene",
          playable: true,
          fallback: true,
          previewDataUrl: image,
          assetDataUrl: "data:application/octet-stream;base64,AA==",
          reason: "scene-native",
        },
        {
          id: "fixture-web",
          title: "Fixture Web",
          type: "web",
          playable: false,
          fallback: true,
          previewDataUrl: image,
          assetDataUrl: null,
          webHtml:
            "<!doctype html><style>body{margin:0;background:linear-gradient(45deg,#123,#abc)}</style>",
          reason: "web-offline",
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `localStorage.setItem(
      "codex-wallpaper-p1-config",
      JSON.stringify({
        enabled: true,
        active: { kind: "workshop", id: "fixture-image" },
        favorites: [],
        playlist: [],
        settings: {
          dim: 18,
          blur: 0,
          opacity: 100,
          fps: 30,
          volume: 60,
          muted: true,
          rotationMinutes: 0,
          performanceProfile: "balanced",
          pauseWhenHidden: true
        }
      })
    )`,
    options
  );
  await evaluateInPage(
    port,
    `(() => {
      globalThis.WebWallGL = {
        bytesSource: () => ({}),
        createScene: (host, options) => {
          globalThis.__t05SceneFps = options.fps;
          const canvas = document.createElement("canvas");
          canvas.dataset.sceneCanvas = "";
          host.append(canvas);
          return {
            load: () => {
              globalThis.__t05SceneLoaded = true;
              return Promise.resolve();
            },
            pause: () => {
              globalThis.__t05ScenePaused = true;
            },
            resume: () => {
              globalThis.__t05SceneResumed = true;
            },
            setFps: (fps) => {
              globalThis.__t05SceneFps = fps;
            },
            setVolume: (volume) => {
              globalThis.__t05SceneVolume = volume;
            },
            destroy() {}
          };
        }
      };
    })()`,
    options
  );
  await applyStaticBackground(port, options);

  const result = await evaluateInPage(
    port,
    `(async () => {
      const root = document.getElementById("${rootId}");
      const controls = document.getElementById("${controlRootId}");
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const panel = controls.querySelector("[data-codex-wallpaper-panel]");
      panel.querySelector("[data-panel-page='playback']").click();

      const initial = {
        profile: panel.querySelector("[data-playback-profile]").value,
        summary: panel.querySelector("[data-performance-summary]").textContent,
        tradeoff: panel.querySelector("[data-performance-tradeoff]").textContent,
        capability: panel.querySelector("[data-playback-capability]").textContent,
        fpsControl: Boolean(panel.querySelector("[data-setting='fps']")),
        audioDisabled: panel.querySelector("[data-setting='volume']").disabled && panel.querySelector("[data-setting='muted']").disabled,
        pauseDisabled: panel.querySelector(
          "[data-setting='pauseWhenHidden']"
        ).disabled
      };

      const selectMedia = async (id, ready) => {
        panel.querySelector("[data-panel-page='library']").click();
        panel
          .querySelector(\`.card[data-entry-id="\${id}"] [data-entry-action='use']\`)
          .click();
        for (let attempt = 0; attempt < 200; attempt += 1) {
          if (ready()) {
            panel.querySelector("[data-panel-page='playback']").click();
            return;
          }
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        throw new Error(\`Timed out selecting \${id}: \${panel.querySelector(".runtime-status").textContent}\`);
      };

      await selectMedia(
        "fixture-video",
        () => Boolean(root.querySelector(".media:not(.staged) video"))
      );
      const videoMedia = root.querySelector(".media:not(.staged)");
      const video = videoMedia.querySelector("video");
      const volume = panel.querySelector("[data-setting='volume']");
      volume.value = "43";
      volume.dispatchEvent(new Event("input", { bubbles: true }));
      volume.dispatchEvent(new Event("change", { bubbles: true }));
      const mute = panel.querySelector("[data-setting='muted']");
      const unmutedByVolume =
        mute.checked === false && video.muted === false && video.volume === 0.43;
      mute.click();
      const muteRoundTrip = video.muted === true && video.volume === 0;
      mute.click();
      const videoControls = {
        volume: video.volume,
        muted: video.muted,
        unmutedByVolume,
        muteRoundTrip,
        fpsControl: Boolean(panel.querySelector("[data-setting='fps']")),
        capability: panel.querySelector("[data-playback-capability]").textContent
      };

      const profile = panel.querySelector("[data-playback-profile]");
      profile.value = "performance";
      profile.dispatchEvent(new Event("change", { bubbles: true }));
      const priority = {
        stateFps: globalThis.__codexWallpaperApi.state().fpsCap,
        profile: panel.querySelector("[data-playback-profile]").value,
        summary: panel.querySelector("[data-performance-summary]").textContent,
        tradeoff: panel.querySelector("[data-performance-tradeoff]").textContent,
        mediaSame: root.querySelector(".media:not(.staged)") === videoMedia
      };

      await selectMedia(
        "fixture-scene",
        () => Boolean(root.querySelector(".media:not(.staged) .scene-host.ready"))
      );
      const sceneFpsFromProfile = globalThis.__t05SceneFps;
      const fps = panel.querySelector("[data-setting='fps']");
      fps.value = "24";
      fps.dispatchEvent(new Event("input", { bubbles: true }));
      fps.dispatchEvent(new Event("change", { bubbles: true }));
      const custom = {
        profile: panel.querySelector("[data-playback-profile]").value,
        fps: fps.value,
        sceneFps: globalThis.__t05SceneFps,
        summary: panel.querySelector("[data-performance-summary]").textContent,
        tradeoff: panel.querySelector("[data-performance-tradeoff]").textContent
      };

      globalThis.__t05ScenePaused = false;
      globalThis.__t05SceneResumed = false;
      Object.defineProperty(document, "visibilityState", {
        configurable: true,
        get: () => "hidden"
      });
      document.dispatchEvent(new Event("visibilitychange"));
      Object.defineProperty(document, "visibilityState", {
        configurable: true,
        get: () => "visible"
      });
      document.dispatchEvent(new Event("visibilitychange"));
      const pauseEnabled = {
        paused: globalThis.__t05ScenePaused,
        resumed: globalThis.__t05SceneResumed
      };

      const hiddenPause = panel.querySelector("[data-setting='pauseWhenHidden']");
      hiddenPause.click();
      globalThis.__t05ScenePaused = false;
      globalThis.__t05SceneResumed = false;
      Object.defineProperty(document, "visibilityState", {
        configurable: true,
        get: () => "hidden"
      });
      document.dispatchEvent(new Event("visibilitychange"));
      Object.defineProperty(document, "visibilityState", {
        configurable: true,
        get: () => "visible"
      });
      document.dispatchEvent(new Event("visibilitychange"));
      const pauseDisabled = {
        paused: globalThis.__t05ScenePaused,
        resumed: globalThis.__t05SceneResumed
      };
      const directProfile = panel.querySelector("[data-playback-profile]");
      directProfile.value = "balanced";
      directProfile.dispatchEvent(new Event("change", { bubbles: true }));
      directProfile.value = "custom";
      directProfile.dispatchEvent(new Event("change", { bubbles: true }));
      const directCustom = {
        profile: panel.querySelector("[data-playback-profile]").value,
        fps: globalThis.__codexWallpaperApi.state().fpsCap
      };

      await selectMedia(
        "fixture-image",
        () => Boolean(root.querySelector(".media:not(.staged) img"))
      );
      const imageCapability = {
        fpsControl: Boolean(panel.querySelector("[data-setting='fps']")),
        audioDisabled: panel.querySelector("[data-setting='volume']").disabled && panel.querySelector("[data-setting='muted']").disabled,
        pauseDisabled: panel.querySelector(
          "[data-setting='pauseWhenHidden']"
        ).disabled,
        text: panel.querySelector("[data-playback-capability]").textContent
      };

      await selectMedia(
        "fixture-web",
        () => Boolean(root.querySelector(".media:not(.staged) iframe"))
      );
      const webCapability =
        {
          text: panel.querySelector("[data-playback-capability]").textContent,
          pauseDisabled: panel.querySelector(
            "[data-setting='pauseWhenHidden']"
          ).disabled
        };

      await selectMedia(
        "fixture-image",
        () => Boolean(root.querySelector(".media:not(.staged) img"))
      );
      const syncedMedia = root.querySelector(".media:not(.staged)");
      const previous = localStorage.getItem("codex-wallpaper-p1-config");
      const next = JSON.stringify({
        ...JSON.parse(previous),
        settings: {
          ...JSON.parse(previous).settings,
          fps: 15,
          volume: 35,
          muted: false,
          performanceProfile: "performance",
          pauseWhenHidden: true
        }
      });
      localStorage.setItem("codex-wallpaper-p1-config", next);
      dispatchEvent(
        new StorageEvent("storage", {
          key: "codex-wallpaper-p1-config",
          oldValue: previous,
          newValue: next,
          storageArea: localStorage
        })
      );
      await new Promise((resolve) => setTimeout(resolve, 30));
      const crossWindow = {
        mediaSame: root.querySelector(".media:not(.staged)") === syncedMedia,
        profile: panel.querySelector("[data-playback-profile]").value,
        volume: panel.querySelector("[data-setting='volume']").value,
        muted: panel.querySelector("[data-setting='muted']").checked,
        pauseWhenHidden: panel.querySelector(
          "[data-setting='pauseWhenHidden']"
        ).checked
      };

      panel.querySelector("header button").click();
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const saved = JSON.parse(
        localStorage.getItem("codex-wallpaper-p1-config")
      ).settings;
      const reopened = {
        profile: panel.querySelector("[data-playback-profile]").value,
        fps: panel.querySelector("[data-setting='fps']")?.value ?? null,
        volume: panel.querySelector("[data-setting='volume']").value,
        saved: {
          fps: saved.fps,
          volume: saved.volume,
          muted: saved.muted,
          performanceProfile: saved.performanceProfile,
          pauseWhenHidden: saved.pauseWhenHidden
        }
      };
      return {
        initial,
        videoControls,
        priority,
        sceneFpsFromProfile,
        custom,
        pauseEnabled,
        pauseDisabled,
        directCustom,
        imageCapability,
        webCapability,
        crossWindow,
        reopened
      };
    })()`,
    options
  );

  assert.deepEqual(result, {
    initial: {
      profile: "balanced",
      summary: "当前图片不使用帧率；已保存 Scene 上限 30 FPS · 不可见时暂停",
      tradeoff: "取舍：保留现有 30 FPS 上限，优先画面连续性。",
      capability: "图片稳定显示后不持续绘制；帧率不适用。",
      fpsControl: false,
      audioDisabled: true,
      pauseDisabled: true,
    },
    videoControls: {
      volume: 0.43,
      muted: false,
      unmutedByVolume: true,
      muteRoundTrip: true,
      fpsControl: false,
      capability:
        "视频按源文件解码并直接合成；性能档限制 Scene 上限，不伪造视频绘制帧率。",
    },
    priority: {
      stateFps: 15,
      profile: "performance",
      summary: "当前视频按源播放；已保存 Scene 上限 15 FPS · 不可见时暂停",
      tradeoff:
        "取舍：降低 Scene 绘制上限以减少渲染活动，画面连续性可能低于 30 FPS。",
      mediaSame: true,
    },
    sceneFpsFromProfile: 15,
    custom: {
      profile: "custom",
      fps: "24",
      sceneFps: 24,
      summary: "参数：Scene 上限 24 FPS · 不可见时暂停",
      tradeoff: "取舍：使用手动参数组合，不再自动套用命名档位。",
    },
    pauseEnabled: { paused: true, resumed: true },
    pauseDisabled: { paused: false, resumed: true },
    directCustom: {
      profile: "custom",
      fps: 30,
    },
    imageCapability: {
      fpsControl: false,
      audioDisabled: true,
      pauseDisabled: true,
      text: "图片稳定显示后不持续绘制；帧率不适用。",
    },
    webCapability: {
      text: "Web iframe 内部帧率和暂停无法由父页面可靠控制。",
      pauseDisabled: true,
    },
    crossWindow: {
      mediaSame: true,
      profile: "performance",
      volume: "35",
      muted: false,
      pauseWhenHidden: true,
    },
    reopened: {
      profile: "performance",
      fps: null,
      volume: "35",
      saved: {
        fps: 15,
        volume: 35,
        muted: false,
        performanceProfile: "performance",
        pauseWhenHidden: true,
      },
    },
  });
});

test("appearance controls update wallpaper and surface layers without reloading media", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const image =
    "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E";
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-image",
          title: "Fixture Image",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl: image,
          assetDataUrl: image,
          reason: null,
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `localStorage.setItem(
      "codex-wallpaper-p1-config",
      JSON.stringify({
        enabled: true,
        active: { kind: "workshop", id: "fixture-image" },
        favorites: [],
        playlist: [],
        settings: {
          dim: 18,
          blur: 0,
          opacity: 100,
          fps: 30,
          volume: 0,
          rotationMinutes: 0
        }
      })
    )`,
    options
  );
  await applyStaticBackground(port, options);

  const first = await evaluateInPage(
    port,
    `(async () => {
      const controls = document.getElementById("${controlRootId}");
      const root = document.getElementById("${rootId}");
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const panel = controls.querySelector("[data-codex-wallpaper-panel]");
      panel.querySelector("[data-panel-page='appearance']").click();
      const media = root.querySelector(".media:not(.staged)");
      const image = media.querySelector("img");
      const titlebar = document.querySelector("[data-app-shell-titlebar]");
      const settingsHost = document.createElement("div");
      settingsHost.dataset.appShellFeatureNavigation = "true";
      settingsHost.innerHTML =
        '<nav data-settings-nav-scroll-container></nav><main data-app-shell-main-surface><div class="electron:bg-surface">Settings</div></main>';
      document.body.append(settingsHost);
      const settingsCanvas = settingsHost.querySelector(
        "[class~='electron:bg-surface']"
      );
      const alphaOf = (value) =>
        Number(value.match(/\\/\\s*([\\d.]+)\\s*\\)$/)?.[1] ?? 0);
      const setRange = (name, value) => {
        const input = panel.querySelector(\`[data-setting="\${name}"]\`);
        input.value = value;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      };
      setRange("dim", "35");
      setRange("blur", "7");
      setRange("opacity", "80");

      const fit = panel.querySelector("[data-setting='fitMode']");
      const fitAvailable = Boolean(fit);
      fit.value = "contain";
      fit.dispatchEvent(new Event("change", { bubbles: true }));
      const fitResult = {
        fit: fit.value,
        objectFit: getComputedStyle(image).objectFit,
        mediaSame: root.querySelector(".media:not(.staged)") === media
      };

      const rootStyleBeforePreview = document.documentElement.getAttribute("style");
      setRange("surfaceOpacity", "55");
      const surfaceAlpha = (selector) =>
        alphaOf(getComputedStyle(document.querySelector(selector)).backgroundColor);
      const globalSurface = surfaceAlpha("body [data-app-shell-frame]");
      const inheritedChat = surfaceAlpha("[data-app-shell-main-surface]");
      const inheritedSidebar = surfaceAlpha("[data-app-shell-page-sidebar]");
      setRange("interfaceBlur", "8");
      const previewKeepsRootStyle =
        document.documentElement.getAttribute("style") === rootStyleBeforePreview;
      const blur = getComputedStyle(
        document.querySelector("[data-app-shell-main-surface]")
      ).backdropFilter;
      const borders = panel.querySelector(
        "[data-setting-toggle='interfaceBorders']"
      );
      borders.click();
      const bordersOff =
        document.documentElement.style.getPropertyValue(
          "--codex-wallpaper-line"
        ) === "transparent";

      const titlebarBefore = alphaOf(
        getComputedStyle(titlebar).backgroundColor
      );
      const sidebarOverride = panel.querySelector(
        "[data-surface-override='sidebar']"
      );
      sidebarOverride.click();
      const sidebarRange = panel.querySelector(
        "[data-surface-override-value='sidebar']"
      );
      sidebarRange.value = "40";
      sidebarRange.dispatchEvent(new Event("input", { bubbles: true }));
      const titlebarOverridden = alphaOf(
        getComputedStyle(titlebar).backgroundColor
      );
      panel.querySelector("[data-restore-surface='sidebar']").click();
      const titlebarRestored = alphaOf(
        getComputedStyle(titlebar).backgroundColor
      );

      const settingsCanvasBefore = alphaOf(
        getComputedStyle(settingsCanvas).backgroundColor
      );
      const settingsOverride = panel.querySelector(
        "[data-surface-override='settings']"
      );
      settingsOverride.click();
      const settingsRange = panel.querySelector(
        "[data-surface-override-value='settings']"
      );
      settingsRange.value = "70";
      settingsRange.dispatchEvent(new Event("input", { bubbles: true }));
      const settingsCanvasAfter = alphaOf(
        getComputedStyle(settingsCanvas).backgroundColor
      );
      panel.querySelector("[data-restore-surface='settings']").click();

      const chatOverride = panel.querySelector(
        "[data-surface-override='chat']"
      );
      chatOverride.click();
      const chatRange = panel.querySelector(
        "[data-surface-override-value='chat']"
      );
      chatRange.value = "30";
      chatRange.dispatchEvent(new Event("input", { bubbles: true }));
      const override = {
        enabled: chatOverride.checked,
        rangeEnabled: !chatRange.disabled,
        value: surfaceAlpha("[data-app-shell-main-surface]")
      };
      panel.querySelector("[data-restore-surface='chat']").click();
      const restored = {
        enabled: chatOverride.checked,
        value: surfaceAlpha("[data-app-shell-main-surface]")
      };

      document.documentElement.dataset.theme = "light";
      const lightBackground = getComputedStyle(
        document.querySelector("[data-app-shell-main-surface]")
      ).backgroundColor;
      const lightAlpha = Number(
        lightBackground.match(/\\/\\s*([\\d.]+)\\s*\\)$/)?.[1]
      );
      document.documentElement.dataset.theme = "dark";

      panel.querySelector("header button").click();
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const reopened = {
        fit: panel.querySelector("[data-setting='fitMode']").value,
        surface:
          panel.querySelector("[data-setting='surfaceOpacity']").value,
        blur: panel.querySelector("[data-setting='interfaceBlur']").value,
        borders: panel.querySelector(
          "[data-setting-toggle='interfaceBorders']"
        ).checked,
        overrideEnabled: panel.querySelector(
          "[data-surface-override='chat']"
        ).checked,
        mediaSame: root.querySelector(".media:not(.staged)") === media
      };

      const previous = localStorage.getItem("codex-wallpaper-p1-config");
      const pendingChatOverride = panel.querySelector(
        "[data-surface-override='chat']"
      );
      pendingChatOverride.click();
      const pendingChatRange = panel.querySelector(
        "[data-surface-override-value='chat']"
      );
      pendingChatRange.value = "44";
      pendingChatRange.dispatchEvent(new Event("input", { bubbles: true }));
      const next = JSON.stringify({
        ...JSON.parse(previous),
        settings: {
          ...JSON.parse(previous).settings,
          fitMode: "contain",
          surfaceOpacity: 60,
          interfaceBlur: 4,
          interfaceBorders: true,
          surfaceOverrides: { chat: null, sidebar: null, right: null, settings: 70 }
        }
      });
      localStorage.setItem("codex-wallpaper-p1-config", next);
      const syncedMedia = root.querySelector(".media:not(.staged)");
      dispatchEvent(
        new StorageEvent("storage", {
          key: "codex-wallpaper-p1-config",
          oldValue: previous,
          newValue: next,
          storageArea: localStorage
        })
      );
      await new Promise((resolve) => setTimeout(resolve, 30));
      const crossWindow = {
        mediaSame: root.querySelector(".media:not(.staged)") === syncedMedia,
        surface:
          panel.querySelector("[data-setting='surfaceOpacity']").value,
        fit: panel.querySelector("[data-setting='fitMode']").value,
        chatOverride: surfaceAlpha("[data-app-shell-main-surface]"),
        settingsOverride: alphaOf(getComputedStyle(panel).backgroundColor)
      };

      return {
        mediaSame:
          root.querySelector(".media:not(.staged) img") === image,
        dim: root.querySelector(
          "[data-codex-wallpaper-layer] .dim"
        ).style.background,
        filter: media.style.filter,
        opacity:
          root.querySelector("[data-codex-wallpaper-layer]").style.opacity,
        fitAvailable,
        fitResult,
        globalSurface,
        inheritedChat,
        inheritedSidebar,
        blur,
        previewKeepsRootStyle,
        bordersOff,
        top: {
          before: titlebarBefore,
          overridden: titlebarOverridden,
          restored: titlebarRestored
        },
        settingsSurface: {
          changes: settingsCanvasAfter !== settingsCanvasBefore,
          effective: settingsCanvasAfter > 0
        },
        override,
        restored,
        lightSurfaceTranslucent: lightAlpha > 0 && lightAlpha < 1,
        reopened,
        crossWindow
      };
    })()`,
    options
  );

  assert.deepEqual(first, {
    mediaSame: true,
    dim: "rgba(4, 6, 15, 0.35)",
    filter: "blur(7px)",
    opacity: "0.8",
    fitAvailable: true,
    fitResult: {
      fit: "contain",
      objectFit: "contain",
      mediaSame: true,
    },
    globalSurface: 0.55,
    inheritedChat: 0.14,
    inheritedSidebar: 0.55,
    blur: "blur(8px)",
    previewKeepsRootStyle: true,
    bordersOff: true,
    top: {
      before: 0,
      overridden: 0.4,
      restored: 0,
    },
    settingsSurface: {
      changes: true,
      effective: true,
    },
    override: {
      enabled: true,
      rangeEnabled: true,
      value: 0.3,
    },
    restored: {
      enabled: false,
      value: 0.14,
    },
    lightSurfaceTranslucent: true,
    reopened: {
      fit: "contain",
      surface: "55",
      blur: "8",
      borders: false,
      overrideEnabled: false,
      mediaSame: true,
    },
    crossWindow: {
      mediaSame: true,
      surface: "60",
      fit: "contain",
      chatOverride: 0.44,
      settingsOverride: 0.7,
    },
  });

  const second = await evaluateInPage(
    port,
    `(async () => {
      await globalThis.__codexWallpaperApi.disable();
      const cleared =
        !document.getElementById("${rootId}-style") &&
        getComputedStyle(document.querySelector("[data-app-shell-main-surface]")).backdropFilter === "none";
      await globalThis.__codexWallpaperApi.enable();
      const root = document.getElementById("${rootId}");
      for (let attempt = 0; attempt < 80; attempt += 1) {
        const image = root?.querySelector(".media:not(.staged) img");
        if (image?.complete && image.naturalWidth > 0) break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      const controls = document.getElementById("${controlRootId}");
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const panel = controls.querySelector("[data-codex-wallpaper-panel]");
      return {
        cleared,
        state: globalThis.__codexWallpaperApi.state().state,
        fit: getComputedStyle(root.querySelector(".media img")).objectFit,
        surface:
          panel.querySelector("[data-setting='surfaceOpacity']").value,
        settingsOverride: Number(getComputedStyle(panel).backgroundColor.match(/\\/\\s*([\\d.]+)\\s*\\)$/)?.[1])
      };
    })()`,
    options
  );
  assert.deepEqual(second, {
    cleared: true,
    state: "enabled",
    fit: "contain",
    surface: "60",
    settingsOverride: 0.7,
  });
});

test("scene fit uses the installed renderer without replacing the active scene", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const image =
    "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E";
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-scene",
          title: "Fixture Scene",
          type: "scene",
          playable: true,
          fallback: true,
          previewDataUrl: image,
          assetDataUrl: "data:application/octet-stream;base64,AA==",
          reason: "scene-native",
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `localStorage.setItem(
      "codex-wallpaper-p1-config",
      JSON.stringify({
        enabled: true,
        active: { kind: "workshop", id: "fixture-scene" },
        favorites: [],
        playlist: [],
        settings: {
          dim: 18,
          blur: 0,
          opacity: 100,
          fitMode: "contain",
          surfaceOpacity: 72,
          interfaceBlur: 0,
          interfaceBorders: true,
          surfaceOverrides: { chat: null, sidebar: null, right: null, settings: null },
          fps: 30,
          volume: 0,
          muted: true,
          rotationMinutes: 0,
          performanceProfile: "balanced",
          pauseWhenHidden: true
        }
      })
    );
    globalThis.__sceneFitCalls = [];
    globalThis.WebWallGL = {
      bytesSource: () => ({}),
      createScene: (host, sceneOptions) => {
        globalThis.__sceneInitialFit = sceneOptions.fit;
        const canvas = document.createElement("canvas");
        host.append(canvas);
        return {
          load: () => Promise.resolve(),
          pause: () => {},
          resume: () => {},
          setFps: () => {},
          setVolume: () => {},
          setFit: (fit) => globalThis.__sceneFitCalls.push(fit),
          destroy: () => {}
        };
      }
    };`,
    options
  );
  await applyStaticBackground(port, options);

  const result = await evaluateInPage(
    port,
    `(async () => {
      const root = document.getElementById("${rootId}");
      const controls = document.getElementById("${controlRootId}");
      for (let attempt = 0; attempt < 80; attempt += 1) {
        if (root.querySelector(".media:not(.staged) .scene-host.ready")) break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      const media = root.querySelector(".media:not(.staged)");
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const panel = controls.querySelector("[data-codex-wallpaper-panel]");
      panel.querySelector("[data-panel-page='appearance']").click();
      const fit = panel.querySelector("[data-setting='fitMode']");
      const before = {
        available: Boolean(fit),
        enabled: !fit.disabled,
        value: fit.value,
        initialRendererFit: globalThis.__sceneInitialFit
      };
      fit.value = "cover";
      fit.dispatchEvent(new Event("change", { bubbles: true }));
      return {
        before,
        after: {
          value: fit.value,
          calls: globalThis.__sceneFitCalls,
          mediaSame: root.querySelector(".media:not(.staged)") === media
        }
      };
    })()`,
    options
  );

  assert.deepEqual(result, {
    before: {
      available: true,
      enabled: true,
      value: "contain",
      initialRendererFit: "contain",
    },
    after: {
      value: "cover",
      calls: ["contain", "cover"],
      mediaSame: true,
    },
  });
});

test("settings presets import export migration and scoped resets form a complete loop", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const image =
    "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E";
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-image",
          title: "Fixture Image",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl: image,
          assetDataUrl: image,
          reason: null,
        },
      ],
    },
  };
  await waitForPage(port, options);
  await evaluateInPage(
    port,
    `localStorage.setItem(
      "codex-wallpaper-p1-config",
      JSON.stringify({
        enabled: true,
        active: { kind: "workshop", id: "fixture-image" },
        favorites: [{ kind: "workshop", id: "fixture-image" }],
        playlist: [{ kind: "workshop", id: "fixture-image" }],
        settings: {
          dim: 25,
          blur: 2,
          opacity: 90,
          fps: 30,
          volume: 20,
          rotationMinutes: 0,
          pauseWhenHidden: false,
          legacyPath: "C:\\\\private\\\\wallpaper",
          surfaceOverrides: {
            chat: null,
            sidebar: null,
            right: null,
            settings: null,
            unknown: 77
          }
        }
      })
    )`,
    options
  );
  await applyStaticBackground(port, options);

  const result = await evaluateInPage(
    port,
    `(async () => {
      const root = document.getElementById("${rootId}");
      const controls = document.getElementById("${controlRootId}");
      const media = root.querySelector(".media:not(.staged)");
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const panel = controls.querySelector("[data-codex-wallpaper-panel]");
      panel.querySelector("[data-panel-page='appearance']").click();
      const recovery = panel.querySelector("[data-preset-section]");

      const migrated = {
        active: globalThis.__codexWallpaperApi.state().activeId,
        favorite: panel
          .querySelector("[data-entry-action='favorite']")
          .getAttribute("aria-pressed"),
        playlist: panel.querySelector(".playlist-summary").textContent,
        fitMode: panel.querySelector("[data-setting='fitMode']").value,
        surfaceOpacity:
          panel.querySelector("[data-setting='surfaceOpacity']").value,
        profile: panel.querySelector("[data-playback-profile]").value
      };

      const dim = panel.querySelector("[data-setting='dim']");
      dim.value = "33";
      dim.dispatchEvent(new Event("input", { bubbles: true }));
      const volume = panel.querySelector("[data-setting='volume']");
      volume.value = "45";
      volume.dispatchEvent(new Event("input", { bubbles: true }));
      const name = recovery.querySelector("[data-preset-name-input]");
      name.value = "Night";
      recovery.querySelector("[data-preset-save]").click();
      const savedPreset = JSON.parse(
        localStorage.getItem("codex-wallpaper-p1-config")
      ).presets[0];

      dim.value = "50";
      dim.dispatchEvent(new Event("input", { bubbles: true }));
      const beforeRemoteEdit = localStorage.getItem(
        "codex-wallpaper-p1-config"
      );
      const remoteDuringEdit = JSON.stringify({
        ...JSON.parse(beforeRemoteEdit),
        activePresetId: "night",
        settings: {
          ...JSON.parse(beforeRemoteEdit).settings,
          dim: 33,
          performanceProfile: "custom"
        }
      });
      localStorage.setItem("codex-wallpaper-p1-config", remoteDuringEdit);
      dispatchEvent(
        new StorageEvent("storage", {
          key: "codex-wallpaper-p1-config",
          oldValue: beforeRemoteEdit,
          newValue: remoteDuringEdit,
          storageArea: localStorage
        })
      );
      await new Promise((resolve) => setTimeout(resolve, 120));
      const afterRemoteEdit = JSON.parse(
        localStorage.getItem("codex-wallpaper-p1-config")
      );
      const customAfterEdit = {
        dim: afterRemoteEdit.settings.dim,
        activePresetId: afterRemoteEdit.activePresetId,
        profile: afterRemoteEdit.settings.performanceProfile
      };

      recovery
        .querySelector("[data-preset-apply='night']")
        .click();
      const applied = {
        dim: panel.querySelector("[data-setting='dim']").value,
        volume: panel.querySelector("[data-setting='volume']").value,
        activePresetId: JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        ).activePresetId,
        mediaSame: root.querySelector(".media:not(.staged)") === media
      };

      const rename = recovery.querySelector("[data-preset-name='night']");
      rename.value = "Night A";
      recovery.querySelector("[data-preset-rename='night']").click();
      const renamed = {
        text: recovery.querySelector("[data-preset-name='night']").value,
        stored: JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        ).presets[0].name
      };

      const originalCreate = URL.createObjectURL;
      let exportedBlob = null;
      URL.createObjectURL = (blob) => {
        exportedBlob = blob;
        return "blob:fixture-settings";
      };
      recovery.querySelector("[data-settings-export]").click();
      URL.createObjectURL = originalCreate;
      const exportedText = await exportedBlob.text();
      const exported = JSON.parse(exportedText);

      const previous = localStorage.getItem("codex-wallpaper-p1-config");
      const next = JSON.stringify({
        ...JSON.parse(previous),
        activePresetId: null,
        settings: {
          ...JSON.parse(previous).settings,
          dim: 41
        }
      });
      localStorage.setItem("codex-wallpaper-p1-config", next);
      const syncedMedia = root.querySelector(".media:not(.staged)");
      dispatchEvent(
        new StorageEvent("storage", {
          key: "codex-wallpaper-p1-config",
          oldValue: previous,
          newValue: next,
          storageArea: localStorage
        })
      );
      await new Promise((resolve) => setTimeout(resolve, 30));
      const crossWindow = {
        dim: panel.querySelector("[data-setting='dim']").value,
        activePreset:
          recovery
            .querySelector("[data-preset-id='night']")
            .getAttribute("data-active"),
        mediaSame: root.querySelector(".media:not(.staged)") === syncedMedia
      };

      const settingsImport = recovery.querySelector("[data-settings-import]");
      recovery.querySelector("[data-settings-status]").textContent = "";
      const validTransfer = new DataTransfer();
      validTransfer.items.add(
        new File(
          [exportedText],
          "valid-settings.json",
          { type: "application/json" }
        )
      );
      settingsImport.files = validTransfer.files;
      settingsImport.dispatchEvent(new Event("change", { bubbles: true }));
      for (let attempt = 0; attempt < 40; attempt += 1) {
        if (recovery.querySelector("[data-settings-status]").textContent)
          break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      const imported = {
        dim: panel.querySelector("[data-setting='dim']").value,
        fitMode: panel.querySelector("[data-setting='fitMode']").value,
        volume: panel.querySelector("[data-setting='volume']").value,
        activePresetId: JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        ).activePresetId,
        activePresetUi:
          recovery
            .querySelector("[data-preset-id='night']")
            .getAttribute("data-active"),
        mediaSame: root.querySelector(".media:not(.staged)") === media,
        status: recovery.querySelector("[data-settings-status]").textContent
      };
      panel.querySelector("header button").click();
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const importedReopened = {
        dim: panel.querySelector("[data-setting='dim']").value,
        fitMode:
          panel.querySelector("[data-setting='fitMode']")?.value ?? null,
        volume: panel.querySelector("[data-setting='volume']").value
      };

      const beforeInvalid = localStorage.getItem("codex-wallpaper-p1-config");
      recovery.querySelector("[data-settings-status]").textContent = "";
      const invalidTransfer = new DataTransfer();
      invalidTransfer.items.add(
        new File(
          [
            JSON.stringify({
              version: 99,
              settings: { dim: 999, opacity: "broken" }
            })
          ],
          "invalid-settings.json",
          { type: "application/json" }
        )
      );
      settingsImport.files = invalidTransfer.files;
      settingsImport.dispatchEvent(new Event("change", { bubbles: true }));
      for (let attempt = 0; attempt < 40; attempt += 1) {
        if (recovery.querySelector("[data-settings-status]").textContent)
          break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      const invalid = {
        unchanged:
          localStorage.getItem("codex-wallpaper-p1-config") === beforeInvalid,
        status: recovery.querySelector("[data-settings-status]").textContent
      };
      const beforeInvalidRange = localStorage.getItem(
        "codex-wallpaper-p1-config"
      );
      recovery.querySelector("[data-settings-status]").textContent = "";
      const invalidRangeTransfer = new DataTransfer();
      invalidRangeTransfer.items.add(
        new File(
          [
            JSON.stringify({
              version: 1,
              settings: { dim: 999 }
            })
          ],
          "invalid-range.json",
          { type: "application/json" }
        )
      );
      settingsImport.files = invalidRangeTransfer.files;
      settingsImport.dispatchEvent(new Event("change", { bubbles: true }));
      for (let attempt = 0; attempt < 40; attempt += 1) {
        if (recovery.querySelector("[data-settings-status]").textContent)
          break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      const invalidRange = {
        unchanged:
          localStorage.getItem("codex-wallpaper-p1-config") ===
          beforeInvalidRange,
        status: recovery.querySelector("[data-settings-status]").textContent
      };
      recovery.querySelector("[data-settings-status]").textContent = "";
      const mismatchTransfer = new DataTransfer();
      mismatchTransfer.items.add(
        new File(
          [
            JSON.stringify({
              version: 1,
              settings: {
                ...exported.settings,
                fps: 17,
                pauseWhenHidden: false,
                performanceProfile: "balanced"
              }
            })
          ],
          "mismatched-profile.json",
          { type: "application/json" }
        )
      );
      settingsImport.files = mismatchTransfer.files;
      settingsImport.dispatchEvent(new Event("change", { bubbles: true }));
      for (let attempt = 0; attempt < 40; attempt += 1) {
        if (recovery.querySelector("[data-settings-status]").textContent)
          break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      const normalizedProfile = {
        profile: panel.querySelector("[data-playback-profile]").value,
        fps: globalThis.__codexWallpaperApi.state().fpsCap,
        status: recovery.querySelector("[data-settings-status]").textContent
      };

      recovery.querySelector("[data-reset-group='appearance']").click();
      const appearanceReset = {
        dim: panel.querySelector("[data-setting='dim']").value,
        fitMode: panel.querySelector("[data-setting='fitMode']").value,
        activeId: globalThis.__codexWallpaperApi.state().activeId,
        favorite: panel
          .querySelector("[data-entry-action='favorite']")
          .getAttribute("aria-pressed"),
        playlist: panel.querySelector(".playlist-summary").textContent
      };
      recovery.querySelector("[data-reset-group='playback']").click();
      const playbackReset = {
        volume: panel.querySelector("[data-setting='volume']").value,
        fps: globalThis.__codexWallpaperApi.state().fpsCap,
        profile: panel.querySelector("[data-playback-profile]").value
      };
      recovery.querySelector("[data-reset-group='all']").click();
      const allReset = {
        dim: panel.querySelector("[data-setting='dim']").value,
        volume: panel.querySelector("[data-setting='volume']").value,
        activeId: globalThis.__codexWallpaperApi.state().activeId,
        favorite: panel
          .querySelector("[data-entry-action='favorite']")
          .getAttribute("aria-pressed"),
        playlist: panel.querySelector(".playlist-summary").textContent
      };

      const mediaImport = panel.querySelector(".import-row input");
      const mediaTransfer = new DataTransfer();
      mediaTransfer.items.add(
        new File(
          ["<svg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/>"],
          "Remove Me.svg",
          { type: "image/svg+xml" }
        )
      );
      mediaImport.files = mediaTransfer.files;
      mediaImport.dispatchEvent(new Event("change", { bubbles: true }));
      for (let attempt = 0; attempt < 40; attempt += 1) {
        if (globalThis.__codexWallpaperApi.state().importedCount > 0) break;
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      const importedBeforeRemove =
        globalThis.__codexWallpaperApi.state().importedCount;
      panel.querySelector("[data-panel-page='library']").click();
      panel.querySelector("[data-remove-imported]").click();
      for (let attempt = 0; attempt < 40; attempt += 1) {
        if (globalThis.__codexWallpaperApi.state().importedCount === 0) break;
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      const removedImported = {
        before: importedBeforeRemove,
        after: globalThis.__codexWallpaperApi.state().importedCount,
        state: globalThis.__codexWallpaperApi.state().state,
        activeKind: globalThis.__codexWallpaperApi.state().activeKind,
        activeId: globalThis.__codexWallpaperApi.state().activeId,
        favorite: panel
          .querySelector("[data-entry-action='favorite']")
          .getAttribute("aria-pressed")
      };

      panel.querySelector("header button").click();
      controls.querySelector("[data-codex-wallpaper-settings]").click();
      const reopened = {
        presetName: panel.querySelector("[data-preset-name='night']").value,
        presetCount: panel.querySelectorAll("[data-preset-id]").length
      };
      return {
        migrated,
        savedPreset,
        customAfterEdit,
        applied,
        renamed,
        exported,
        crossWindow,
        imported,
        importedReopened,
        invalid,
        invalidRange,
        normalizedProfile,
        appearanceReset,
        playbackReset,
        allReset,
        removedImported,
        reopened
      };
    })()`,
    options
  );

  assert.deepEqual(result.migrated, {
    active: "fixture-image",
    favorite: "true",
    playlist: "轮播：Fixture Image",
    fitMode: "cover",
    surfaceOpacity: "72",
    profile: "custom",
  });
  assert.equal(result.savedPreset.id, "night");
  assert.equal(result.savedPreset.name, "Night");
  assert.equal(result.savedPreset.settings.dim, 33);
  assert.equal(result.savedPreset.settings.volume, 45);
  assert.deepEqual(result.customAfterEdit, {
    dim: 50,
    activePresetId: null,
    profile: "custom",
  });
  assert.deepEqual(result.applied, {
    dim: "33",
    volume: "45",
    activePresetId: "night",
    mediaSame: true,
  });
  assert.deepEqual(result.renamed, {
    text: "Night A",
    stored: "Night A",
  });
  assert.equal(result.exported.version, 1);
  assert.deepEqual(Object.keys(result.exported), ["version", "settings"]);
  assert.equal("favorites" in result.exported, false);
  assert.equal("active" in result.exported, false);
  assert.equal("legacyPath" in result.exported.settings, false);
  assert.equal("unknown" in result.exported.settings.surfaceOverrides, false);
  assert.equal(result.exported.settings.dim, 33);
  assert.deepEqual(result.crossWindow, {
    dim: "41",
    activePreset: "false",
    mediaSame: true,
  });
  assert.deepEqual(result.imported, {
    dim: "33",
    fitMode: "cover",
    volume: "45",
    activePresetId: null,
    activePresetUi: "false",
    mediaSame: true,
    status: "设置已导入",
  });
  assert.deepEqual(result.importedReopened, {
    dim: "33",
    fitMode: "cover",
    volume: "45",
  });
  assert.equal(result.invalid.unchanged, true);
  assert.match(result.invalid.status, /^导入失败：/);
  assert.equal(result.invalidRange.unchanged, true);
  assert.match(result.invalidRange.status, /^导入失败：/);
  assert.deepEqual(result.normalizedProfile, {
    profile: "custom",
    fps: 17,
    status: "设置已导入",
  });
  assert.deepEqual(result.appearanceReset, {
    dim: "18",
    fitMode: "cover",
    activeId: "fixture-image",
    favorite: "true",
    playlist: "轮播：Fixture Image",
  });
  assert.deepEqual(result.playbackReset, {
    volume: "0",
    fps: 30,
    profile: "balanced",
  });
  assert.deepEqual(result.allReset, {
    dim: "18",
    volume: "0",
    activeId: "fixture-image",
    favorite: "true",
    playlist: "轮播：Fixture Image",
  });
  assert.deepEqual(result.removedImported, {
    before: 1,
    after: 0,
    state: "enabled",
    activeKind: "builtin",
    activeId: "aurora",
    favorite: "true",
  });
  assert.deepEqual(result.reopened, {
    presetName: "Night A",
    presetCount: 1,
  });
});

test("static background is single, removable and persists disabled", async (t) => {
  const { fixture, port } = await startBrowserFixture(t);
  const options = {
    page: fixture.url,
    origin: new URL(fixture.url).origin,
    payload: {
      version: 1,
      library: [
        {
          id: "fixture-image",
          title: "Fixture Image",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          assetDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%235d32b8'/%3E%3C/svg%3E",
          reason: null,
        },
        {
          id: "fixture-video",
          title: "Fixture Video",
          type: "video",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl: `data:video/mp4;base64,${tinyMp4}`,
          reason: "asset-too-large-or-missing",
        },
        {
          id: "fixture-scene",
          title: "Fixture Scene",
          type: "scene",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl: "data:application/octet-stream;base64,AA==",
          reason: "scene-native",
        },
        {
          id: "fixture-web",
          title: "Fixture Web",
          type: "web",
          playable: false,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl: null,
          webHtml:
            "<!doctype html><style>body{margin:0;background:linear-gradient(45deg,#123,#abc)}</style>",
          reason: "web-offline",
        },
        {
          id: "fixture-web-fallback",
          title: "Fixture Web Fallback",
          type: "web",
          playable: false,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl: null,
          webHtml: null,
          reason: "web-preview-fallback",
        },
        {
          id: "fixture-on-demand",
          title: "Fixture On Demand",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%23fb923c'/%3E%3C/svg%3E",
          assetDataUrl: null,
          reason: "asset-not-loaded",
        },
        {
          id: "fixture-lazy",
          title: "Fixture Lazy",
          type: "image",
          playable: false,
          fallback: true,
          previewDataUrl: null,
          assetDataUrl: null,
          reason: "asset-not-loaded",
        },
      ],
    },
  };
  await waitForPage(port, options);
  const pressAltShiftW = async () => {
    for (const type of ["rawKeyDown", "keyUp"]) {
      await callMainPage(
        port,
        "Input.dispatchKeyEvent",
        {
          type,
          key: "W",
          code: "KeyW",
          windowsVirtualKeyCode: 87,
          nativeVirtualKeyCode: 87,
          modifiers: 9,
        },
        options.page,
        true
      );
    }
  };
  const waitForWallpaperImage = () =>
    evaluateInPage(
      port,
      `(async () => {
        for (let attempt = 0; attempt < 80; attempt += 1) {
          const image = document.querySelector(
            "#${rootId} .media:not(.staged) img"
          );
          if (
            globalThis.__codexWallpaperApi.state().state === "enabled" &&
            image?.complete &&
            image.naturalWidth > 0
          )
            return;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
      })()`,
      options
    );

  assert.deepEqual(
    await evaluateInPage(
      port,
      "({ href: location.href, origin: location.origin, ready: document.readyState })",
      options
    ),
    {
      href: fixture.url,
      origin: new URL(fixture.url).origin,
      ready: "complete",
    }
  );
  await assert.rejects(
    applyStaticBackground(port, { ...options, page: `${fixture.url}other` }),
    /Main page not uniquely available/
  );
  await evaluateInPage(
    port,
    `(() => {
      globalThis.WebWallGL = {
        bytesSource: () => ({}),
        createScene: (host) => {
          const canvas = document.createElement("canvas");
          canvas.dataset.sceneCanvas = "";
          if (getComputedStyle(host).position === "static")
            host.style.position = "relative";
          canvas.style.cssText =
            "position:absolute;inset:0;width:100%;height:100%;display:block";
          host.append(canvas);
          return {
            load: () =>
              new Promise((resolve, reject) => {
                globalThis.__sceneResolve = () => {
                  globalThis.__sceneLoaded = true;
                  resolve();
                };
                globalThis.__sceneReject = reject;
              }),
            pause: () => {
              globalThis.__scenePaused = true;
            },
            resume: () => {
              globalThis.__sceneResumed = true;
            },
            setFps: (fps) => {
              globalThis.__sceneFps = fps;
            },
            setVolume: (volume) => {
              globalThis.__sceneVolume = volume;
            },
            destroy() {}
          };
        }
      };
    })()`,
    options
  );
  const initial = await applyStaticBackground(port, options);
  assert.equal(initial.state, "enabled");
  assert.equal(initial.backgroundLayers, 1);
  assert.equal(initial.styles, 1);
  assert.equal(initial.libraryCount, 7);
  assert.equal(initial.volume, 0);
  assert.equal(initial.fpsCap, 30);
  assert.equal(initial.visible, true);
  assert.ok(initial.controls >= 2);
  assert.deepEqual(
    await evaluateInPage(
      port,
      `document.querySelector("#${controlRootId} [data-codex-wallpaper-settings]").click(),
       (() => {
         const panel = document.querySelector("#${controlRootId} [data-codex-wallpaper-panel]");
         return {
           open: panel.classList.contains("open"),
           cards: panel.querySelectorAll(".card").length
         };
       })()`,
      options
    ),
    { open: true, cards: 7 }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const panel = document.querySelector(
          "#${controlRootId} [data-codex-wallpaper-panel]"
        );
        const card = [...panel.querySelectorAll(".card")].find(
          (item) => item.querySelector("strong")?.textContent === "Fixture Lazy"
        );
        const settings = panel.querySelector(".settings-grid").firstElementChild;
        panel.scrollTop = 80;
        await globalThis.__codexWallpaperApi.receivePreview({
          id: "fixture-lazy",
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          fallback: true
        });
        return {
          sameCard:
            [...panel.querySelectorAll(".card")].find(
              (item) => item.querySelector("strong")?.textContent === "Fixture Lazy"
            ) === card,
          sameSettings: panel.querySelector(".settings-grid").firstElementChild === settings,
          previewAttached: Boolean(card.querySelector(".thumb img")),
          placeholderRemaining: Boolean(card.querySelector(".thumb[data-preview-id]")),
          scrollTop: panel.scrollTop
        };
      })()`,
      options
    ),
    {
      sameCard: true,
      sameSettings: true,
      previewAttached: true,
      placeholderRemaining: false,
      scrollTop: 80,
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const state = await globalThis.__codexWallpaperApi.configureHost();
        const controls = document.getElementById("${controlRootId}");
        const webCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Web"
        );
        return {
          hostReady: state.hostReady,
          meta: webCard.querySelector("small")?.textContent
        };
      })()`,
      options
    ),
    { hostReady: true, meta: "web · 离线沙箱" }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        let hostRequests = 0;
        globalThis.__codexWallpaperHostRequest = (raw) => {
          const request = JSON.parse(raw);
          if (request.type === "load-asset") hostRequests += 1;
        };
        const controls = document.getElementById("${controlRootId}");
        const fallbackCard = [...controls.querySelectorAll(".card")].find(
          (card) =>
            card.querySelector("strong")?.textContent ===
            "Fixture Web Fallback"
        );
        fallbackCard.querySelector(".card-actions button").click();
        await new Promise((resolve) => setTimeout(resolve, 20));
        return {
          hostRequests,
          meta: controls
            .querySelector(
              ".card[data-entry-id='fixture-web-fallback'] [data-card-status]"
            )?.textContent,
          preview:
            document.querySelector(
              "#${rootId} .media:not(.staged) img"
            )?.naturalWidth > 0,
          status: controls.querySelector(".runtime-status")?.textContent
        };
      })()`,
      options
    ),
    {
      hostRequests: 0,
      meta: "web · 预览降级",
      preview: true,
      status: "Fixture Web Fallback · Web 预览降级",
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        const imageCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Image"
        );
        imageCard.querySelector(".card-actions button").click();
        for (let attempt = 0; attempt < 40; attempt += 1) {
          const image = root.querySelector(".media img");
          if (
            image?.complete &&
            image.naturalWidth > 0 &&
            !image.closest(".media.staged")
          )
            break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const oldImage = root.querySelector(".media img");
        const originalFrameCallback =
          HTMLVideoElement.prototype.requestVideoFrameCallback;
        let videoFrameCallback = null;
        HTMLVideoElement.prototype.requestVideoFrameCallback = (callback) => {
          videoFrameCallback = () => callback(performance.now(), {});
          return 1;
        };
        const videoCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Video"
        );
        videoCard.querySelector(".card-actions button").click();
        for (
          let attempt = 0;
          attempt < 40 &&
          (typeof videoFrameCallback !== "function" ||
            root.querySelector(".media video")?.readyState < 2);
          attempt += 1
        ) {
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const beforeFrame = {
          callbackAvailable: typeof videoFrameCallback === "function",
          oldFrameStillVisible: root.querySelector(".media img") === oldImage,
          fullWindowPreview: Boolean(
            root.querySelector(".media-preview")
          )
        };
        const originalRequestAnimationFrame = window.requestAnimationFrame;
        let drawLoopFrames = 0;
        window.requestAnimationFrame = (callback) => {
          drawLoopFrames += 1;
          return originalRequestAnimationFrame(callback);
        };
        videoFrameCallback?.();
        await new Promise((resolve) => setTimeout(resolve, 120));
        window.requestAnimationFrame = originalRequestAnimationFrame;
        const canvas = root.querySelector(".media canvas");
        const video = root.querySelector(".media:not(.staged) video");
        const afterFrame = {
          oldFrameReleased: !oldImage.isConnected,
          previewGone: !root.querySelector(".media-preview"),
          videoVisible:
            video?.getBoundingClientRect().width ===
              root.querySelector(".media").clientWidth &&
            video?.getBoundingClientRect().height ===
              root.querySelector(".media").clientHeight,
          directVideo: !canvas,
          drawLoopFrames,
          objectFit: video ? getComputedStyle(video).objectFit : null,
          playerCount: globalThis.__codexWallpaperApi.state().playerCount
        };
        HTMLVideoElement.prototype.requestVideoFrameCallback =
          originalFrameCallback;
        return { beforeFrame, afterFrame };
      })()`,
      options
    ),
    {
      beforeFrame: {
        callbackAvailable: true,
        oldFrameStillVisible: true,
        fullWindowPreview: false,
      },
      afterFrame: {
        oldFrameReleased: true,
        previewGone: true,
        videoVisible: true,
        directVideo: true,
        drawLoopFrames: 0,
        objectFit: "cover",
        playerCount: 1,
      },
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        const imageCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Image"
        );
        imageCard.querySelector(".card-actions button").click();
        for (let attempt = 0; attempt < 40; attempt += 1) {
          const image = root.querySelector(".media img");
          if (
            image?.src.includes("5d32b8") &&
            image.complete &&
            !image.closest(".media.staged")
          )
            break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const oldImage = root.querySelector(".media img");
        globalThis.__codexWallpaperApi.receiveAsset({
          id: "fixture-video",
          title: "Fixture Video",
          type: "video",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl: "data:video/mp4;base64,AAAA",
          reason: null
        });
        const videoCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Video"
        );
        videoCard.querySelector(".card-actions button").click();
        for (let attempt = 0; attempt < 40; attempt += 1) {
          if (
            controls
              .querySelector(".runtime-status")
              ?.textContent.includes("视频加载失败")
          )
            break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const result = {
          oldFrameRetained: root.querySelector(".media img") === oldImage,
          previewShown: Boolean(root.querySelector(".media-preview")),
          status: controls.querySelector(".runtime-status")?.textContent
        };
        globalThis.__codexWallpaperApi.receiveAsset({
          id: "fixture-video",
          title: "Fixture Video",
          type: "video",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl: "data:video/mp4;base64,${tinyMp4}",
          reason: null
        });
        imageCard.querySelector(".card-actions button").click();
        return result;
      })()`,
      options
    ),
    {
      oldFrameRetained: true,
      previewShown: false,
      status: "视频加载失败，已保留当前画面",
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const originalPlay = HTMLMediaElement.prototype.play;
        let playCalls = 0;
        HTMLMediaElement.prototype.play = () => {
          playCalls += 1;
          return playCalls === 1
            ? Promise.reject(new DOMException("Paused to save power", "NotAllowedError"))
            : Promise.resolve();
        };
        const controls = document.getElementById("${controlRootId}");
        const videoCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Video"
        );
        videoCard.querySelector(".card-actions button").click();
        for (let attempt = 0; attempt < 40; attempt += 1) {
          if (
            document.querySelector(
              "#${rootId} .media:not(.staged) video"
            )
          )
            break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const videoAfterRejectedPlay =
          document.querySelector("#${rootId} video") instanceof HTMLVideoElement;
        const originalRequestAnimationFrame = window.requestAnimationFrame;
        let drawLoopFrames = 0;
        window.requestAnimationFrame = (callback) => {
          drawLoopFrames += 1;
          return originalRequestAnimationFrame(callback);
        };
        Object.defineProperty(document, "visibilityState", {
          configurable: true,
          get: () => "hidden"
        });
        document.dispatchEvent(new Event("visibilitychange"));
        Object.defineProperty(document, "visibilityState", {
          configurable: true,
          get: () => "visible"
        });
        document.dispatchEvent(new Event("visibilitychange"));
        await new Promise((resolve) => setTimeout(resolve, 80));
        window.requestAnimationFrame = originalRequestAnimationFrame;
        const result = {
          videoAfterRejectedPlay,
          videoAfterVisible:
            document.querySelector("#${rootId} video") instanceof HTMLVideoElement,
          playCalls,
          drawLoopFrames,
          status: controls.querySelector(".runtime-status")?.textContent
        };
        HTMLMediaElement.prototype.play = originalPlay;
        return result;
      })()`,
      options
    ),
    {
      videoAfterRejectedPlay: true,
      videoAfterVisible: true,
      playCalls: 2,
      drawLoopFrames: 0,
      status: "Fixture Video · 视频",
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const api = globalThis.__codexWallpaperApi;
        const originalFrameCallback =
          HTMLVideoElement.prototype.requestVideoFrameCallback;
        const originalCancelFrameCallback =
          HTMLVideoElement.prototype.cancelVideoFrameCallback;
        let presentedFrame = null;
        HTMLVideoElement.prototype.requestVideoFrameCallback = (callback) => {
          presentedFrame = callback;
          return 1;
        };
        HTMLVideoElement.prototype.cancelVideoFrameCallback = () => {};
        api.beginAssetTransfer({
          id: "fixture-video",
          title: "Fixture Video",
          type: "video",
          playable: true,
          fallback: false,
          previewDataUrl: null,
          assetDataUrl: null,
          assetUrl: null,
          webHtml: null,
          reason: null,
          mime: "video/mp4",
          size: ${Buffer.from(tinyMp4, "base64").length}
        });
        api.appendAssetTransferChunk("fixture-video", ${JSON.stringify(tinyMp4)});
        await api.finishAssetTransfer("fixture-video");
        for (let attempt = 0; attempt < 160; attempt += 1) {
          const stagedVideo =
            document.querySelector("#${rootId} .media.staged video");
          if (typeof presentedFrame === "function" && stagedVideo?.readyState >= 2)
            break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        presentedFrame?.(performance.now(), {});
        for (let attempt = 0; attempt < 160; attempt += 1) {
          const activeVideo = document.querySelector(
            "#${rootId} .media:not(.staged) video"
          );
          if (
            api.state().playerCount === 1 &&
            activeVideo?.src.startsWith("blob:")
          )
            break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const video = document.querySelector(
          "#${rootId} .media:not(.staged) video"
        );
        const result = {
          playerCount: api.state().playerCount,
          blobUrl: video?.src.startsWith("blob:") ?? false
        };
        HTMLVideoElement.prototype.requestVideoFrameCallback =
          originalFrameCallback;
        HTMLVideoElement.prototype.cancelVideoFrameCallback =
          originalCancelFrameCallback;
        return result;
      })()`,
      options
    ),
    { playerCount: 1, blobUrl: true }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        const imageCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Image"
        );
        imageCard.querySelector(".card-actions button").click();
        for (let attempt = 0; attempt < 40; attempt += 1) {
          const image = root.querySelector(".media:not(.staged) img");
          if (image?.complete && image.naturalWidth > 0) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        Object.defineProperty(document, "visibilityState", {
          configurable: true,
          get: () => "hidden"
        });
        document.dispatchEvent(new Event("visibilitychange"));
        const originalFrameCallback =
          HTMLVideoElement.prototype.requestVideoFrameCallback;
        HTMLVideoElement.prototype.requestVideoFrameCallback = () => 1;
        const videoCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Video"
        );
        videoCard.querySelector(".card-actions button").click();
        for (let attempt = 0; attempt < 80; attempt += 1) {
          if (root.querySelector(".media:not(.staged) video")) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const result = {
          activeVideo: Boolean(root.querySelector(".media:not(.staged) video")),
          staged: root.querySelectorAll(".media.staged").length,
          preview: Boolean(root.querySelector(".media-preview"))
        };
        Object.defineProperty(document, "visibilityState", {
          configurable: true,
          get: () => "visible"
        });
        document.dispatchEvent(new Event("visibilitychange"));
        HTMLVideoElement.prototype.requestVideoFrameCallback =
          originalFrameCallback;
        await new Promise((resolve) => setTimeout(resolve, 40));
        return result;
      })()`,
      options
    ),
    { activeVideo: true, staged: 0, preview: false }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const media = document.querySelector("#${rootId} .media");
        let mutations = 0;
        const observer = new MutationObserver(() => {
          mutations += 1;
        });
        observer.observe(media, { childList: true });
        globalThis.__codexWallpaperApi.receivePreview({
          id: "fixture-video",
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          fallback: true
        });
        await new Promise((resolve) => setTimeout(resolve, 20));
        observer.disconnect();
        return {
          mutations,
          playerCount: globalThis.__codexWallpaperApi.state().playerCount
        };
      })()`,
      options
    ),
    { mutations: 0, playerCount: 1 }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        globalThis.__codexWallpaperHostRequest = (raw) => {
          const request = JSON.parse(raw);
          if (request.type !== "load-asset") return;
          globalThis.__pendingLoadRequest = request;
        };
        const root = document.getElementById("${rootId}");
        globalThis.__codexWallpaperApi.receivePreview({
          id: "fixture-lazy",
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          fallback: true
        });
        await new Promise((resolve) => setTimeout(resolve, 20));
        const controls = document.getElementById("${controlRootId}");
        const lazyCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Lazy"
        );
        const previewLoaded =
          lazyCard.querySelector(".thumb img") instanceof HTMLImageElement;
        lazyCard.querySelector(".card-actions button").click();
        await new Promise((resolve) => setTimeout(resolve, 20));
        const imageCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Image"
        );
        imageCard.querySelector(".card-actions button").click();
        await new Promise((resolve) => setTimeout(resolve, 20));
        const media = root.querySelector(".media");
        let mutations = 0;
        const observer = new MutationObserver(() => {
          mutations += 1;
        });
        observer.observe(media, { childList: true });
        globalThis.__codexWallpaperApi.receiveAsset({
          id: globalThis.__pendingLoadRequest.id,
          title: "Fixture Lazy",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/%3E",
          assetDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%23123456'/%3E%3C/svg%3E",
          reason: null
        });
        await new Promise((resolve) => setTimeout(resolve, 20));
        observer.disconnect();
        const image = media.querySelector("img");
        return {
          active: globalThis.__codexWallpaperApi.state().activeId,
          mutations,
          imageIsCurrentAsset: image?.src.includes("5d32b8") ?? false,
          previewLoaded
        };
      })()`,
      options
    ),
    {
      active: "fixture-image",
      mutations: 0,
      imageIsCurrentAsset: true,
      previewLoaded: true,
    }
  );
  assert.equal(
    await evaluateInPage(
      port,
      `(() => {
        globalThis.__codexWallpaperApi.receiveAssetError(
          "fixture-image",
          "fixture failure"
        );
        return document.querySelector("#${controlRootId} .runtime-status")
          ?.textContent;
      })()`,
      options
    ),
    "素材加载失败：fixture failure"
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        const sceneCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Scene"
        );
        sceneCard.querySelector(".card-actions button").click();
        await new Promise((resolve) => setTimeout(resolve, 20));
        const oldImage = root.querySelector(".media img");
        const heldWhileSceneLoads =
          oldImage?.src.includes("5d32b8") &&
          !root.querySelector(".media-preview");
        const rejectOldScene = globalThis.__sceneReject;
        const imageCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Image"
        );
        imageCard.querySelector(".card-actions button").click();
        await new Promise((resolve) => setTimeout(resolve, 20));
        rejectOldScene(new Error("Scene superseded"));
        await new Promise((resolve) => setTimeout(resolve, 20));
        const image = root.querySelector("[data-codex-wallpaper-layer] img");
        return {
          activeId: globalThis.__codexWallpaperApi.state().activeId,
          heldWhileSceneLoads,
          imageIsCurrentAsset: image?.src.includes("5d32b8") ?? false,
          mediaCount: root.querySelectorAll(".media:not(.staged)").length,
          staged: root.querySelectorAll(".media.staged").length
        };
      })()`,
      options
    ),
    {
      activeId: "fixture-image",
      heldWhileSceneLoads: true,
      imageIsCurrentAsset: true,
      mediaCount: 1,
      staged: 0,
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        const sceneCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Scene"
        );
        sceneCard.querySelector(".card-actions button").click();
        await new Promise((resolve) => setTimeout(resolve, 20));
        globalThis.__sceneResolve();
        await new Promise((resolve) => setTimeout(resolve, 20));
        Object.defineProperty(document, "visibilityState", {
          configurable: true,
          get: () => "hidden"
        });
        document.dispatchEvent(new Event("visibilitychange"));
        Object.defineProperty(document, "visibilityState", {
          configurable: true,
          get: () => "visible"
        });
        document.dispatchEvent(new Event("visibilitychange"));
        const fps = controls.querySelector("[data-setting='fps']");
        const volume = controls.querySelector("[data-setting='volume']");
        fps.value = "15";
        fps.dispatchEvent(new Event("input", { bubbles: true }));
        volume.value = "40";
        volume.dispatchEvent(new Event("input", { bubbles: true }));
        const canvas = root.querySelector("[data-scene-canvas]");
        const layer = root.querySelector("[data-codex-wallpaper-layer]");
        return {
          loaded: globalThis.__sceneLoaded,
          paused: globalThis.__scenePaused,
          resumed: globalThis.__sceneResumed,
          fps: globalThis.__sceneFps,
          volume: globalThis.__sceneVolume,
          canvasFillsLayer:
            canvas.getBoundingClientRect().height ===
              layer.getBoundingClientRect().height &&
            canvas.getBoundingClientRect().height > 0
        };
      })()`,
      options
    ),
    {
      loaded: true,
      paused: true,
      resumed: true,
      fps: 15,
      volume: 0.4,
      canvasFillsLayer: true,
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        const webCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Web"
        );
        webCard.querySelector(".card-actions button").click();
        await new Promise((resolve) => setTimeout(resolve, 40));
        const frame = root.querySelector("[data-codex-wallpaper-layer] iframe");
        return {
          fillsWallpaperLayer:
            frame.getBoundingClientRect().width === frame.parentElement.clientWidth &&
            frame.getBoundingClientRect().height === frame.parentElement.clientHeight,
          sandbox: frame.getAttribute("sandbox"),
          offlineDocument: frame.srcdoc.includes("linear-gradient"),
          networkBlocked: frame.srcdoc.includes("default-src 'none'")
        };
      })()`,
      options
    ),
    {
      fillsWallpaperLayer: true,
      sandbox: "allow-scripts",
      offlineDocument: true,
      networkBlocked: true,
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        const imageCard = [...controls.querySelectorAll(".card")].find(
          (card) => card.querySelector("strong")?.textContent === "Fixture Image"
        );
        imageCard.querySelector(".card-actions button").click();
        imageCard.querySelectorAll(".card-actions button")[1].click();
        imageCard.querySelectorAll(".card-actions button")[2].click();
        const opacity = controls.querySelector("[data-setting='opacity']");
        opacity.value = "66";
        opacity.dispatchEvent(new Event("input", { bubbles: true }));
        const input = controls.querySelector(".import-row input");
        const transfer = new DataTransfer();
        transfer.items.add(
          new File(
            ["<svg xmlns='http://www.w3.org/2000/svg' width='16' height='9'/>"],
            "Imported.svg",
            { type: "image/svg+xml" }
          )
        );
        input.files = transfer.files;
        input.dispatchEvent(new Event("change", { bubbles: true }));
        for (let attempt = 0; attempt < 40; attempt += 1) {
          if (globalThis.__codexWallpaperApi.state().importedCount > 0) break;
          await new Promise((resolve) => setTimeout(resolve, 50));
        }
        const saved = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        );
        return {
          imageVisible:
            root.querySelector("[data-codex-wallpaper-layer] img") instanceof
            HTMLImageElement,
          favorite: saved.favorites.length,
          playlist: saved.playlist.length,
          opacity: saved.settings.opacity,
          imported: globalThis.__codexWallpaperApi.state().importedCount,
          importedActive: saved.active.kind === "imported"
        };
      })()`,
      options
    ),
    {
      imageVisible: true,
      favorite: 1,
      playlist: 1,
      opacity: 66,
      imported: 1,
      importedActive: true,
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        const reset = controls.querySelector(".reset");
        reset.click();
        reset.click();
        for (let attempt = 0; attempt < 40; attempt += 1) {
          if (globalThis.__codexWallpaperApi.state().importedCount === 0) break;
          await new Promise((resolve) => setTimeout(resolve, 50));
        }
        const saved = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        );
        return {
          activeKind: saved.active.kind,
          imported: globalThis.__codexWallpaperApi.state().importedCount,
          state: globalThis.__codexWallpaperApi.state().state,
          root: document.querySelectorAll("#${rootId}, #${controlRootId}").length
        };
      })()`,
      options
    ),
    { activeKind: "builtin", imported: 0, state: "disabled", root: 0 }
  );
  await evaluateInPage(
    port,
    `(() => {
      const root = document.createElement("div");
      root.id = "${rootId}";
      root.dataset.stale = "";
      const controls = document.createElement("div");
      controls.id = "${controlRootId}";
      controls.dataset.stale = "";
      const style = document.createElement("style");
      style.id = "${rootId}-style";
      style.dataset.stale = "";
      document.documentElement.append(root, controls, style);
    })()`,
    options
  );
  await evaluateInPage(
    port,
    'dispatchEvent(new KeyboardEvent("keydown", { altKey: true, shiftKey: true, code: "KeyW" }))',
    options
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `({
        root: document.querySelectorAll("#${rootId}").length,
        controls: document.querySelectorAll("#${controlRootId}").length,
        styles: document.querySelectorAll("#${rootId}-style").length,
        stale: document.querySelectorAll(
          "#${rootId}[data-stale], #${controlRootId}[data-stale], #${rootId}-style[data-stale]"
        ).length
      })`,
      options
    ),
    { root: 1, controls: 1, styles: 1, stale: 0 }
  );
  const { composerIdleShadow, ...chatResults } = await evaluateInPage(
    port,
    `(() => {
        const root = document.getElementById("${rootId}");
        const background = root.querySelector("[data-codex-wallpaper-layer]");
        const media = root.querySelector(".media");
        const controls = document.getElementById("${controlRootId}");
        const toolbar = controls.querySelector(".toolbar");
        const panel = controls.querySelector("[data-codex-wallpaper-panel]");
        const toolbarRect = toolbar.getBoundingClientRect();
        const toolbarHit = document.elementFromPoint(
          toolbarRect.right - 8,
          toolbarRect.bottom - 8
        );
        const surface = document.querySelector("[data-app-shell-main-surface]");
        const frame = document.querySelector("[data-app-shell-frame]");
        const ordinaryStatus = document.querySelector("#ordinary-status");
        const ordinaryActivity = document.querySelector("#ordinary-activity-header");
        const ordinaryActivityAction = document.querySelector(
          "#ordinary-activity-action"
        );
        const userMessage = document.querySelector("#user-message");
        const userMarkdownAction = document.querySelector("#user-markdown-action");
        const tool = document.querySelector("#tool-action");
        const details = document.querySelector("#tool-details");
        const toolSurface = tool.closest("[data-testid='webmcp-tool-scroll']");
        const summarySurface = document.querySelector(
          "[data-summary-panel-variant]"
        );
        const diffSurface = document.querySelector(
          "[data-thread-find-target='review']"
        );
        const changesCodeSurface = diffSurface.querySelector("pre");
        const codeSurface = document.querySelector("#chat-code");
        const composerSurface = document.querySelector(
          "[data-composer-surface-variant]"
        );
        const footerBackdrop = document.querySelector(
          "[data-thread-scroll-footer] > .thread-footer-backdrop"
        );
        const footerShell = document.querySelector(".thread-scroll-footer-shell");
        const footerLeading = document.querySelector(
          "[data-pip-obstacle='thread-footer-leading']"
        );
        const leftPanel = document.querySelector("[data-app-shell-page-sidebar]");
        const rightPanel = document.querySelector(
          "[data-app-shell-trailing-sidebar]"
        );
        const openChanges = document.querySelector("#open-changes");
        openChanges.scrollIntoView({ block: "center" });
        const openChangesRect = openChanges.getBoundingClientRect();
        const openChangesHit = document.elementFromPoint(
          openChangesRect.left + openChangesRect.width / 2,
          openChangesRect.top + openChangesRect.height / 2
        );
        openChangesHit.click();
        const changesOpened = !rightPanel.hidden;
        const workspaceTabs = rightPanel.querySelector('[role="tablist"]');
        const changesTab = rightPanel.querySelector("#changes-tab");
        const filesTab = rightPanel.querySelector("#files-tab");
        const filesPanel = rightPanel.querySelector("#files-panel");
        const fileTree = rightPanel.querySelector("file-tree-container");
        const diffPaintSurface = diffSurface.querySelector(
          ".composer-diff-simple-line"
        );
        const additionLine = diffSurface.querySelector(
          "[data-line-type='change-addition']"
        );
        const deletionLine = diffSurface.querySelector(
          "[data-line-type='change-deletion']"
        );
        const toolReadabilitySurfaces = [
          toolSurface,
          summarySurface,
        ];
        const changesReadabilitySurfaces = [
          diffPaintSurface,
        ];
        const readabilitySurfaces = [
          ...toolReadabilitySurfaces,
          ...changesReadabilitySurfaces,
          codeSurface,
          composerSurface,
        ];
        const clickTab = (tab) => tab.click();
        clickTab(filesTab);
        const filesTabSelected =
          filesTab.getAttribute("aria-selected") === "true" &&
          !filesPanel.hidden &&
          diffSurface.hidden;
        clickTab(changesTab);
        const changesTabRestored =
          changesTab.getAttribute("aria-selected") === "true" &&
          filesPanel.hidden &&
          !diffSurface.hidden;
        const pane = document.querySelector(
          "[data-app-shell-pane-content-viewport]"
        );
        const dialog = document.querySelector("#settings-dialog");
        const popper = document.createElement("div");
        popper.dataset.radixPopperContentWrapper = "";
        const menu = document.createElement("div");
        menu.setAttribute("role", "menu");
        popper.append(menu);
        document.body.append(popper);
        const dialogAction = document.querySelector("#dialog-action");
        dialogAction.focus();
        const dialogHasFocus = document.activeElement === dialogAction;
        tool.addEventListener("click", () => {
          details.hidden = !details.hidden;
        });
        tool.scrollIntoView({ block: "center" });
        const rect = tool.getBoundingClientRect();
        const hit = document.elementFromPoint(
          rect.left + rect.width / 2,
          rect.top + rect.height / 2
        );
        const toolInitiallyHidden = details.hidden;
        hit.click();
        let toolToggleWorked = details.hidden !== toolInitiallyHidden;
        hit.click();
        toolToggleWorked &&= details.hidden === toolInitiallyHidden;
        ordinaryActivityAction.scrollIntoView({ block: "center" });
        ordinaryActivityAction.focus();
        const ordinaryActivityActionRect =
          ordinaryActivityAction.getBoundingClientRect();
        const ordinaryActivityActionHit = document.elementFromPoint(
          ordinaryActivityActionRect.left +
            ordinaryActivityActionRect.width / 2,
          ordinaryActivityActionRect.top +
            ordinaryActivityActionRect.height / 2
        );
        const range = document.createRange();
        range.selectNodeContents(document.querySelector("#message"));
        const selection = getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
        const streamed = document.createElement("p");
        streamed.id = "streamed-message";
        streamed.textContent = "Streamed response";
        document.querySelector("#message").append(streamed);
        streamed.scrollIntoView({ block: "center" });
        const readAlpha = (element, property = "backgroundColor") => {
          const value = getComputedStyle(element)[property];
          const match =
            value.match(/\\/\\s*([\\d.]+)\\s*\\)/) ||
            value.match(/,\\s*([\\d.]+)\\s*\\)$/);
          return match ? Number(match[1]) : 1;
        };
        const themeBases = ["dark", "light"].map((theme) => {
          document.documentElement.dataset.theme = theme;
          return [
            surface,
            ...readabilitySurfaces,
          ]
            .every(
              (element) =>
                getComputedStyle(element).backgroundColor !==
                "rgba(0, 0, 0, 0)"
            );
        });
        const themeFooterBackdrops = ["dark", "light"].map((theme) => {
          document.documentElement.dataset.theme = theme;
          return getComputedStyle(footerBackdrop).backgroundColor ===
            "rgba(0, 0, 0, 0)" &&
            getComputedStyle(footerShell, "::before").backgroundImage === "none" &&
            getComputedStyle(footerShell, "::after").backgroundColor === "rgba(0, 0, 0, 0)";
        });
        const fade = document.querySelector("#thread-top-fade");
        const pixel = document.createElement("canvas").getContext("2d");
        const fadeIsTranslucent = () => {
          const gradient = getComputedStyle(fade).backgroundImage;
          const color = gradient.match(/^linear-gradient\\(((?:rgba?|color)\\([^)]*\\))/)?.[1];
          if (!color || !CSS.supports("color", color)) return false;
          pixel.clearRect(0, 0, 1, 1);
          pixel.fillStyle = color;
          pixel.fillRect(0, 0, 1, 1);
          const alpha = pixel.getImageData(0, 0, 1, 1).data[3];
          return alpha > 0 && alpha < 255;
        };
        const wallpaperVisibility = ["dark", "light"].map((theme) => {
          document.documentElement.dataset.theme = theme;
          const surfaceAlpha = readAlpha(surface);
          const frameAlpha = readAlpha(frame);
          return {
            theme,
            frameAlpha,
            surfaceAlpha,
            compositeAlpha: 1 - (1 - frameAlpha) * (1 - surfaceAlpha),
            wallpaperOpacity: Number(getComputedStyle(media).opacity),
            translucentTopFade: fadeIsTranslucent(),
          };
        });
        return {
          translucentTopFade: wallpaperVisibility.every(({ translucentTopFade }) => translucentTopFade),
          mainWallpaperHasNoExtraBlur: getComputedStyle(surface).backdropFilter === "none",
          paneHasNoForcedBlur:
            getComputedStyle(pane).backdropFilter === "none",
          frameCarriesPageSidebarAnchor:
            frame.hasAttribute("data-app-shell-page-sidebar"),
          surfaceAboveBackground:
            Number.parseInt(getComputedStyle(surface).zIndex, 10) >
            Number.parseInt(getComputedStyle(background).zIndex, 10),
          surfaceHasReadabilityBase:
            getComputedStyle(surface).backgroundColor !== "rgba(0, 0, 0, 0)",
          contentHasReadabilityBases: readabilitySurfaces.every(
            (element) =>
              getComputedStyle(element).backgroundColor !==
              "rgba(0, 0, 0, 0)"
          ),
          composerOuterPaintTransparent: themeFooterBackdrops.every(Boolean),
          footerLeadingHasReadabilityBase:
            getComputedStyle(footerLeading).backgroundColor !==
            "rgba(0, 0, 0, 0)",
          ordinaryChatSharesCanvas: [ordinaryStatus, userMessage].every(
            (element) => readAlpha(element) === 0
          ),
          ordinaryActivityHasNoCard:
            readAlpha(ordinaryActivity) === 0 &&
            getComputedStyle(ordinaryActivity).boxShadow === "none" &&
            getComputedStyle(ordinaryActivity).borderRadius === "0px",
          ordinaryActivityKeepsNativeInteraction:
            document.activeElement === ordinaryActivityAction &&
            ordinaryActivity.contains(ordinaryActivityActionHit) &&
            ordinaryActivityAction.getAttribute("aria-expanded") === "false",
          userMarkdownKeepsNativeState:
            userMarkdownAction.getAttribute("aria-expanded") === "false" &&
            readAlpha(userMarkdownAction) === 0,
          themesHaveReadabilityBases: themeBases.every(Boolean),
          wallpaperRemainsVisible:
            wallpaperVisibility.every(
              ({ compositeAlpha, frameAlpha, wallpaperOpacity }) =>
                compositeAlpha > frameAlpha &&
                compositeAlpha < 1 &&
                wallpaperOpacity === 1
            ),
          panelSurfacesHaveReadability: [leftPanel, pane, dialog].every(
            (element) =>
              getComputedStyle(element).backgroundColor !==
                "rgba(0, 0, 0, 0)"
          ),
          browserSurfaceIsOpaque: (() => {
            const host = document.querySelector("[data-browser-sidebar-webview]");
            const webview = host.querySelector("webview");
            const read = () => [host, webview].map((node) => getComputedStyle(node).backgroundColor).join(" / ");
            const light = read();
            document.documentElement.dataset.theme = "dark";
            const dark = read();
            document.documentElement.dataset.theme = "light";
            return getComputedStyle(host).opacity === "1" &&
              light === "rgb(232, 232, 237) / rgb(232, 232, 237)" &&
              dark === "rgb(12, 12, 16) / rgb(12, 12, 16)";
          })(),
          wallpaperControlsUseSharedPalette:
            getComputedStyle(toolbar).backgroundColor ===
              getComputedStyle(dialog).backgroundColor &&
            getComputedStyle(panel).backgroundColor ===
              getComputedStyle(dialog).backgroundColor,
          wallpaperControlsHaveNoExtraBlur:
            getComputedStyle(toolbar).backdropFilter === "none" &&
            getComputedStyle(panel).backdropFilter === "none",
          menuPaintsOnlyVisibleContent:
            getComputedStyle(popper).backgroundColor ===
              "rgba(0, 0, 0, 0)" &&
            getComputedStyle(menu).backgroundColor ===
              getComputedStyle(dialog).backgroundColor,
          dialogKeepsHostPosition:
            getComputedStyle(dialog).position === "static" &&
            getComputedStyle(dialog).zIndex === "auto",
          changesOpened,
          changesPanelKeepsWallpaper: readAlpha(rightPanel) === 0,
          changesScrollKeepsWallpaper: readAlpha(diffSurface) === 0,
          changesTabsKeepWallpaper: readAlpha(workspaceTabs) === 0,
          changesFileTreeKeepsWallpaper: readAlpha(fileTree) === 0,
          filesTabSelected,
          changesTabRestored,
          changesContentHasReadabilityBase: readAlpha(diffPaintSurface) > 0,
          changesDiffCodeStaysTransparent: readAlpha(changesCodeSurface) === 0,
          changesSignalsRemainDistinct:
            readAlpha(additionLine) > 0 &&
            readAlpha(deletionLine) > 0 &&
            getComputedStyle(additionLine).backgroundColor !==
              getComputedStyle(deletionLine).backgroundColor,
          changesBackgroundLayers: document.querySelectorAll(
            "#${rootId} [data-codex-wallpaper-layer]"
          ).length,
          changesRuntimeState: globalThis.__codexWallpaperApi.state().state,
          changesPanelClosed: (() => {
            rightPanel.hidden = true;
            return rightPanel.hidden;
          })(),
          dialogHasFocus,
          backgroundIgnoresPointers:
            getComputedStyle(background).pointerEvents === "none",
          wallpaperMediaVisible:
            getComputedStyle(media).backgroundImage.includes("gradient") &&
            getComputedStyle(media).opacity === "1",
          toolbarIsAboveHost: toolbar.contains(toolbarHit),
          toolReceivesClick: hit === tool && toolToggleWorked,
          composerIdleShadow: getComputedStyle(composerSurface).boxShadow,
          messageIsSelectable: selection.toString().startsWith("Long assistant response"),
          pageScrolled: scrollY > 0,
          streamedMessageIsHitTestable:
            document.elementFromPoint(
              streamed.getBoundingClientRect().left + 1,
              streamed.getBoundingClientRect().top + 1
            ) === streamed
        };
      })()`,
    options
  );
  assert.deepEqual(chatResults, {
    translucentTopFade: true,
    mainWallpaperHasNoExtraBlur: true,
    paneHasNoForcedBlur: true,
    frameCarriesPageSidebarAnchor: true,
    surfaceAboveBackground: true,
    surfaceHasReadabilityBase: true,
    contentHasReadabilityBases: true,
    composerOuterPaintTransparent: true,
    footerLeadingHasReadabilityBase: true,
    ordinaryChatSharesCanvas: true,
    ordinaryActivityHasNoCard: true,
    ordinaryActivityKeepsNativeInteraction: true,
    userMarkdownKeepsNativeState: true,
    themesHaveReadabilityBases: true,
    wallpaperRemainsVisible: true,
    panelSurfacesHaveReadability: true,
    browserSurfaceIsOpaque: true,
    wallpaperControlsUseSharedPalette: true,
    wallpaperControlsHaveNoExtraBlur: true,
    menuPaintsOnlyVisibleContent: true,
    dialogKeepsHostPosition: true,
    changesOpened: true,
    changesPanelKeepsWallpaper: true,
    changesScrollKeepsWallpaper: true,
    changesTabsKeepWallpaper: true,
    changesFileTreeKeepsWallpaper: true,
    filesTabSelected: true,
    changesTabRestored: true,
    changesContentHasReadabilityBase: true,
    changesDiffCodeStaysTransparent: true,
    changesSignalsRemainDistinct: true,
    changesBackgroundLayers: 1,
    changesRuntimeState: "enabled",
    changesPanelClosed: true,
    dialogHasFocus: true,
    backgroundIgnoresPointers: true,
    wallpaperMediaVisible: true,
    toolbarIsAboveHost: true,
    toolReceivesClick: true,
    messageIsSelectable: true,
    pageScrolled: true,
    streamedMessageIsHitTestable: true,
  });
  await evaluateInPage(
    port,
    'document.querySelector("#composer").scrollIntoView({ block: "center" })',
    options
  );
  const composerReceivesClick = await clickAtElementCenter(
    port,
    options,
    "#composer"
  );
  await callMainPage(
    port,
    "Input.insertText",
    { text: " from CDP" },
    options.page,
    true
  );
  assert.deepEqual(
    {
      composerReceivesClick,
      ...(await evaluateInPage(
        port,
        `({
        composerHasFocus: document.activeElement === document.querySelector("#composer"),
        composerAcceptedText: document.querySelector("#composer").value.includes("from CDP"),
        composerFocusStyleChanged:
          getComputedStyle(document.querySelector("[data-composer-surface-variant]")).boxShadow !==
          ${JSON.stringify(composerIdleShadow)},
        userMarkdownKeepsNativeState:
          document.querySelector("#user-markdown-action").getAttribute("aria-expanded") === "false"
      })`,
        options
      )),
    },
    {
      composerReceivesClick: true,
      composerHasFocus: true,
      composerAcceptedText: true,
      composerFocusStyleChanged: true,
      userMarkdownKeepsNativeState: true,
    }
  );
  const metrics = await openMainPageSession(port, options.page, true);
  t.after(() => metrics.close());
  await metrics.send("Emulation.setDeviceMetricsOverride", {
    width: 1707,
    height: 1066,
    deviceScaleFactor: 1,
    mobile: false,
  });
  await evaluateInPage(
    port,
    `(() => {
      document.querySelector("[data-composer-surface-variant]").style.cssText =
        "position:fixed;z-index:10;right:108px;bottom:20px;width:736px;height:98px;box-sizing:border-box";
      document.querySelector("[data-app-shell-pane-content-viewport]").hidden = true;
      document.querySelector("#${controlRootId} .toolbar").style.cssText =
        "position-anchor:none;right:14px;left:auto;bottom:14px";
    })()`,
    options
  );
  const settingsButton = `#${controlRootId} [data-codex-wallpaper-settings]`;
  await evaluateInPage(
    port,
    `(() => {
      document.querySelector("#${controlRootId} [data-codex-wallpaper-settings]").click();
    })()`,
    options
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(() => {
        const panel = document.querySelector("#${controlRootId} .panel.open");
        const c = document.querySelector("[data-composer-surface-variant]").getBoundingClientRect();
        const p = panel.getBoundingClientRect();
        return { visible: p.top >= 0 && p.right <= innerWidth, clear: p.bottom <= c.top - 3 };
      })()`,
      options
    ),
    { visible: true, clear: true }
  );
  await evaluateInPage(
    port,
    `(() => {
      document.querySelector("#${controlRootId} [data-codex-wallpaper-settings]").click();
    })()`,
    options
  );
  assert.equal(
    await evaluateInPage(
      port,
      `!document.querySelector("#${controlRootId} .panel").classList.contains("open")`,
      options
    ),
    true
  );
  await evaluateInPage(
    port,
    `document.querySelector("#${controlRootId} .toolbar").removeAttribute("style")`,
    options
  );
  await metrics.send("Emulation.setDeviceMetricsOverride", {
    width: 1290,
    height: 900,
    deviceScaleFactor: 1,
    mobile: false,
  });
  await evaluateInPage(
    port,
    `(() => {
      const composer = document.querySelector("[data-composer-surface-variant]");
      composer.style.cssText = "position:fixed;right:108px;bottom:20px;width:736px;height:98px;box-sizing:border-box";
      const action = document.createElement("button");
      action.id = "fixture-composer-action";
      action.type = "button";
      action.textContent = "Mic";
      action.style.cssText = "position:absolute;right:8px;bottom:8px;width:28px;height:28px";
      action.onclick = () => action.toggleAttribute("data-clicked");
      composer.append(action);
    })()`,
    options
  );
  const narrowComposerReceivesClick = await clickAtElementCenter(
    port,
    options,
    "#fixture-composer-action"
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(() => {
        const action = document.querySelector("#fixture-composer-action");
        const center = action.getBoundingClientRect();
        const hit = document.elementFromPoint(
          center.left + center.width / 2,
          center.top + center.height / 2
        );
        return {
          receivesClick: ${narrowComposerReceivesClick},
          hitTag: hit?.tagName || null,
          hitInsideAction: hit === action || action.contains(hit),
          panelOpen: document
            .querySelector("#${controlRootId} .panel")
            .classList.contains("open")
        };
      })()`,
      options
    ),
    {
      receivesClick: true,
      hitTag: "BUTTON",
      hitInsideAction: true,
      panelOpen: false,
    }
  );
  assert.equal(
    await evaluateInPage(
      port,
      'document.querySelector("#fixture-composer-action").hasAttribute("data-clicked")',
      options
    ),
    true
  );
  await evaluateInPage(
    port,
    `(() => {
      const button = document.querySelector(${JSON.stringify(settingsButton)});
      globalThis.__t03SettingsClicks = 0;
      button.addEventListener("click", () => {
        globalThis.__t03SettingsClicks += 1;
      });
    })()`,
    options
  );
  assert.equal(await clickAtElementCenter(port, options, settingsButton), true);
  await evaluateInPage(
    port,
    `(() => {
      const panel = document.querySelector("#${controlRootId} .panel");
      panel.classList.remove("open");
      globalThis.__t03SettingsClicks = 0;
      document.querySelector(${JSON.stringify(settingsButton)}).click();
    })()`,
    options
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(() => {
        const panel = document.querySelector("#${controlRootId} .panel.open");
        const c = document.querySelector("[data-composer-surface-variant]").getBoundingClientRect();
        const p = panel?.getBoundingClientRect();
        return {
          clicks: globalThis.__t03SettingsClicks,
          visible: Boolean(p && p.top >= 0 && p.right <= innerWidth),
          clear: Boolean(p && p.bottom < c.top)
        };
      })()`,
      options
    ),
    { clicks: 1, visible: true, clear: true }
  );
  await clickAtElementCenter(port, options, settingsButton);
  await evaluateInPage(
    port,
    `(() => {
      document.querySelector("#fixture-composer-action").remove();
      document.querySelector("[data-composer-surface-variant]").removeAttribute("style");
      document.querySelector("[data-app-shell-pane-content-viewport]").hidden = false;
    })()`,
    options
  );
  await metrics.send("Emulation.clearDeviceMetricsOverride");
  assert.equal(
    (await applyStaticBackground(port, options)).backgroundLayers,
    1
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const controls = document.getElementById("${controlRootId}");
        controls.querySelector("[data-codex-wallpaper-settings]").click();
        const card = [...controls.querySelectorAll(".card")].find(
          (item) => item.querySelector("strong")?.textContent === "Fixture Image"
        );
        card.querySelector(".card-actions button").click();
        for (const [input, value] of [
          [controls.querySelector("[data-setting='dim']"), "42"],
          [controls.querySelector("[data-setting='blur']"), "6"],
          [controls.querySelector("[data-setting='opacity']"), "73"]
        ]) {
          input.value = value;
          input.dispatchEvent(new Event("input", { bubbles: true }));
        }
        [...controls.querySelectorAll(".card")]
          .find(
            (item) =>
              item.querySelector("strong")?.textContent === "Fixture Scene"
          )
          .querySelector(".card-actions button")
          .click();
        for (let attempt = 0; attempt < 40; attempt += 1) {
          if (controls.querySelector("[data-setting='fps']")) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const fps = controls.querySelector("[data-setting='fps']");
        fps.value = "15";
        fps.dispatchEvent(new Event("input", { bubbles: true }));
        fps.dispatchEvent(new Event("change", { bubbles: true }));
        [...controls.querySelectorAll(".card")]
          .find(
            (item) =>
              item.querySelector("strong")?.textContent === "Fixture Image"
          )
          .querySelector(".card-actions button")
          .click();
        for (let attempt = 0; attempt < 40; attempt += 1) {
          const image = document.querySelector(
            "#${rootId} .media:not(.staged) img"
          );
          if (image?.complete && image.naturalWidth > 0) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const root = document.getElementById("${rootId}");
        const media = root.querySelector(".media:not(.staged)");
        const saved = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        );
        const selectedCard = [...controls.querySelectorAll(".card")].find(
          (item) => item.querySelector("strong")?.textContent === "Fixture Image"
        );
        const selectedActions = selectedCard.querySelectorAll(".card-actions button");
        return {
          selected: saved.active,
          settings: saved.settings,
          selectedCard: selectedCard.dataset.selected,
          selectedActions: [...selectedActions].map((button) =>
            button.getAttribute("aria-pressed")
          ),
          imageIsFixture: media.querySelector("img")?.src.includes("5d32b8"),
          playerCount: globalThis.__codexWallpaperApi.state().playerCount,
          opacity: root.querySelector("[data-codex-wallpaper-layer]").style.opacity,
          filter: media.style.filter
        };
      })()`,
      options
    ),
    {
      selected: { kind: "workshop", id: "fixture-image" },
      settings: {
        dim: 42,
        blur: 6,
        opacity: 73,
        fitMode: "cover",
        surfaceOpacity: 72,
        interfaceBlur: 0,
        interfaceBorders: true,
        surfaceOverrides: {
          chat: null,
          sidebar: null,
          right: null,
          settings: null,
        },
        fps: 15,
        volume: 0,
        muted: true,
        rotationMinutes: 0,
        performanceProfile: "custom",
        pauseWhenHidden: true,
      },
      selectedCard: "true",
      selectedActions: ["true", "false", "false"],
      imageIsFixture: true,
      playerCount: 0,
      opacity: "0.73",
      filter: "blur(6px)",
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(() => {
        document.getElementById("open-changes").click();
        const sidebar = document.querySelector(
          "[data-app-shell-trailing-sidebar]"
        );
        const review = sidebar.querySelector(
          "[data-thread-find-target='review']"
        );
        const titlebar = document.querySelector("[data-app-shell-titlebar]");
        const panelBackground = getComputedStyle(sidebar).backgroundColor;
        const opened = {
          titlebarRemainsFixed: getComputedStyle(titlebar).position === "fixed",
          panel: !sidebar.hidden,
          panelKeepsWallpaper:
            panelBackground.includes("/ 0)") || panelBackground.endsWith("0, 0)"),
          reviewAlpha: getComputedStyle(review).backgroundColor,
          code: review.querySelector("code")?.textContent,
          wallpaperLayers: document.querySelectorAll(
            "#${rootId} [data-codex-wallpaper-layer]"
          ).length,
          imageIsFixture: document.querySelector("#${rootId} .media img")
            ?.src.includes("5d32b8")
        };
        document.getElementById("close-changes").click();
        return { ...opened, closed: sidebar.hidden };
      })()`,
      options
    ),
    {
      titlebarRemainsFixed: true,
      panel: true,
      panelKeepsWallpaper: true,
      reviewAlpha: "rgba(0, 0, 0, 0)",
      code: "const visible = true;",
      wallpaperLayers: 1,
      imageIsFixture: true,
      closed: true,
    }
  );
  const themeMaterialExpression = `(() => {
      const controls = document.getElementById("${controlRootId}");
      const root = document.documentElement;
      return ["dark", "light"].map((theme) => {
        root.dataset.theme = theme;
        return {
          theme,
          main: getComputedStyle(
            document.querySelector("[data-app-shell-main-surface]")
          ).backgroundColor,
          toolbar: getComputedStyle(
            controls.querySelector(".toolbar")
          ).backgroundColor,
          panel: getComputedStyle(
            controls.querySelector("[data-codex-wallpaper-panel]")
          ).backgroundColor
        };
      });
    })()`;
  const themeMaterialBefore = await evaluateInPage(
    port,
    themeMaterialExpression,
    options
  );
  await evaluateInPage(
    port,
    `document.body.append(document.getElementById("${controlRootId}").cloneNode(true))`,
    options
  );
  const toggleReceivesClick = await clickAtElementCenter(
    port,
    options,
    `#${controlRootId} .toolbar [data-codex-wallpaper-toggle]`
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(() => {
        const saved = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        );
        return {
          toggleReceivesClick: ${toggleReceivesClick},
          state: globalThis.__codexWallpaperApi.state(),
          savedEnabled: saved.enabled,
          savedActive: saved.active,
          savedSettings: saved.settings,
          roots: document.querySelectorAll(
            "#${rootId}, #${controlRootId}, #${rootId}-style"
          ).length
        };
      })()`,
      options
    ),
    {
      toggleReceivesClick,
      state: {
        state: "disabled",
        backgroundLayers: 0,
        controls: 0,
        styles: 0,
        activeKind: "workshop",
        activeId: "fixture-image",
        libraryCount: 7,
        importedCount: 0,
        playerCount: 0,
        visible: true,
        measuredFps: 0,
        fpsCap: 15,
        volume: 0,
        hostReady: true,
      },
      savedEnabled: false,
      savedActive: { kind: "workshop", id: "fixture-image" },
      savedSettings: {
        dim: 42,
        blur: 6,
        opacity: 73,
        fitMode: "cover",
        surfaceOpacity: 72,
        interfaceBlur: 0,
        interfaceBorders: true,
        surfaceOverrides: {
          chat: null,
          sidebar: null,
          right: null,
          settings: null,
        },
        fps: 15,
        volume: 0,
        muted: true,
        rotationMinutes: 0,
        performanceProfile: "custom",
        pauseWhenHidden: true,
      },
      roots: 0,
    }
  );
  await pressAltShiftW();
  await waitForWallpaperImage();
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(() => {
        const root = document.getElementById("${rootId}");
        const controls = document.getElementById("${controlRootId}");
        const media = root.querySelector(".media");
        const saved = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        );
        return {
          state: { ...globalThis.__codexWallpaperApi.state(), controls: undefined },
          roots: {
            wallpaper: document.querySelectorAll("#${rootId}").length,
            controls: document.querySelectorAll("#${controlRootId}").length,
            styles: document.querySelectorAll("#${rootId}-style").length
          },
          imageIsFixture: media.querySelector("img")?.src.includes("5d32b8"),
          opacity: root.querySelector("[data-codex-wallpaper-layer]").style.opacity,
          filter: media.style.filter,
          settingsInputs: Object.fromEntries(
            [...controls.querySelectorAll(".range input[type='range']")].map((input) => [
              input.dataset.setting,
              Number(input.value)
            ])
          ),
          savedActive: saved.active,
          savedEnabled: saved.enabled
        };
      })()`,
      options
    ),
    {
      state: {
        state: "enabled",
        backgroundLayers: 1,
        styles: 1,
        activeKind: "workshop",
        activeId: "fixture-image",
        libraryCount: 7,
        importedCount: 0,
        playerCount: 0,
        visible: true,
        measuredFps: 0,
        fpsCap: 15,
        volume: 0,
        hostReady: true,
      },
      roots: { wallpaper: 1, controls: 1, styles: 1 },
      imageIsFixture: true,
      opacity: "0.73",
      filter: "blur(6px)",
      settingsInputs: {
        volume: 0,
        rotationMinutes: 0,
        dim: 42,
        blur: 6,
        opacity: 73,
        surfaceOpacity: 72,
        interfaceBlur: 0,
      },
      savedActive: { kind: "workshop", id: "fixture-image" },
      savedEnabled: true,
    }
  );
  await pressAltShiftW();
  assert.deepEqual(
    await evaluateInPage(
      port,
      `({
        state: globalThis.__codexWallpaperApi.state().state,
        toolbar: document.querySelector("#${controlRootId} .toolbar") !== null
      })`,
      options
    ),
    { state: "disabled", toolbar: false }
  );
  await pressAltShiftW();
  await waitForWallpaperImage();
  assert.deepEqual(
    await evaluateInPage(port, themeMaterialExpression, options),
    themeMaterialBefore
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        await new Promise((resolve) => setTimeout(resolve, 50));
        const value = JSON.parse(
          localStorage.getItem("codex-wallpaper-p1-config")
        );
        value.enabled = false;
        value.active = { kind: "workshop", id: "fixture-on-demand" };
        globalThis.__testHostRequests = [];
        globalThis.__codexWallpaperHostRequest = (raw) => {
          const request = JSON.parse(raw);
          if (request.type === "load-asset")
            globalThis.__testHostRequests.push(request);
        };
        const next = JSON.stringify(value);
        localStorage.setItem("codex-wallpaper-p1-config", next);
        dispatchEvent(
          new StorageEvent("storage", {
            key: "codex-wallpaper-p1-config",
            newValue: next,
            storageArea: localStorage
          })
        );
        await new Promise((resolve) => setTimeout(resolve, 50));
        return true;
      })()`,
      options
    ),
    true
  );
  await new Promise((resolve) => setTimeout(resolve, 30));
  assert.deepEqual(
    await evaluateInPage(
      port,
      `({ root: document.querySelectorAll("#${rootId}, #${controlRootId}").length, styles: document.querySelectorAll("#${rootId}-style").length })`,
      options
    ),
    { root: 0, styles: 0 }
  );
  await pressAltShiftW();
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        for (let attempt = 0; attempt < 80; attempt += 1) {
          if (globalThis.__testHostRequests.length > 0) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        const root = document.getElementById("${rootId}");
        const media = root.querySelector(".media");
        const nativeBeforeAsset =
          media?.childElementCount === 0 &&
          !media.classList.contains("builtin");
        const previewShown = Boolean(
          media?.querySelector(".media-preview")
        );
        const request = globalThis.__testHostRequests[0];
        globalThis.__codexWallpaperApi.receiveAsset({
          id: "fixture-on-demand",
          title: "Fixture On Demand",
          type: "image",
          playable: true,
          fallback: true,
          previewDataUrl: null,
          assetDataUrl:
            "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='9'%3E%3Crect width='16' height='9' fill='%2322c55e'/%3E%3C/svg%3E",
          assetUrl: null,
          webHtml: null,
          reason: null
        });
        for (let attempt = 0; attempt < 40; attempt += 1) {
          const image = root.querySelector(".media:not(.staged) img");
          if (image?.complete && image.naturalWidth > 0) break;
          await new Promise((resolve) => setTimeout(resolve, 25));
        }
        return {
          request,
          nativeBeforeAsset,
          previewShown,
          assetShown: root
            .querySelector(".media:not(.staged) img")
            ?.src.includes("22c55e"),
          state: { ...globalThis.__codexWallpaperApi.state(), controls: undefined }
        };
      })()`,
      options
    ),
    {
      request: { type: "load-asset", id: "fixture-on-demand" },
      nativeBeforeAsset: true,
      previewShown: false,
      assetShown: true,
      state: {
        state: "enabled",
        backgroundLayers: 1,
        styles: 1,
        activeKind: "workshop",
        activeId: "fixture-on-demand",
        libraryCount: 7,
        importedCount: 0,
        playerCount: 0,
        visible: true,
        measuredFps: 0,
        fpsCap: 15,
        volume: 0,
        hostReady: true,
      },
    }
  );
  await evaluateInPage(
    port,
    `(() => {
      const originalTheme = document.documentElement.dataset.theme;
      const settings = document.createElement("div");
      settings.id = "settings-fixture";
      settings.dataset.appShellFeatureNavigation = "true";
      settings.dataset.appShellFrame = "";
      settings.style.cssText =
        "position:fixed;inset:0;z-index:100;display:grid;grid-template-columns:340px minmax(0,1fr);color:var(--app-color-text-foreground);background:var(--app-color-background-surface)";
      settings.innerHTML = \`
        <div data-settings-nav-scroll-container style="padding:44px 12px">
          <h1 style="margin:0 16px 18px">设置</h1>
          <div id="settings-search-shell" class="bg-background-secondary-soft-alpha" style="padding:9px 12px;border-radius:9999px;background:rgba(255,255,255,.08)">
            <input id="settings-search-input" role="searchbox" placeholder="搜索">
          </div>
          <nav aria-label="设置" style="display:grid;gap:1px;margin-top:16px">
            <button id="settings-general" data-settings-panel-slug="general-settings" aria-current="page" style="padding:6px 16px;border:0;border-radius:12.5px;background:rgba(255,255,255,.08);text-align:left">常规</button>
            <button id="settings-appearance" data-settings-panel-slug="appearance" style="padding:6px 16px;border:0;border-radius:12.5px;background:transparent;text-align:left">外观</button>
          </nav>
        </div>
        <main data-app-shell-main-surface="default" style="min-height:0;overflow:auto">
          <div id="settings-viewport" class="electron:bg-surface" style="min-height:100%;background:rgb(24,24,28)">
            <div data-density="default" style="width:min(728px,calc(100% - 48px));margin:80px auto">
              <h2>常规</h2>
              <div id="settings-card" class="rounded-2xl border-default" style="padding:16px;background:rgb(35,35,35);border:1px solid rgba(255,255,255,.082);border-radius:20px;--color-border:rgba(255,255,255,.082)">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;padding:8px 0">
                  <span>默认文件打开位置</span>
                  <button id="settings-select" class="bg-background-neutral-soft-alpha border-default" aria-expanded="false" style="padding:4px 12px;border-radius:12.5px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.082)">VS Code</button>
                </div>
                <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;padding:8px 0">
                  <span>默认使用完整视图</span>
                  <button id="settings-switch" role="switch" aria-checked="true" data-state="checked" style="padding:0;border:0;background:transparent">
                    <span id="settings-switch-track" data-state="checked" style="display:block;width:32px;height:20px;border-radius:9999px;background:rgb(2,133,255)"></span>
                  </button>
                </div>
                <button id="settings-secondary" class="bg-text/5" style="padding:4px 12px;border:0;border-radius:12.5px;background:rgba(255,255,255,.05)">更改</button>
              </div>
            </div>
          </div>
        </main>
      \`;
      document.body.append(settings);

      const search = settings.querySelector("#settings-search-input");
      const searchShell = settings.querySelector("#settings-search-shell");
      const select = settings.querySelector("#settings-select");
      const switchControl = settings.querySelector("#settings-switch");
      const switchTrack = settings.querySelector("#settings-switch-track");
      const menu = document.createElement("div");
      menu.id = "settings-menu";
      menu.setAttribute("role", "dialog");
      menu.hidden = true;
      menu.textContent = "VS Code";
      menu.style.cssText =
        "position:fixed;right:24px;top:24px;z-index:101;padding:12px;border-radius:14px;background:rgb(20,20,20)";
      document.body.append(menu);
      settings
        .querySelectorAll("[data-settings-panel-slug]")
        .forEach((button) => {
          button.addEventListener("click", () => {
            settings
              .querySelectorAll("[data-settings-panel-slug]")
              .forEach((item) => item.removeAttribute("aria-current"));
            button.setAttribute("aria-current", "page");
          });
        });
      select.addEventListener("click", () => {
        const open = select.getAttribute("aria-expanded") !== "true";
        select.setAttribute("aria-expanded", String(open));
        menu.hidden = !open;
      });
      switchControl.addEventListener("click", () => {
        const checked =
          switchControl.getAttribute("aria-checked") !== "true";
        switchControl.setAttribute("aria-checked", String(checked));
        switchControl.dataset.state = checked ? "checked" : "unchecked";
        switchTrack.dataset.state = checked ? "checked" : "unchecked";
      });

      const decoy = document.createElement("div");
      decoy.id = "settings-scope-decoy";
      decoy.className = "electron:bg-surface";
      decoy.style.cssText =
        "position:fixed;right:0;bottom:0;width:8px;height:8px;background:rgb(35,35,35)";
      document.body.append(decoy);
      globalThis.__settingsOriginalTheme = originalTheme;
      globalThis.__settingsSearchShell = searchShell;
      globalThis.__settingsSearch = search;
      globalThis.__settingsSearchIdleShadow =
        getComputedStyle(searchShell).boxShadow;
    })()`,
    options
  );
  assert.equal(
    await clickAtElementCenter(port, options, "#settings-search-input"),
    true
  );
  await callMainPage(
    port,
    "Input.insertText",
    { text: "通用" },
    options.page,
    true
  );
  const searchInteraction = await evaluateInPage(
    port,
    `(() => {
      const search = document.querySelector("#settings-search-input");
      const searchShell = document.querySelector("#settings-search-shell");
      return {
        focused: document.activeElement === search,
        acceptedText: search.value === "通用",
        focusStyleChanged:
          getComputedStyle(searchShell).boxShadow !==
          globalThis.__settingsSearchIdleShadow,
      };
    })()`,
    options
  );
  await callMainPage(
    port,
    "Input.dispatchKeyEvent",
    {
      type: "rawKeyDown",
      key: "Tab",
      code: "Tab",
      windowsVirtualKeyCode: 9,
      nativeVirtualKeyCode: 9,
    },
    options.page,
    true
  );
  await callMainPage(
    port,
    "Input.dispatchKeyEvent",
    {
      type: "keyUp",
      key: "Tab",
      code: "Tab",
      windowsVirtualKeyCode: 9,
      nativeVirtualKeyCode: 9,
    },
    options.page,
    true
  );
  const keyboardFocus = await evaluateInPage(
    port,
    `(() => ({
      target: document.activeElement.id,
      focusVisible: document.activeElement.matches(":focus-visible"),
      outline: getComputedStyle(document.activeElement).outlineStyle,
    }))()`,
    options
  );
  assert.equal(
    await clickAtElementCenter(port, options, "#settings-appearance"),
    true
  );
  assert.equal(
    await clickAtElementCenter(port, options, "#settings-select"),
    true
  );
  assert.equal(
    await clickAtElementCenter(port, options, "#settings-switch"),
    true
  );
  const settingsResults = await evaluateInPage(
    port,
    `(() => {
      const readAlpha = (element) => {
        const value = getComputedStyle(element).backgroundColor;
        const match =
          value.match(/\\/\\s*([\\d.]+)\\s*\\)/) ||
          value.match(/,\\s*([\\d.]+)\\s*\\)$/);
        return match ? Number(match[1]) : 1;
      };
      const viewport = document.querySelector("#settings-viewport");
      const card = document.querySelector("#settings-card");
      const searchShell = document.querySelector("#settings-search-shell");
      const selected = document.querySelector(
        "[data-settings-panel-slug][aria-current='page']"
      );
      const select = document.querySelector("#settings-select");
      const switchTrack = document.querySelector("#settings-switch-track");
      const menu = document.querySelector("#settings-menu");
      const decoy = document.querySelector("#settings-scope-decoy");
      const readMaterials = (theme) => {
        document.documentElement.dataset.theme = theme;
        return {
          viewport: getComputedStyle(viewport).backgroundColor,
          card: getComputedStyle(card).backgroundColor,
          search: getComputedStyle(searchShell).backgroundColor,
        };
      };
      const dark = readMaterials("dark");
      const light = readMaterials("light");
      document.documentElement.dataset.theme =
        globalThis.__settingsOriginalTheme;
      return {
        viewportTranslucent:
          readAlpha(viewport) > 0 && readAlpha(viewport) < 1,
        cardTranslucent: readAlpha(card) > 0 && readAlpha(card) < 1,
        cardBelowViewport: readAlpha(card) < readAlpha(viewport),
        searchHasMaterial:
          getComputedStyle(searchShell).boxShadow !== "none",
        selectedHasMaterial:
          getComputedStyle(selected).boxShadow !== "none",
        controlHasMaterial:
          getComputedStyle(select).borderColor !==
            "rgba(255, 255, 255, 0.082)" &&
          getComputedStyle(document.querySelector("#settings-secondary"))
            .backgroundColor !== "rgba(255, 255, 255, 0.05)",
        switchHasMaterial:
          getComputedStyle(switchTrack).boxShadow !== "none",
        themesDiffer:
          dark.viewport !== light.viewport &&
          dark.card !== light.card &&
          dark.search !== light.search,
        scopedToSettings:
          getComputedStyle(decoy).backgroundColor === "rgb(35, 35, 35)",
        appearanceSelected:
          document
            .querySelector("#settings-appearance")
            .getAttribute("aria-current") === "page",
        menuOpened:
          select.getAttribute("aria-expanded") === "true" && !menu.hidden,
        switchToggled:
          document
            .querySelector("#settings-switch")
            .getAttribute("aria-checked") === "false",
      };
    })()`,
    options
  );
  assert.deepEqual(
    {
      ...settingsResults,
      searchFocused: searchInteraction.focused,
      searchAcceptedText: searchInteraction.acceptedText,
      searchFocusStyleChanged: searchInteraction.focusStyleChanged,
      keyboardFocusTarget: keyboardFocus.target,
      keyboardFocusVisible:
        keyboardFocus.focusVisible && keyboardFocus.outline !== "none",
    },
    {
      viewportTranslucent: true,
      cardTranslucent: true,
      cardBelowViewport: true,
      searchHasMaterial: true,
      selectedHasMaterial: true,
      controlHasMaterial: true,
      switchHasMaterial: true,
      themesDiffer: true,
      scopedToSettings: true,
      appearanceSelected: true,
      menuOpened: true,
      switchToggled: true,
      searchFocused: true,
      searchAcceptedText: true,
      searchFocusStyleChanged: true,
      keyboardFocusTarget: "settings-general",
      keyboardFocusVisible: true,
    }
  );
  assert.deepEqual(
    await evaluateInPage(
      port,
      `(async () => {
        const initial = globalThis.__codexWallpaperApi.state();
        const before = {
          viewport: getComputedStyle(
            document.querySelector("#settings-viewport")
          ).backgroundColor,
          card: getComputedStyle(
            document.querySelector("#settings-card")
          ).backgroundColor,
        };
        await globalThis.__codexWallpaperApi.disable();
        const disabled = {
          styles: document.querySelectorAll("#${rootId}-style").length,
          viewport: getComputedStyle(
            document.querySelector("#settings-viewport")
          ).backgroundColor,
          card: getComputedStyle(
            document.querySelector("#settings-card")
          ).backgroundColor,
        };
        const enabled = await globalThis.__codexWallpaperApi.enable();
        await new Promise((resolve) => setTimeout(resolve, 40));
        return {
          initiallyEnabled: initial.state === "enabled",
          disabled,
          reapplied: {
            state: enabled.state,
            styles: document.querySelectorAll("#${rootId}-style").length,
            sameViewport:
              getComputedStyle(
                document.querySelector("#settings-viewport")
              ).backgroundColor === before.viewport,
            sameCard:
              getComputedStyle(
                document.querySelector("#settings-card")
              ).backgroundColor === before.card,
          },
        };
      })()`,
      options
    ),
    {
      initiallyEnabled: true,
      disabled: {
        styles: 0,
        viewport: "rgb(24, 24, 28)",
        card: "rgb(35, 35, 35)",
      },
      reapplied: {
        state: "enabled",
        styles: 1,
        sameViewport: true,
        sameCard: true,
      },
    }
  );
});
